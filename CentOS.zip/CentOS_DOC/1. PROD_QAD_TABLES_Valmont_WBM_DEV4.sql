--SCHEMA OF QAD TABLES
--ITEM TABLE SCHEMA
create table PROD_QAD_ITEM_EXTRACT_FI1010(
DOMAIN                               VARCHAR2(400),
ITEM_NUMBER                          VARCHAR2(400),
UOM                                  VARCHAR2(400),
DESC1                                VARCHAR2(400),
DESC2                                VARCHAR2(400),
PRODUCT_LINE                         VARCHAR2(400),
ADDED_DATE                           VARCHAR2(400),
DESIGN_GROUP                         VARCHAR2(400),
PROMO_GROUP                          VARCHAR2(400),
ITEM_TYPE                            VARCHAR2(400),
STATUS                               VARCHAR2(400),
"Group"                              VARCHAR2(400),
DRAWING                              VARCHAR2(400),
REVISION                             VARCHAR2(400),
DRAWING_LOCATION                     VARCHAR2(400),
"Size"                               VARCHAR2(400),
PRICE_BREAK_CATEGORY                 VARCHAR2(400),
ABC_CLASS                            VARCHAR2(400),
LOT_OR_SERIAL_CONTROL                VARCHAR2(400),
"Site"                               VARCHAR2(400),
"Location"                           VARCHAR2(400),
LOCATION_TYPE                        VARCHAR2(400),
AUTO_LOT_NUMBERS                     VARCHAR2(400),
LOT_GROUP                            VARCHAR2(400),
ARTICLE_NUMBER                       VARCHAR2(400),
AVERAGE_INTERVAL                     VARCHAR2(400),
CYCLE_COUNT_INTERVAL                 VARCHAR2(400),
SHELF_LIFE                           VARCHAR2(400),
ALLOCATE_SINGLE_LOT                  VARCHAR2(400),
KEY_ITEM                             VARCHAR2(400),
PO_RECEIPT_STATUS                    VARCHAR2(400),
PO_RECEIPT_STATUS_ACTIVE             VARCHAR2(400),
WO_RECEIPT_STATUS                    VARCHAR2(400),
WO_RECEIPT_STATUS_ACTIVE             VARCHAR2(400),
CORP_COMM_CODE                       VARCHAR2(400),
SHIP_WEIGHT                          VARCHAR2(400),
SHIP_WEIGHT_UOM                      VARCHAR2(400),
FREIGHT_CLASS                        VARCHAR2(400),
NET_WEIGHT                           VARCHAR2(400),
NET_WEIGHT_UOM                       VARCHAR2(400),
VOLUME                               VARCHAR2(400),
VOLUME_UOM                           VARCHAR2(400),
MASTER_SCHEDULING                    VARCHAR2(400),
PLAN_ORDERS                          VARCHAR2(400),
TIME_FENCE                           VARCHAR2(400),
MRP_REQUIRED                         VARCHAR2(400),
ORDER_POLICY                         VARCHAR2(400),
ORDER_QUANTITY                       VARCHAR2(400),
BATCH_QUANTITY                       VARCHAR2(400),
ORDER_PERIOD                         VARCHAR2(400),
SAFETY_STOCK                         VARCHAR2(400),
SAFETY_TIME                          VARCHAR2(400),
REORDER_POINT                        VARCHAR2(400),
ISSUE_POLICY                         VARCHAR2(400),
BUYER_OR_PLANNER                     VARCHAR2(400),
SUPPLIER                             VARCHAR2(400),
PO_SITE                              VARCHAR2(400),
PURCHASE_OR_MANUFACTURE              VARCHAR2(400),
CONFIGURATION_TYPE                   VARCHAR2(400),
INSPECT                              VARCHAR2(400),
INSPECTION_LEAD_TIME                 VARCHAR2(400),
MANUFACTURING_LEAD_TIME              VARCHAR2(400),
CUM_LEAD_TIME                        VARCHAR2(400),
PURCHASE_LEAD_TIME                   VARCHAR2(400),
ATP_ENFORCEMENT                      VARCHAR2(400),
FAMILY_ATP                           VARCHAR2(400),
RUN_SEQ_1                            VARCHAR2(400),
RUN_SEQ_2                            VARCHAR2(400),
PHANTOM                              VARCHAR2(400),
MINIMUM_ORDER                        VARCHAR2(400),
MAXIMUM_ORDER                        VARCHAR2(400),
ORDER_MULTIPLE                       VARCHAR2(400),
OP_BASED_YIELD                       VARCHAR2(400),
YIELD_PERCENT                        VARCHAR2(400),
RUN_TIME                             VARCHAR2(400),
SETUP_TIME                           VARCHAR2(400),
EMT_TYPE                             VARCHAR2(400),
AUTO_EMT_PROCESSING                  VARCHAR2(400),
NETWORK_CODE                         VARCHAR2(400),
ROUTING_CODE                         VARCHAR2(400),
BOM_OR_FORMULA                       VARCHAR2(400),
PRICE                                VARCHAR2(400),
TAX                                  VARCHAR2(400),
TAX_CLASS                            VARCHAR2(400),
CURRENT_BURDEN_LOWER_LEVEL           VARCHAR2(400),
STANDARD_BURDEN_LOWER_LEVEL          VARCHAR2(400),
CURRENT_BURDEN_TOP_LEVEL             VARCHAR2(400),
STANDARD_BURDEN_TOP_LEVEL            VARCHAR2(400),
CURRENT_LABOR_LOWER_LEVEL            VARCHAR2(400),
STANDARD_LABOR_LOWER_LEVEL           VARCHAR2(400),
CURRENT_LABOR_TOP_LEVEL              VARCHAR2(400),
STANDARD_LABOR_TOP_LEVEL             VARCHAR2(400),
CURRENT_MATERIAL_LOWER_LEVEL         VARCHAR2(400),
STANDARD_MATERIAL_LOWER_LEVEL        VARCHAR2(400),
CURRENT_MATERIAL_TOP_LEVEL           VARCHAR2(400),
STANDARD_MATERIAL_TOP_LEVEL          VARCHAR2(400),
CURRENT_OVERHEAD_LOWER_LEVEL         VARCHAR2(400),
STANDARD_OVERHEAD_LOWER_LEVEL        VARCHAR2(400),
CURRENT_OVERHEAD_TOP_LEVEL           VARCHAR2(400),
STANDARD_OVERHEAD_TOP_LEVEL          VARCHAR2(400),
CURRENT_SUBCONTRACTLOWER_LEVEL       VARCHAR2(400),
STANDARDSUBCONTRACTLOWER_LEVEL       VARCHAR2(400),
CURRENT_SUBCONTRACT_TOP_LEVEL        VARCHAR2(400),
STANDARD_SUBCONTRACT_TOP_LEVEL       VARCHAR2(400),
EN40_DECLARED_VALUE                  VARCHAR2(400),
EN40_CERTIFICATE_NUMBER              VARCHAR2(400),
EN40_DOOR_POSITION                   VARCHAR2(400),
EN40_VALIDATION                      VARCHAR2(400),
LENGTH_HEIGHT_SIZE_FORME             VARCHAR2(400),
BLOCKING                             VARCHAR2(400),
AUTO_8_13                            VARCHAR2(400));

--ITEM TABLES DATA IMPORT DONE
select * from PROD_QAD_ITEM_EXTRACT_FI1010;--63179  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010;--62049  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010;--453247  Rows
commit;

--BOM TABLE SCHEMA
create table PROD_QAD_BOM_EXTRACT_FI1010(
DOMAIN                 VARCHAR2(400),
PARENT_ITEM            VARCHAR2(400),
COMPONENT_ITEM         VARCHAR2(400),
REFERENCE              VARCHAR2(400),
START_EFFECTIVE        VARCHAR2(400),
END_EFFECTIVE          VARCHAR2(400),
QUANTITY_PER           VARCHAR2(400),
STRUCTURE_TYPE         VARCHAR2(400),
REMARKS                VARCHAR2(400),
SCRAP                  VARCHAR2(400),
LEAD_TIME_OFFSET       VARCHAR2(400),
OPERATION              VARCHAR2(400),
SEQUENCE_NUMBER        VARCHAR2(400),
FORECAST_PERCENT       VARCHAR2(400),
OPTION_GROUP           VARCHAR2(400),
PROCESS                VARCHAR2(400)
);

select * from PROD_QAD_BOM_EXTRACT_FI1010;--223117  Rows
select * from PROD_QAD_BOM_EXTRACT_FR1010;--296602  Rows
select * from PROD_QAD_BOM_EXTRACT_FR2010;--1936882  Rows
commit;

--SPECIAL CHARACTER ISSUE IN ITEM TABLES
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where item_number like '%�%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where DESC1 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where DESC2 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where lower(item_number) like '%š%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where lower(DESC1) like '%š%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FI1010 where lower(DESC2) like '%š%';--no rows

select * from PROD_QAD_ITEM_EXTRACT_FR1010 where item_number like '%�%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 where DESC1 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 where DESC2 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 where lower(item_number) like '%š%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 where lower(DESC1) like '%š%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 where lower(DESC2) like '%š%';--no rows

select * from PROD_QAD_ITEM_EXTRACT_FR2010 where item_number like '%�%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010 where DESC1 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010 where DESC2 like '%�%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010 where lower(item_number) like '%š%';--no rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010 where lower(DESC1) like '%š%';--no  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010 where lower(DESC2) like '%š%';--no  Rows

--SPECIAL CHARACTER ISSUE IN BOM TABLES
select * from PROD_QAD_BOM_EXTRACT_FI1010 where PARENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FI1010 where COMPONENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FI1010 where lower(PARENT_ITEM) like '%š%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FI1010 where lower(COMPONENT_ITEM) like '%š%';--no rows

select * from PROD_QAD_BOM_EXTRACT_FR1010 where PARENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR1010 where COMPONENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR1010 where lower(PARENT_ITEM) like '%š%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR1010 where lower(COMPONENT_ITEM) like '%š%';--no rows

select * from PROD_QAD_BOM_EXTRACT_FR2010 where PARENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR2010 where COMPONENT_ITEM like '%�%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR2010 where lower(PARENT_ITEM) like '%š%';--no rows
select * from PROD_QAD_BOM_EXTRACT_FR2010 where lower(COMPONENT_ITEM) like '%š%';--no rows

--BACKUP TABLES OF ORIGINAL IMPORTED DATA
--ITEM TABLES
create table PROD_QAD_ITEM_EXTRACT_FI1010_BKP_ORIG as select * from PROD_QAD_ITEM_EXTRACT_FI1010;
create table PROD_QAD_ITEM_EXTRACT_FR1010_BKP_ORIG as select * from PROD_QAD_ITEM_EXTRACT_FR1010;
create table PROD_QAD_ITEM_EXTRACT_FR2010_BKP_ORIG as select * from PROD_QAD_ITEM_EXTRACT_FR2010;

--BOM TABLES
create table PROD_QAD_BOM_EXTRACT_FI1010_BKP_ORIG as select * from PROD_QAD_BOM_EXTRACT_FI1010;
create table PROD_QAD_BOM_EXTRACT_FR1010_BKP_ORIG as select * from PROD_QAD_BOM_EXTRACT_FR1010;
create table PROD_QAD_BOM_EXTRACT_FR2010_BKP_ORIG as select * from PROD_QAD_BOM_EXTRACT_FR2010;

--SPECIAL CHARACTER ISSUE RESOLVED FOR ALL SITES
/*
we take decision from QAD Test environment based on some sample data
After staging we need to replace BOX Character with the specified values
Ø --FI
Ø --FR
ü --GE
Ø --NL
Ł --PL
AFTER SATGING OF PART DATA
FOR GERMANY and NL 'š' will be replaced with 'Ü'
FOR FRANCE 'š' will be replaced with 'è'
--ITEM TABLE SPECIAL CHARACTER ISSUE
--===================================
--FI1010 '�' will be replaced with 'Ø'
update PROD_QAD_ITEM_EXTRACT_FI1010 set DESC1=replace(DESC1,'�','Ø') where DESC1 like '%�%';--284 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI1010 set DESC2=replace(DESC2,'�','Ø') where DESC2 like '%�%';--79 rows updated.
commit;
--FR1010 '�' will be replaced with 'Ø' & 'š' will be replaced with 'è'
update PROD_QAD_ITEM_EXTRACT_FR1010 set DESC1=replace(DESC1,'�','Ø') where DESC1 like '%�%';--2,100 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR1010 set DESC2=replace(DESC2,'�','Ø') where DESC2 like '%�%';--326 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR1010 set DESC1=replace(DESC1,'š','è') where lower(DESC1) like '%š%';--10 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR1010 set DESC2=replace(DESC2,'š','è') where lower(DESC2) like '%š%';--3 rows updated.
commit;
--FR2010 '�' will be replaced with 'Ø' & 'š' will be replaced with 'è'
update PROD_QAD_ITEM_EXTRACT_FR2010 set DESC1=replace(DESC1,'�','Ø') where DESC1 like '%�%';--2,561 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR2010 set DESC2=replace(DESC2,'�','Ø') where DESC2 like '%�%';--5,417 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR2010 set DESC1=replace(DESC1,'š','è') where lower(DESC1) like '%š%';--117 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR2010 set DESC2=replace(DESC2,'š','è') where lower(DESC2) like '%š%';--19 rows updated.
commit;
*/
--BOM TABLE SPECIAL CHARACTER ISSUE
--==================================
--There is no special character issue this time.....

--============CHECKING SITE DETAILS IN ITEM TABLES=====================
--"Site" column has the Site information
select distinct "Site" from PROD_QAD_ITEM_EXTRACT_FI1010;
select distinct "Site" from PROD_QAD_ITEM_EXTRACT_FR1010;
select distinct "Site" from PROD_QAD_ITEM_EXTRACT_FR2010;

update PROD_QAD_ITEM_EXTRACT_FI1010 set item_number=trim(item_number),"Site"=upper("Site");--63,179 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR1010 set item_number=trim(item_number),"Site"=upper("Site");--62,049 rows updated.
update PROD_QAD_ITEM_EXTRACT_FR2010 set item_number=trim(item_number),"Site"=upper("Site");--453,247 rows updated.
commit;

--===================ADDING SITE DETAILS IN BOM TABLES=====================
update PROD_QAD_BOM_EXTRACT_FI1010 set PARENT_ITEM=trim(PARENT_ITEM),COMPONENT_ITEM=trim(COMPONENT_ITEM);--223,117 rows updated.
update PROD_QAD_BOM_EXTRACT_FR1010 set PARENT_ITEM=trim(PARENT_ITEM),COMPONENT_ITEM=trim(COMPONENT_ITEM);--296,602 rows updated.
update PROD_QAD_BOM_EXTRACT_FR2010 set PARENT_ITEM=trim(PARENT_ITEM),COMPONENT_ITEM=trim(COMPONENT_ITEM);--1,936,882 rows updated.
commit;

alter table PROD_QAD_BOM_EXTRACT_FI1010 add ("Site" varchar2(20) DEFAULT 'FI1010');
alter table PROD_QAD_BOM_EXTRACT_FR1010 add ("Site" varchar2(20) DEFAULT 'FR1010');
alter table PROD_QAD_BOM_EXTRACT_FR2010 add ("Site" varchar2(20) DEFAULT 'FR2010');
commit;

--MAP L1,L2,L3 FROM PREVIOUS DATASET
--===================================
--DRESS REHEARSAL DATA ITEM TABLE -- PART WISE L1,L2,L3 AVAILABLE
select * from DR_QAD_ITEM_EXTRACT_FI_FR;

--CLASSIF ATTRIBUTES TABLE TILL DRESS REHEARSAL
select * from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL;--432986  Rows

--CREATE TABLE FOR ITEM & BOM ALL SITES TOGETHER
--=================================================
create table PROD_QAD_ITEM_EXTRACT_FI_FR as
select * from PROD_QAD_ITEM_EXTRACT_FI1010 union--63179  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR1010 union--62049  Rows
select * from PROD_QAD_ITEM_EXTRACT_FR2010;--453247  Rows

select * from PROD_QAD_ITEM_EXTRACT_FI_FR;--578475  Rows

create table PROD_QAD_BOM_EXTRACT_FI_FR as
select * from PROD_QAD_BOM_EXTRACT_FI1010 union--223117  Rows
select * from PROD_QAD_BOM_EXTRACT_FR1010 union--296602  Rows
select * from PROD_QAD_BOM_EXTRACT_FR2010;--1936882  Rows

select * from PROD_QAD_BOM_EXTRACT_FI_FR;--2456601  Rows

--ADDING DELTA_PART,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3 FROM PREV DATA
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add(DELTA_PART varchar2(20),
CLASSIF_LEVEL_1 varchar2(128),CLASSIF_LEVEL_2 varchar2(128),CLASSIF_LEVEL_3 varchar2(128));

--DELTA PART IDENTIFY
update PROD_QAD_ITEM_EXTRACT_FI_FR set DELTA_PART='Yes' where trim(upper(ITEM_NUMBER)) in (
select trim(upper(ITEM_NUMBER)) from PROD_QAD_ITEM_EXTRACT_FI_FR minus
select trim(upper(ITEM_NUMBER)) from DR_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes');--5,417 rows updated.
commit;

select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes';--5417  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART is null;--573058  Rows

--MERGE L1,L2,L3 BASED ON PREV EXTRACTED DATA --'FI1010','FR1010','FR2010'
merge into PROD_QAD_ITEM_EXTRACT_FI_FR a
using (select * from DR_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes')b
on (a.ITEM_NUMBER=b.ITEM_NUMBER) when matched then update set a.CLASSIF_LEVEL_1=b.CLASSIF_LEVEL_1,
a.CLASSIF_LEVEL_2=b.CLASSIF_LEVEL_2,a.CLASSIF_LEVEL_3=b.CLASSIF_LEVEL_3;--573,057 rows merged.
commit;

--VALIDATING L1,L2,L3
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CLASSIF_LEVEL_1='null' OR CLASSIF_LEVEL_2='null'
OR CLASSIF_LEVEL_3='null';--no rows

--DUPLICATE PART IDENTIFY
--MARK ONLY CONSIDERABLE PARTS
select * from PROD_QAD_ITEM_EXTRACT_FI_FR;--578475  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where ITEM_NUMBER is null;--1 Row
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add(CONSIDER varchar2(20));

update PROD_QAD_ITEM_EXTRACT_FI_FR set CONSIDER='Yes' where ITEM_NUMBER not in(
select ITEM_NUMBER from PROD_QAD_ITEM_EXTRACT_FI_FR group by ITEM_NUMBER having count(*)>1)--1 Duplicate
and ITEM_NUMBER is not null;--578,472 rows updated.
commit;

--PARTS WHICH ARE ALREADY CONSIDERED IN PL,NL,GE
--COMMON DATA BETWEEN FRANCE AND NETHERLAND POLAND
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where ITEM_NUMBER in (
select ITEM_NUMBER from PROD_QAD_ITEM_EXTRACT_GE_NL_PL where CONSIDER='Yes');

update PROD_QAD_ITEM_EXTRACT_FI_FR set DELTA_PART=null,CONSIDER='No' where ITEM_NUMBER in (
select ITEM_NUMBER from PROD_QAD_ITEM_EXTRACT_GE_NL_PL where CONSIDER='Yes');--5 rows updated.
commit;

--CONSIDERED BASED ON DECISION MANUALLY
/*
-- valconf already considered in GE,NL,PL.. will not be considered again
FR1010	VALEU	valconf
FI1010	VALFI	valconf
*/
select distinct CONSIDER from PROD_QAD_ITEM_EXTRACT_FI_FR;
update PROD_QAD_ITEM_EXTRACT_FI_FR set CONSIDER='No' where ITEM_NUMBER is null;--1 row updated.
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes';--578469  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='No';--6  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes';--5412  Rows / FINAL DELTA COUNT

--ALL PARENT AND CHILD PRESENT IN BOM ARE PRESENT IN ITEM TABLE ALSO... VERIFYING
select * from PROD_QAD_BOM_EXTRACT_FI_FR where trim(upper(COMPONENT_ITEM)) not in
(select trim(upper(ITEM_NUMBER)) from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes');
--44  Rows (NOT PRESENT IN ITEM TABLE)
select * from PROD_QAD_BOM_EXTRACT_FI_FR where trim(upper(PARENT_ITEM)) not in
(select trim(upper(ITEM_NUMBER)) from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes');
--ALL PARENT ITEM IS PRESENT

--BUG WAS RAISED DUE TO NON UTF CHARACTER --164357KXXX
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where ITEM_NUMBER='164357KXXX';--GOOD NOW

--NEED TO RUN CLASSIFICATION SCRIPT ON DELTA DATA
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes';--5412  Rows
