--CLASSIF ATTR FOR FR,FI
--CLASSIF ATTRIBUTE EXTRACTION ON DELTA PARTS
--==========================================================================
select * from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL;--432986  Rows / TILL DRESS REHEARSAL DATA

select ITEM_NUMBER,count(*) from (
select distinct ITEM_NUMBER,"Site" from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL)
group by ITEM_NUMBER having count(*)>1;--no duplicate in item_number

--AFTER RUNNING FREDRIC'S SCRIPT ROWS WILL BE ADDED TO THIS TABLE
--FOR FREDRIC'S SCRIPT SOME TABLES REQUIRED
create table rh1_qad_item_extract_with_classification_bkp_20_JULY as select * from rh1_qad_item_extract_with_classification;
create table rh1_qad_item_extract_classif_attributes_bkp_20_JULY as select * from rh1_qad_item_extract_classif_attributes;
drop table rh1_qad_item_extract_with_classification;
drop table rh1_qad_item_extract_classif_attributes;
drop table rh1_qad_bom_extract_with_classification;

create table rh1_qad_item_extract_with_classification as
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes' and CONSIDER='Yes';--5412  Rows
create table rh1_qad_bom_extract_with_classification as select * from PROD_QAD_BOM_EXTRACT_FI_FR;

--AFTER FREDRIC'S SCRIPT EXTRACTED ATTRIBUTES
--============================================
select "Site",count(*) from rh1_qad_item_extract_with_classification group by "Site";
--FR2010 - 4227, FR1010 - 344, FI1010 - 841
select "Site",count(*) from rh1_qad_item_extract_classif_attributes group by "Site";
--FR2010 - 3618

create table PROD_QAD_ITEM_EXTRACT_FI_FR_DELTA as
select * from rh1_qad_item_extract_with_classification;--5412  Rows
create table PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA as
select * from rh1_qad_item_extract_classif_attributes;--3618  Rows

select distinct "Site" from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--FR2010

--MERGE L1,L2,L3 FOR DELTA DATA TO ITEM TABLE
--==============================================
select * from PROD_QAD_ITEM_EXTRACT_FI_FR;--578475  Rows

merge into PROD_QAD_ITEM_EXTRACT_FI_FR a
using (select * from PROD_QAD_ITEM_EXTRACT_FI_FR_DELTA)b
on (a.ITEM_NUMBER=b.ITEM_NUMBER) when matched then update set a.CLASSIF_LEVEL_1=b.CLASSIF_LEVEL_1,
a.CLASSIF_LEVEL_2=b.CLASSIF_LEVEL_2,a.CLASSIF_LEVEL_3=b.CLASSIF_LEVEL_3;--5,412 rows merged.
commit;

--UPDATE PART_TYPE IN ITEM TABLE
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add(PART_TYPE varchar2(128));

update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_TYPE=null;
update PROD_QAD_ITEM_EXTRACT_FI_FR set
PART_TYPE='com.ptcmscloud.RawMaterialPart' where CLASSIF_LEVEL_1='Raw Material';--1,175 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set
PART_TYPE='com.ptcmscloud.Hardware' where CLASSIF_LEVEL_1='Hardware';--5,646 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set
PART_TYPE='com.ptcmscloud.StructuralPart' where part_type is null;--571,654 rows updated.
commit;

--MERGING CLASSIF ATTRIBUTES TABLE
--==================================
select * from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL;--PREVOUS DATA(ALREADY TRANSFORMED)
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--New data

--CLASSIFICATION L1,L2,L3 CORRECTION BOTH TABLE ITEM & CLASSIF
update PROD_QAD_ITEM_EXTRACT_FI_FR set CLASSIF_LEVEL_3='Davit / Bent arm (EMEA)'
where CLASSIF_LEVEL_1='Assembly' and CLASSIF_LEVEL_2='Arm - Lighting' and CLASSIF_LEVEL_3='Davit / Bent Pole (EMEA)';
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set CLASSIF_LEVEL_3='Antenna support arm'
where CLASSIF_LEVEL_1='Assembly' and CLASSIF_LEVEL_2='Arm - Antenna' and CLASSIF_LEVEL_3='Antenna support';
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set CLASSIF_LEVEL_2='Connection Piece'
where CLASSIF_LEVEL_1='Piece Part' and CLASSIF_LEVEL_2='Connection Part' and CLASSIF_LEVEL_3='Clamp Ear';
--0 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set CLASSIF_LEVEL_3='Davit / Bent arm (EMEA)'
where CLASSIF_LEVEL_1='Assembly' and CLASSIF_LEVEL_2='Arm - Lighting' and CLASSIF_LEVEL_3='Davit / Bent Pole (EMEA)';
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set CLASSIF_LEVEL_3='Antenna support arm'
where CLASSIF_LEVEL_1='Assembly' and CLASSIF_LEVEL_2='Arm - Antenna' and CLASSIF_LEVEL_3='Antenna support';
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set CLASSIF_LEVEL_2='Connection Piece'
where CLASSIF_LEVEL_1='Piece Part' and CLASSIF_LEVEL_2='Connection Part' and CLASSIF_LEVEL_3='Clamp Ear';
--0 rows updated.
commit;

--ADDING CLASSIFICATION_NODE,ATTR_INTERNAL_NAME,DATATYPE,UNIT
--AND COMPARE WITH LOV WHERE REQUIRED
--============================================================
--CLASSIFICATION_STRUCTURAL_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS
--CLASSIFICATION_RAW_HARDWARE_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS
--CLASSIFICATION_NODE_INTERNAL_NAME_ALL_PARTTYPE
--CLASSIFICATION_NODE_ATTRIBUTES_LOV
--STAGED ON 3RD MAY
select * from CLASSIFICATION_NODE_INTERNAL_NAME_ALL_PARTTYPE;--247  Rows
select * from CLASSIFICATION_STRUCTURAL_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS;--830  Rows
select * from CLASSIFICATION_RAW_HARDWARE_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS;--92  Rows
select * from CLASSIFICATION_NODE_ATTRIBUTES_LOV;--1972  Rows

--ITEM TABLE CLASSIFICATION_NODE ADD
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add(CLASSIFICATION_NODE varchar2(128));

merge into PROD_QAD_ITEM_EXTRACT_FI_FR a
using(select * from CLASSIFICATION_NODE_INTERNAL_NAME_ALL_PARTTYPE)b
on(upper(trim(a.CLASSIF_LEVEL_1)||trim(a.CLASSIF_LEVEL_2)||trim(a.CLASSIF_LEVEL_3))=
upper(trim(b.CLASSIF_LEVEL_1)||trim(b.CLASSIF_LEVEL_2)||trim(b.CLASSIF_LEVEL_3)))
when matched then update set a.CLASSIFICATION_NODE=b.CLASSIFICATION_INTERNAL_NODE;--368,834 rows merged.
commit;

select* from PROD_QAD_ITEM_EXTRACT_FI_FR where CLASSIFICATION_NODE is null and CLASSIF_LEVEL_1 is not null;--12542  Rows
select distinct CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3 from PROD_QAD_ITEM_EXTRACT_FI_FR
where CLASSIFICATION_NODE is null and CLASSIF_LEVEL_1 is not null;--5 combination //Detailed is given below
/*
Assembly	Arm - Utility Distribution	C-Bracket connection -> INVALID
Assembly	Pole - Utility Transmission - Non Tapered	Lattice -> INVALID
Assembly	Bus Charging	Contact Hood -> INVALID (Not a good L1,L2,L3)
Field Assembly	Lighting	Decorative -> INVALID
Field Assembly	Lighting	Handhole / Door Assembly -> INVALID
*/

--CLASSIFICATION_NODE,ATTR_INTERNAL_NAME & OTHER DETAILS ADD IN DELTA CLASSIF_ATTR TABLE
--PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA
select distinct ATTR_NAME from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;
delete from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where ATTR_NAME='UNUSED_TOKEN';--0 rows deleted.
commit;
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--3618  Rows

--VALIDATING L1,L2,L3 FOR ATTRIBUTE TABLE
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where CLASSIF_LEVEL_1='null' OR CLASSIF_LEVEL_2='null'
OR CLASSIF_LEVEL_3='null';--No  Rows
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set CLASSIF_LEVEL_3=null
where CLASSIF_LEVEL_3='null';--0 rows updated.
commit;

alter table PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA add(CLASSIFICATION_NODE varchar2(128),
ATTR_INTERNAL_NAME varchar2(128),DATATYPE varchar2(128),UNIT varchar2(20),LOV_STATUS varchar2(20),LOV_VALUES varchar2(1000),
FINAL_ATTR_VALUE varchar2(128),LOV_MATCHED varchar2(128),FINAL_ATTR_VALUE_MIG varchar2(128));

--ATTRIBUTE TABLE CLASSIFICATION_NODE ADD
merge into PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA a
using(select * from CLASSIFICATION_NODE_INTERNAL_NAME_ALL_PARTTYPE)b
on(upper(trim(a.PART_TYPE)||trim(a.CLASSIF_LEVEL_1)||trim(a.CLASSIF_LEVEL_2)||trim(a.CLASSIF_LEVEL_3))=
upper(trim(b.PART_TYPE)||trim(b.CLASSIF_LEVEL_1)||trim(b.CLASSIF_LEVEL_2)||trim(b.CLASSIF_LEVEL_3)))
when matched then update set a.CLASSIFICATION_NODE=b.CLASSIFICATION_INTERNAL_NODE;--3,618 rows merged.
commit;

--SOME ATTR_NAME WILL BE CHANGED ACCRODING TO THE ATTR_NAME AVAILABLE
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Type of Grating' where classif_level_1='Assembly' and classif_level_2='Access' and classif_level_3='Grating' and attr_name='Type';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Tube diameter' where classif_level_1='Assembly' and classif_level_2='Bracket / Crossarm' and classif_level_3='Clamp' and attr_name='Diameter';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Type of Crossbar' where classif_level_1='Assembly' and classif_level_2='Bracket / Crossarm' and classif_level_3='Crossbar' and attr_name='Type';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Diameter at base' where classif_level_1='Field Assembly' and classif_level_2='Lighting' and classif_level_3='Straight Pole' and attr_name='Dimaeter as base';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Diameter at base' where classif_level_1='Field Assembly' and classif_level_2='Lighting' and classif_level_3='Straight Pole' and attr_name='Diameter as base';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Type of Nut Covers' where classif_level_1='Piece Part' and classif_level_2='Cap' and classif_level_3='Nut Covers' and attr_name='Type';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Type of Cable' where classif_level_1='Piece Part' and classif_level_2='Mechanical' and classif_level_3='Cable' and attr_name='Type';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Diameter' where classif_level_1='Piece Part' and classif_level_2='Pole Top' and classif_level_3='Lightning Protection' and attr_name='Bolt Diameter';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Length' where classif_level_1='Piece Part' and classif_level_2='Pole Top' and classif_level_3='Lightning Protection' and attr_name='Bolt Length';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Bolt hole qty' where classif_level_1='Piece Part' and classif_level_2='Template' and classif_level_3='Anchor Bolt Template' and attr_name='BoltHoleQty';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Hole Pattern' where classif_level_1='Piece Part' and classif_level_2='Template' and classif_level_3='Anchor Bolt Template' and attr_name='HolePattern';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Hole size' where classif_level_1='Piece Part' and classif_level_2='Template' and classif_level_3='Anchor Bolt Template' and attr_name='HoleSize';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Type of Tenon Assembly' where classif_level_1='Sub-Assembly' and classif_level_2='Pole Top' and classif_level_3='Tenon Assembly' and attr_name='Type';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Free text' where classif_level_1='Piece Part' and classif_level_2='Tag' and classif_level_3='Decals' and attr_name='Product Name';
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set ATTR_NAME='Side Length' where classif_level_1='Piece Part' and classif_level_2='Gusset' and classif_level_3='Corner' and attr_name='Length';
commit;

--STRUCTURAL PART ATTR MERGED
merge into PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA a
using(select * from CLASSIFICATION_STRUCTURAL_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS)b
on(upper(trim(a.PART_TYPE)||trim(a.CLASSIFICATION_NODE)||trim(a.ATTR_NAME))=
upper(trim(b.PART_TYPE)||trim(b.L3_INTERNAL_NAME)||trim(b.ATTRIBUTE_DISPLAY_NAME)))
when matched then update set a.ATTR_INTERNAL_NAME=b.FINAL_ATTR_INTERNAL_NAME,
a.DATATYPE=b.DATATYPE,a.LOV_STATUS=b.LOV_STATUS,a.UNIT=b.UNIT,a.LOV_VALUES=b.LOV_VALUES;--3,567 rows merged.
commit;

--RAW MATERIAL & HARDWARE PART ATTR MERGED
merge into PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA a
using(select * from CLASSIFICATION_RAW_HARDWARE_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS)b
on(upper(trim(a.PART_TYPE)||trim(a.CLASSIFICATION_NODE)||trim(a.ATTR_NAME))=
upper(trim(b.PART_TYPE)||trim(b.L2_INTERNAL_NAME)||trim(b.ATTRIBUTE_DISPLAY_NAME)))
when matched then update set a.ATTR_INTERNAL_NAME=b.FINAL_ATTR_INTERNAL_NAME,
a.DATATYPE=b.DATATYPE,a.LOV_STATUS=b.LOV_STATUS,a.UNIT=b.UNIT,a.LOV_VALUES=b.LOV_VALUES;--0 rows merged.
commit;

select distinct CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,ATTR_NAME from
PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where ATTR_INTERNAL_NAME is null;
--Assembly	Pole - Lighting	Non-Tapered	Top Diameter (Top Diameter values already in Bottom Diameter).
delete from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where ATTR_INTERNAL_NAME is null;--51 rows deleted.
commit;

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--NEW DATA / 3567  Rows
select * from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL;--OLD DATA TILL DR / 432986  Rows

--LOV MATCHING - For the attributes where value is not matching with lov mark a flag
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where LOV_STATUS='Yes';--1431  Rows

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set LOV_MATCHED='Yes' where 
(CLASSIFICATION_NODE||ATTR_INTERNAL_NAME||upper(ATTR_VALUE)) in (select CLASSIFICATION_NODE||
ATTR_INTERNAL_NAME||upper(LOV_VALUES) from CLASSIFICATION_NODE_ATTRIBUTES_LOV) and
LOV_STATUS='Yes';--768 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set LOV_MATCHED='No' where 
(CLASSIFICATION_NODE||ATTR_INTERNAL_NAME||upper(ATTR_VALUE)) not in (select CLASSIFICATION_NODE||
ATTR_INTERNAL_NAME||upper(LOV_VALUES) from CLASSIFICATION_NODE_ATTRIBUTES_LOV) and
LOV_STATUS='Yes';--663 rows updated.
commit;

--POPULATING FINAL_ATTR_VALUE
--==============================
--STRINGVALUE FIXED
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=ATTR_VALUE
where DATATYPE='java.lang.String' and LOV_STATUS='Yes' and LOV_MATCHED='Yes';--768 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=ATTR_VALUE
where DATATYPE='java.lang.String' and LOV_STATUS='No';--0 rows updated. / WHERE LOV NOT REQUIRED
commit;

--FIXING THE VALUES WHERE LOV NOT MATCHED
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where LOV_MATCHED='No';--663  Rows
select distinct CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,ATTR_NAME,ATTR_VALUE
from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where LOV_MATCHED='No';
/*
ALL DECISIONS GOT FROM BUSINESS
Assembly	Pole - Lighting	Non-Fluted Tapered / Tapered (EMEA)	Shape	Round tapered -> Circular
Assembly	Pole - Lighting	Non-Tapered	Shape	Tubular -> Circular
Assembly	Pole - Lighting	Stepped Non-Tapered / Stepped (EMEA)	Finish	G -> Galvanized
Assembly	Pole - Lighting	Stepped Non-Tapered / Stepped (EMEA)	Finish	B -> Black
Assembly	Pole - Lighting	Stepped Non-Tapered / Stepped (EMEA)	Shape	PERCAGE -> Exclude
*/
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE='Circular' where CLASSIF_LEVEL_1='Assembly'
and CLASSIF_LEVEL_2='Pole - Lighting' and CLASSIF_LEVEL_3='Non-Fluted Tapered / Tapered (EMEA)'
and ATTR_NAME='Shape' and ATTR_VALUE='Round tapered';--579 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE='Circular' where CLASSIF_LEVEL_1='Assembly'
and CLASSIF_LEVEL_2='Pole - Lighting' and CLASSIF_LEVEL_3='Non-Tapered'
and ATTR_NAME='Shape' and ATTR_VALUE='Tubular';--51 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE='Galvanized' where CLASSIF_LEVEL_1='Assembly'
and CLASSIF_LEVEL_2='Pole - Lighting' and CLASSIF_LEVEL_3='Stepped Non-Tapered / Stepped (EMEA)'
and ATTR_NAME='Finish' and ATTR_VALUE='G';--26 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE='Black' where CLASSIF_LEVEL_1='Assembly'
and CLASSIF_LEVEL_2='Pole - Lighting' and CLASSIF_LEVEL_3='Stepped Non-Tapered / Stepped (EMEA)'
and ATTR_NAME='Finish' and ATTR_VALUE='B';--4 rows updated.

delete from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where CLASSIF_LEVEL_1='Assembly'
and CLASSIF_LEVEL_2='Pole - Lighting' and CLASSIF_LEVEL_3='Stepped Non-Tapered / Stepped (EMEA)'
and ATTR_NAME='Shape' and ATTR_VALUE='PERCAGE';--3 rows deleted.
commit;

--ALL THE VALUES WITH STRING LOV ARE MATCHING NOW
--FINAL ATTR VALUE POPULATED & LOV_STATUS='No' VALUE CORRECTED / RE-CHECKING ON FINAL_ATTR_VALUE
--===============================================================================================
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set LOV_MATCHED='Yes' where 
(CLASSIFICATION_NODE||ATTR_INTERNAL_NAME||upper(FINAL_ATTR_VALUE)) in (select CLASSIFICATION_NODE||
ATTR_INTERNAL_NAME||upper(LOV_VALUES) from CLASSIFICATION_NODE_ATTRIBUTES_LOV) and
LOV_STATUS='Yes';--1,428 rows updated.
commit;

--INTEGERVALUE FIXED
select distinct ATTR_VALUE from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA
where DATATYPE='java.lang.Long' and FINAL_ATTR_VALUE is null;--No values
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=ATTR_VALUE
where DATATYPE='java.lang.Long';--0 rows updated.
commit;

--FLOATINGPOINTWITHUNITS FIXED
select DATATYPE,count(*) from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA group by DATATYPE;
select distinct ATTR_VALUE from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA
where DATATYPE='wt.units.FloatingPointWithUnits' and FINAL_ATTR_VALUE is null;

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=ATTR_VALUE||'.0'
where DATATYPE='wt.units.FloatingPointWithUnits' and regexp_like(ATTR_VALUE,'^\d{1,}$');--2,136 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=ATTR_VALUE
where DATATYPE='wt.units.FloatingPointWithUnits' and regexp_like(ATTR_VALUE,'^\d{1,}[.]\d{1,}$');--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=replace(upper(ATTR_VALUE),'X','.')
where DATATYPE='wt.units.FloatingPointWithUnits' and regexp_like(ATTR_VALUE,'^\d{1,}[X]\d{1,}$');--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=replace(upper(ATTR_VALUE),'ST','')||'.0'
where DATATYPE='wt.units.FloatingPointWithUnits' and upper(ATTR_VALUE) like 'ST%';--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=replace(upper(ATTR_VALUE),'STC','')||'.0'
where DATATYPE='wt.units.FloatingPointWithUnits' and upper(ATTR_VALUE) like 'STC%';--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=replace(upper(ATTR_VALUE),'FI','')||'.0'
where DATATYPE='wt.units.FloatingPointWithUnits' and upper(ATTR_VALUE) like 'FI%';--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE=replace(upper(ATTR_VALUE),'M','')||'.0'
where DATATYPE='wt.units.FloatingPointWithUnits' and upper(ATTR_VALUE) like 'M%';--0 rows updated.
commit;

select distinct FINAL_ATTR_VALUE from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA
where DATATYPE='wt.units.FloatingPointWithUnits' and not regexp_like(FINAL_ATTR_VALUE,'^\d{1,}[.]\d{1,}');--No values
--update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE='250.0'
--where FINAL_ATTR_VALUE='250/370.0';
--commit;

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where FINAL_ATTR_VALUE is null;--ALL FIXED

--POPULATING FINAL_ATTR_VALUE_MIG
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE_MIG=FINAL_ATTR_VALUE
where DATATYPE in ('java.lang.Long','java.lang.String');--1,428 rows updated.
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA set FINAL_ATTR_VALUE_MIG=
FINAL_ATTR_VALUE||'|'||length(substr(FINAL_ATTR_VALUE,instr(FINAL_ATTR_VALUE,'.',1,1)+1))||'|'||unit
where DATATYPE='wt.units.FloatingPointWithUnits';--2,136 rows updated.
commit;

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA where
DATATYPE='wt.units.FloatingPointWithUnits' and UNIT is null;--No rows, all good.

--MERGING DELTA CLASSIF ATTR DATA AND PREVIOUS REHEARSAL DATA ALL TOGETHER
--=========================================================================
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--3564  Rows
select * from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL;--432986  Rows

--MERGING ALL CLASSIF_ATTR DATA
create table PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL as
select "Site",ITEM_NUMBER,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,ATTR_NAME,ATTR_VALUE,
PART_TYPE,TS,REF_SCRIPT,EMEA_REQUIRED,CLASSIFICATION_NODE,ATTR_INTERNAL_NAME,DATATYPE,UNIT,LOV_STATUS,FINAL_ATTR_VALUE,
LOV_MATCHED,FINAL_ATTR_VALUE_MIG from DR_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_TILL_8_JUNE_FINAL --432986  Rows
union
select "Site",ITEM_NUMBER,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,ATTR_NAME,ATTR_VALUE,
PART_TYPE,TS,REF_SCRIPT,EMEA_REQUIRED,CLASSIFICATION_NODE,ATTR_INTERNAL_NAME,DATATYPE,UNIT,LOV_STATUS,FINAL_ATTR_VALUE,
LOV_MATCHED,FINAL_ATTR_VALUE_MIG from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_DELTA;--3564  Rows
--436550  Rows

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL;--436550  Rows

--CHECKING PART_TYPE FROM ITEM TABLE & ATTRIBUTE TABLE
select PART_TYPE,CLASSIF_LEVEL_1,count(*) from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL
group by PART_TYPE,CLASSIF_LEVEL_1;--ALL GOOD
select PART_TYPE,CLASSIF_LEVEL_1,count(*) from PROD_QAD_ITEM_EXTRACT_FI_FR
group by PART_TYPE,CLASSIF_LEVEL_1;--ALL GOOD

--VERIFYING ATTRIBUTE TABLE L1,L2,L3 SAME WITH ITEM TABLE L1,L2,L3
select distinct ITEM_NUMBER,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3 from
PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL;--91437  Rows

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL where 
(ITEM_NUMBER,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3) not in 
(select distinct ITEM_NUMBER,CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3 from PROD_QAD_ITEM_EXTRACT_FI_FR);--NO VALUES
--ALL CLASSIFICATION W.R.T PART NUMBER IS MATCHING WITH ATTRIBUTE TABLE

select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes';--578469  Rows
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL;--436550  Rows

--LOV INTERNAL NAME POPULATE, AND DESC1 & DESC2 POPULATE
alter table PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL add(
LOV_INTERNAL_NAME varchar2(50),DESC1 varchar2(200),DESC2 varchar2(200),PART_REV varchar2(20));

--DESC1 & DESC2 POPULATE
merge into PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL a
using (select * from PROD_QAD_ITEM_EXTRACT_FI_FR where consider='Yes')b
on (a.ITEM_NUMBER=b.ITEM_NUMBER) when matched then update set a.DESC1=b.DESC1,a.DESC2=b.DESC2;
--436,550 rows merged.
commit;

--LOV_INTERNAL_NAME POPULATE
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL where LOV_STATUS='Yes';--176972  Rows

merge into PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL a
using (select * from CLASSIFICATION_NODE_ATTRIBUTES_LOV)b
on (a.CLASSIFICATION_NODE||a.ATTR_INTERNAL_NAME||trim(upper(a.FINAL_ATTR_VALUE))
=b.CLASSIFICATION_NODE||b.ATTR_INTERNAL_NAME||trim(upper(b.LOV_VALUES)))
when matched then update set a.LOV_INTERNAL_NAME=b.LOV_INTERNAL_NAME;--176,972 rows merged.
commit;

--POPULATING FINAL_ATTR_VALUE_MIG -- WHERE LOV_STATUS='Yes' WILL BE LOV_INTERNAL_NAME
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL set FINAL_ATTR_VALUE_MIG=FINAL_ATTR_VALUE
where DATATYPE in ('java.lang.Long','java.lang.String') and LOV_STATUS='No';--2,166 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL set FINAL_ATTR_VALUE_MIG=
FINAL_ATTR_VALUE||'|'||length(substr(FINAL_ATTR_VALUE,instr(FINAL_ATTR_VALUE,'.',1,1)+1))||'|'||unit
where DATATYPE='wt.units.FloatingPointWithUnits';--257,412 rows updated.

update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL set FINAL_ATTR_VALUE_MIG=LOV_INTERNAL_NAME
where LOV_STATUS='Yes';--176,972 rows updated.
commit;

select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL;

--NOW CHECKING WHERE ATTR VALUE IS MORE THAN 70 M ON WHOLE SET OF DATA --as m
select distinct CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,upper(ATTR_NAME),count(*)
from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL where to_number(final_attr_value)>50 and
unit='m' group by CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,upper(ATTR_NAME);
/*
Assembly	Pole - Lighting	Non-Fluted Tapered / Tapered (EMEA)	HEIGHT	648
Assembly	Pole - Lighting	Stepped Non-Tapered / Stepped (EMEA)	HEIGHT	30
*/--TOTAL ROWS AFFECTED = 678

select distinct CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,upper(ATTR_NAME),count(*)
from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL where (to_number(final_attr_value)/1000)>50 and
unit='mm' group by CLASSIF_LEVEL_1,CLASSIF_LEVEL_2,CLASSIF_LEVEL_3,upper(ATTR_NAME);--FOR MM ALL GOOD

select distinct to_number(FINAL_ATTR_VALUE) from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL where
to_number(final_attr_value)>50 and unit='m';--FOR ALL THESE BIG VALUES NEEE TO CHANGE UNIT - TO MM

--CHANGING THEUNIT TO MM
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL set UNIT='mm'
where to_number(final_attr_value)>50 and unit='m';--678 rows updated.
commit;
--AFTER CHANGING UNIT
update PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL set FINAL_ATTR_VALUE_MIG=
FINAL_ATTR_VALUE||'|'||length(substr(FINAL_ATTR_VALUE,instr(FINAL_ATTR_VALUE,'.',1,1)+1))||'|'||unit
where DATATYPE='wt.units.FloatingPointWithUnits';--257,412 rows updated.
commit;--NO VALUES NOW / ALL GOOD

select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes' and CLASSIF_LEVEL_1 is not null;--2662  Rows
select * from PROD_QAD_ITEM_EXTRACT_CLASSIF_ATTRIBUTES_FI_FR_20_JULY_FINAL;--436550  Rows
--DELTA PART CLASSIFICATION POPULATED & ATTR TABLE TRANSFOMRED --ALL GOOD NOW
