select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes';--578469  Rows

--DUPLICATE PART IS PRESENT OR NOT
--ALREADY DONE IN SCRIPT NUMBER 1

--DATE FIXING
--=========================
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where substr(added_date,0,instr(added_date,'/',1)-1) is null;--'?' only

--CHECK DATE ARE NOT COMING IN 2099
select TO_TIMESTAMP(added_date,'MM-DD-YY HH24:MI:SS') from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in (
'FR1010','FR2010') and added_date<>'?';--done
select TO_TIMESTAMP(added_date,'DD-MM-YY HH24:MI:SS') from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site"='FI1010';--done

alter table PROD_QAD_ITEM_EXTRACT_FI_FR add DATE_TIMESTAMP_UPDATED TIMESTAMP WITH TIME ZONE;
update PROD_QAD_ITEM_EXTRACT_FI_FR set DATE_TIMESTAMP_UPDATED=TO_TIMESTAMP(added_date,'MM-DD-YY HH24:MI:SS')
where "Site" in ('FR1010','FR2010') and added_date<>'?';--515,295 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set DATE_TIMESTAMP_UPDATED=TO_TIMESTAMP(added_date,'DD-MM-YY HH24:MI:SS')
where "Site"='FI1010' and added_date<>'?';--63,179 rows updated.
commit;

--WHERE ADDED_DATE IS '?'
select TO_TIMESTAMP(current_date,'DD-MM-YY HH24:MI:SS') from dual;
update PROD_QAD_ITEM_EXTRACT_FI_FR set DATE_TIMESTAMP_UPDATED=TO_TIMESTAMP(current_date,'DD-MM-YY HH24:MI:SS')
where added_date='?';--1 rows updated.
commit;

select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes';--578469  Rows

--PART REVISION FIXING
--==========================
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add PART_REV varchar2(10);
--Revision Update for Plant FI1010 -- A
update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV='A' where "Site"='FI1010';--63,179 rows updated.
commit;

--FOR GE,NL,FR WHEREVER REVISION IS VALID, IT'S THE PART REVISION
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where regexp_like(upper(Revision),'^[A-Z]$')
and "Site" in ('FR1010','FR2010');--1786  Rows

update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV=upper(REVISION) where regexp_like(upper(Revision),'^[A-Z]$')
and "Site" in ('FR1010','FR2010');--1,786 rows updated.
commit;

--10-100-T/a,10-100-Ta,10-100-T
--FOR REMAINING DRAWINGS FOLLOW THESE PATTERNS ONLY
select drawing,revision,part_rev from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in('FR1010','FR2010')
and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]') and PART_REV is null;--1  Row  --8TH CHAR
select drawing,revision,part_rev from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in('FR1010','FR2010')
and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]{2}') and PART_REV is null;--no  Rows --9TH CHAR
select drawing,revision,part_rev from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in('FR1010','FR2010')
and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]/[A-Z]') and PART_REV is null;--no  Rows --10TH CHAR

select drawing,part_rev,substr(Upper(Drawing),10,1) from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]/[A-Z]') and PART_REV is null;
select drawing,part_rev,substr(Upper(Drawing),9,1) from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]{2}') and PART_REV is null;
select drawing,part_rev,substr(Upper(Drawing),8,1) from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]') and PART_REV is null;

update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV=substr(Upper(Drawing),10,1) where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]/[A-Z]') and PART_REV is null;
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV=substr(Upper(Drawing),9,1) where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]{2}') and PART_REV is null;
--0 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV=substr(Upper(Drawing),8,1) where "Site" in
('FR1010','FR2010')and regexp_like(Upper(Drawing),'^\d{2}-\d{3}-[A-Z]') and PART_REV is null;
--1 rows updated.
commit;

--FOR REMAINING PARTS REVISION WILL BE 'A' FOR FR
update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV='A' where "Site" in ('FR1010','FR2010')
and PART_REV is null;--513,509 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_REV=upper(PART_REV);
commit;
select * from PROD_QAD_ITEM_EXTRACT_FI_FR;

--PART_TYPE UPDATE
--DONE WHILE EXECUTING CLASSIFICATION DETAILS

--DELTA PARTS "Site" Wise
--DONE WHILE CLASSIFICATION
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where DELTA_PART='Yes';--5412  Rows

--PartType update on column TYPE / UPDATE PROCESS PART
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add TYPE varchar2(400);
select part_type,Type,count(*) from PROD_QAD_ITEM_EXTRACT_FI_FR group by part_type,Type;

update PROD_QAD_ITEM_EXTRACT_FI_FR set Type=
'wt.part.WTPart|com.ptcmscloud.IrrigationPart|com.ptcmscloud.DesignPart|com.ptcmscloud.RawMaterialPart'
where part_type='com.ptcmscloud.RawMaterialPart';--1,175 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set Type=
'wt.part.WTPart|com.ptcmscloud.IrrigationPart|com.ptcmscloud.DesignPart|com.ptcmscloud.Hardware'
where part_type='com.ptcmscloud.Hardware';--5,646 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set Type=
'wt.part.WTPart|com.ptcmscloud.IrrigationPart|com.ptcmscloud.DesignPart|com.ptcmscloud.StructuralPart'
where part_type='com.ptcmscloud.StructuralPart';--571,654 rows updated.
commit;

--FR LOGIC FOR PROCESS PART DEFINE / PROCESS PART UPDATE
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where "Site" in ('FR1010','FR2010')
and "Group" in ('12009999','12109999','12209999','12309999');--2023  Rows

update PROD_QAD_ITEM_EXTRACT_FI_FR set PART_TYPE='com.ptcmscloud.ProcesPart',
TYPE='wt.part.WTPart|com.ptcmscloud.IrrigationPart|com.ptcmscloud.ProcessPart|com.ptcmscloud.ProcesPart'
where "Site" in ('FR1010','FR2010') and "Group" in ('12009999','12109999','12209999','12309999');--2,023 rows updated.
commit;

select CLASSIF_LEVEL_1,PART_TYPE,TYPE,count(*) from PROD_QAD_ITEM_EXTRACT_FI_FR group by CLASSIF_LEVEL_1,PART_TYPE,TYPE;

--LIFECYCLESTATE UPDATE
--==========================
select distinct status from PROD_QAD_ITEM_EXTRACT_FI_FR;
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add (lifecyclestate varchar2(100));

update PROD_QAD_ITEM_EXTRACT_FI_FR set Lifecyclestate= case 
when status is null then 'Obsolete' 
when status='0' then 'Obsolete' 
when status='10' then 'INWORK' 
when status='20' then 'PROTOTYPE'
when status='30' then 'Released'
when status='31' then 'Released' 
when status='32' then 'Released' 
when status='33' then 'Released'
when status='34' then 'Released' 
when status='35' then 'Released' 
when status='36' then 'Released' 
when status='37' then 'Inwork' 
when status='40' then 'Inwork' 
when status='50' then 'DISCONTINUED'
when status='60' then 'OBSOLETE' 
when status='70' then 'DISCONTINUED' 
when status='80' then 'DISCONTINUED'
when status='change' then 'Inwork'
when status='CHANGE' then 'Inwork'
when status='28' then 'Released'
when status='38' then 'Released'
END;--578,475 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set Lifecyclestate=upper(Lifecyclestate);
commit;
select distinct Lifecyclestate from PROD_QAD_ITEM_EXTRACT_FI_FR;

--MASTERWBMID, WBMID ADDING
--===========================
alter table PROD_QAD_ITEM_EXTRACT_FI_FR add (MasterWBMId varchar2(20),WBMID varchar2(20));
--seq
create sequence PROD_MasterWBMSeq_FI_FR start with 1000000 increment by 1 NOCACHE NOCYCLE;
create sequence PROD_WBMSeq_FI_FR start with 2000000 increment by 1 NOCACHE NOCYCLE;

update PROD_QAD_ITEM_EXTRACT_FI_FR set MasterWBMId=PROD_MasterWBMSeq_FI_FR.nextval;--578,475 rows updated.
update PROD_QAD_ITEM_EXTRACT_FI_FR set WBMId=PROD_WBMSeq_FI_FR.nextval;--578,475 rows updated.
commit;
select * from PROD_QAD_ITEM_EXTRACT_FI_FR;

--UOM null fixed
--==================
select distinct UOM from PROD_QAD_ITEM_EXTRACT_FI_FR;
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where UOM is null;--no rows
--select * from PROD_QAD_ITEM_EXTRACT_FI_FR where item_number in ('218379MXXX','135371MSTX');--Belongs to Germany/NL

--CREATING WTPARTMASTER AND WTPART
--====================================
select * from wtpartmaster;
create table PROD_FI_FR_wtpartmaster as select * from wtpartmaster where 1=2;

insert INTO PROD_FI_FR_wtpartmaster(batch_id,Container,Containertype,CONTAINER_ORGANIZATION_NAME,CREATEDDATE,  
DEFAULTTRACECODE,DEFAULTUNIT,ENDITEM,GENERICTYPE,HIDEPARTINSTRUCTURE,MODIFIEDDATE,
NAME,OBJECTNUMBER,ORGANIZATION_NAME,PHANTOM,SERIES,WBMSOURCEDESCRIPTION,WBMSOURCEIDENTIFIER)
select '1' batch_id,
decode ("Site",'UK1010', 'EMEA UK',
               'GE1010', 'EMEA Germany', 
               'FR2010', 'EMEA France', 
               'NL1010', 'EMEA Netherlands', 
               'FR1010', 'EMEA France', 
               'PL1010', 'EMEA Poland', 
               'FI1010', 'EMEA Finland')Container, 
               'PRODUCT' Containertype, 'Valmont' CONTAINER_ORGANIZATION_NAME, 
				DATE_TIMESTAMP_UPDATED CREATEDDATE, 0 DEFAULTTRACECODE, upper(UOM) DEFAULTUNIT, 0 ENDITEM, 
                'standard' GENERICTYPE, 0 HIDEPARTINSTRUCTURE, DATE_TIMESTAMP_UPDATED MODIFIEDDATE,
                Desc1||' '||Desc2 NAME, ITEM_NUMBER OBJECTNUMBER, 'Valmont' ORGANIZATION_NAME, 0 PHANTOM,
                'wt.series.HarvardSeries.Valmont' SERIES, 'wt.part.WTPartMaster'||'_'||"Site"  WBMSOURCEDESCRIPTION, 
                MasterWBMID WBMSOURCEIDENTIFIER from PROD_QAD_ITEM_EXTRACT_FI_FR where consider='Yes';
--578,469 rows inserted..... as we removed duplicate(Consider flag selecting only unique ones)
commit;
select * from PROD_FI_FR_wtpartmaster;--578469  Rows
select OBJECTNUMBER,count(*) from PROD_FI_FR_wtpartmaster group by OBJECTNUMBER having count(*)>1;--should not be any value
select distinct DEFAULTUNIT from PROD_FI_FR_wtpartmaster;

select * from PROD_FI_FR_wtpartmaster where NAME=' ';--28  Rows
update PROD_FI_FR_wtpartmaster set NAME=OBJECTNUMBER where NAME=' ';--28 rows updated.
update PROD_FI_FR_wtpartmaster set NAME=trim(NAME);--578,469 rows updated / for removing extra spaces
commit;

--CREATING WTPART
--====================================
select * from wtpart;
create table PROD_FI_FR_wtpart as select * from wtpart where 1=2;

insert into PROD_FI_FR_wtpart(MASTERWBMSOURCEIDENTIFIER,REVISION,VIEWNAME,MAXIMUMALLOWED,MINIMUMREQUIRED,PARTTYPE,PHASE,
SOURCE,VALIDATEUSAGE,FOLDERPATH,ITERATION,ITERATIONNOTE,CREATEDBY,MODIFIEDBY,LIFECYCLE,LIFECYCLESTATE,CREATEDDATE,
MODIFIEDDATE,TEAM,TYPE,WBMSOURCEDESCRIPTION,WBMSOURCEIDENTIFIER)
select MasterWBMId,PART_REV,'Design',MAXIMUM_ORDER,MINIMUM_ORDER,'separable','PHASE',
'make','1','/Default/Design','1','ITERATIONNOTE','Administrator','Administrator','Valmont_EMEA_LC',LIFECYCLESTATE,
DATE_TIMESTAMP_UPDATED,DATE_TIMESTAMP_UPDATED,'Default',TYPE,'wt.part.WTPart_'||"Site",WBMID
from PROD_QAD_ITEM_EXTRACT_FI_FR where consider='Yes';--578,469 rows inserted.
commit;

select * from PROD_FI_FR_wtpartmaster;--578469  Rows
select * from PROD_FI_FR_wtpart;--578469  Rows
select * from PROD_QAD_ITEM_EXTRACT_FI_FR where CONSIDER='Yes';--578469  Rows
select * from PROD_QAD_BOM_EXTRACT_FI_FR;--2456601  Rows
