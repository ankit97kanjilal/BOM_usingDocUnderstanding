package ext.itc.test;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import com.ptc.core.businessfield.common.BusinessField;
import com.ptc.core.businessfield.common.BusinessFieldIdFactoryHelper;
import com.ptc.core.businessfield.common.BusinessFieldServiceHelper;
import com.ptc.core.businessfield.server.BusinessFieldIdentifier;
import com.ptc.core.businessfield.server.businessObject.BusinessObject;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelper;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelperFactory;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.ClientTypedUtility;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class AttributeValueChangeForWTPart02 implements RemoteAccess {
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		System.out.println("Enter: main method");
		Class[] argTypes = {};
		Object[] argObject = {};
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		rms.invoke("changeAttrValue", "ext.itc.test.AttributeValueChangeForWTPart02", null, argTypes,argObject);
		System.out.println(rms.getUserName());
	}
	
	public static void changeAttrValue() throws WTException, WTPropertyVetoException, IOException {
		QuerySpec query=new QuerySpec(WTPart.class);
		String partNumberToSearch="TESTPART1";
        SearchCondition searchCondition = new SearchCondition(WTPart.class,
                WTPart.NUMBER, SearchCondition.EQUAL, partNumberToSearch);
        query.appendWhere(searchCondition, new int[] {});
        QueryResult queryResult = PersistenceHelper.manager.find(query);
        
        while (queryResult.hasMoreElements()) {
        	WTPart p = (WTPart) queryResult.nextElement();
        	System.out.println("Part Number : " + p.getNumber());
        	System.out.println("Part Name : " + p.getName());
        	
        	final BusinessObjectHelper businessObjHelper = BusinessObjectHelperFactory.getBusinessObjectHelper();
        	Persistable[] persistables=new Persistable[]{p};
        	List<BusinessObject> busObjs = businessObjHelper.newBusinessObjects(SessionHelper.getLocale(),
        	        new DisplayOperationIdentifier(), false, persistables);        	
        	String partNumber=p.getNumber();
        	TypeIdentifier partTypeId = ClientTypedUtility.getTypeIdentifier(p);
        	String bindAttrName="partType";
        	String bindAttrName2="partType";
        	String bindAttrValue=null;
        	
        	Collection<BusinessField> busFields = Arrays.asList(
        			getTypeBusinessField(partTypeId.toString(),bindAttrName));
        	businessObjHelper.load(busObjs, busFields);
        	for (BusinessObject busObj : busObjs) {
        		for (BusinessField busField : busFields) {
        			if (busField!=null) {
        				System.out.println(busField.getName() + " attribute value : " + busObj.get(busField));
        				bindAttrValue=(String) busObj.get(busField);//getting the iba values
        			}
        		}
        	}
        	System.out.println("Attribute value for the part "+ partNumber + " is " + bindAttrValue);
        }
	}
	
	private static BusinessField getTypeBusinessField(final String type_name, final String attr_name)
			throws WTException {
	    BusinessFieldIdentifier bfid = BusinessFieldIdFactoryHelper.FACTORY.
	    		getTypeBusinessFieldIdentifier(attr_name, type_name);
	    return BusinessFieldServiceHelper.SERVICE.getBusinessField(bfid);
	}
}
