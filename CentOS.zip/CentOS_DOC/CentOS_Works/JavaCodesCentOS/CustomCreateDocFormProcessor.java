package ext.itc.test;

import java.util.List;

import com.ptc.core.components.beans.ObjectBean;
import com.ptc.core.components.forms.FormResult;
import com.ptc.netmarkets.util.beans.NmCommandBean;
import com.ptc.windchill.enterprise.doc.forms.CreateDocFormProcessor;

import wt.util.WTException;

public class CustomCreateDocFormProcessor extends CreateDocFormProcessor{
	@Override
	public FormResult doOperation(NmCommandBean commandBean, List<ObjectBean> objectBeanList) throws WTException {
		return super.doOperation(commandBean, objectBeanList);
	}
}
