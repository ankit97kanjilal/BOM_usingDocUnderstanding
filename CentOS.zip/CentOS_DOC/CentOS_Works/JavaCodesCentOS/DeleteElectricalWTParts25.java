package ext.itc.test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.ptc.core.meta.common.TypeIdentifier;

import wt.fc.ObjectReference;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.fc.ReferenceFactory;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartHelper;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.vc.config.LatestConfigSpec;

public class DeleteElectricalWTParts25 implements RemoteAccess {
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		System.out.println("Enter: main method");
		Class[] argTypes = {};
		Object[] argObject = {};
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		rms.invoke("listingElectricalWTParts", "ext.itc.test.DeleteElectricalWTParts25", null, argTypes,argObject);
		System.out.println("RMI username : " + rms.getUserName());
		System.out.println("RMI password : " + rms.getPassword());
	}
	
	public static void listingElectricalWTParts() throws WTException, IOException {
		QuerySpec querySpec=new QuerySpec(WTPart.class);
		TypeIdentifier typeCheck=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart|com.ptc.ElectricalPart");
		SearchCondition sc=TypedUtility.getSearchCondition(typeCheck, true);
		TypeIdentifier typeCheck2=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart");
		SearchCondition sc2=TypedUtility.getSearchCondition(typeCheck2, true);
		
		querySpec.appendWhere(sc,new int [] {});
		querySpec.appendOr();
		querySpec.appendWhere(sc2,new int[] {});
		QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        System.out.println("Query is : " + querySpec);
        Map<String,String> mapParts=new HashMap<>();//This map will store the Part Numbers
        
        while (queryResult.hasMoreElements()) {
        	WTPart p = (WTPart) queryResult.nextElement();
        	String partNumber=p.getNumber();
        	String partDisplayType=p.getDisplayType().getLocalizedMessage(null);
        	TypeIdentifier partTypeId = ClientTypedUtility.getTypeIdentifier(p);
        	if(partDisplayType.equals("Part") || partDisplayType.equals("Electrical Part")) {
        		mapParts.put(partNumber, partTypeId.toString());
        	}
        }
        deleteAllPartsFromMap(mapParts);
        writeOutputPartsGettingDeleted(mapParts);
	}

	private static void deleteAllPartsFromMap(Map<String, String> mapParts) throws WTException {
		for (Map.Entry<String,String> entry : mapParts.entrySet()) {
        	QuerySpec query=new QuerySpec(WTPart.class);
        	String partNumberToSearch=entry.getKey();
        	SearchCondition searchCondition = new SearchCondition(WTPart.class, WTPart.NUMBER,
        			SearchCondition.EQUAL, partNumberToSearch);
        	query.appendWhere(searchCondition, new int[] {});
        	QueryResult queryResult=PersistenceHelper.manager.find(query);        	
        	//If master part object is deleted all the other object links are getting deleted
        	while(queryResult.hasMoreElements()) {
        		WTPart p=(WTPart)queryResult.nextElement();
        		List<WTPart> childPartList=hasMoreChild(p);
        		System.out.println("Number of childs for PartNumber " + p.getNumber() + " : " + childPartList.size());
//        		if(childPartList.size()!=0) {
//        			for(WTPart childPart : childPartList) {
//        				
//        			}
//        		}
        		
        		
        	}
        	//deleteAllUsageLinks(partUsageLinks);
	    }
	}
	
	private static List<WTPart> hasMoreChild(wt.part.WTPart p) throws WTException {
		List<WTPart> childPartList=new ArrayList<>();
		QueryResult qr=WTPartHelper.service.getUsesWTParts(p, new LatestConfigSpec());
		while(qr.hasMoreElements()) {
			Persistable[] persistable=(Persistable[]) qr.nextElement();
			if(persistable[1] instanceof WTPart) {
				WTPart childPart=(WTPart) persistable[1];
				System.out.println("Child part : " + childPart.getNumber() + " Parent part : " + p.getNumber());
				childPartList.add(childPart);
			}
			if(persistable[0] instanceof WTPartUsageLink) {
				WTPartUsageLink childPartLink=(WTPartUsageLink) persistable[0];
				System.out.println("The UsageLink object is : " + childPartLink);
			}
		}
		return childPartList;
	}

	private static void deleteAllUsageLinks(ArrayList<WTPartUsageLink> partUsageLinks) throws WTException {
		for (WTPartUsageLink partUsageLink : partUsageLinks) {
			PersistenceHelper.manager.delete(partUsageLink);
		}
	}

	private static void writeOutputPartsGettingDeleted(Map<String, String> m1) throws IOException {
		String filePath="/appl/ptc/temp/DeletedPartList.csv";
		File file = new File(filePath);
		FileWriter fileWriter = new FileWriter(file);
        fileWriter.write("PartNumber" + "," + "FinalPartType");//header added
        fileWriter.append("\n");
        for (Map.Entry<String,String> entry : m1.entrySet()) {
        	fileWriter.write(entry.getKey() + "," + entry.getValue());
        	fileWriter.append("\n");
	    }
	    fileWriter.close();
	}
}
