package ext.itc.test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import com.ptc.core.meta.common.TypeIdentifier;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.folder.Folder;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.part.WTPartUsageLink;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;
import wt.vc.struct.StructHelper;
import wt.vc.wip.CheckoutLink;
import wt.vc.wip.WorkInProgressHelper;

public class DeleteElectricalWTPartsAndLinks04 implements RemoteAccess {
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		System.out.println("Enter: main method");
		Class[] argTypes = {};
		Object[] argObject = {};
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		rms.invoke("listingElectricalWTParts", "ext.itc.test.DeleteElectricalWTPartsAndLinks04", null, argTypes,argObject);
		System.out.println("RMI username : " + rms.getUserName());
		System.out.println("RMI password : " + rms.getPassword());
	}
	
	public static void listingElectricalWTParts() throws WTException, IOException, WTPropertyVetoException {
		QuerySpec querySpec=new QuerySpec(WTPart.class);
		TypeIdentifier typeCheck=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart|com.ptc.ElectricalPart");
		SearchCondition sc=TypedUtility.getSearchCondition(typeCheck, true);
		TypeIdentifier typeCheck2=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart");
		SearchCondition sc2=TypedUtility.getSearchCondition(typeCheck2, true);
		querySpec.appendWhere(sc,new int [] {});
		querySpec.appendOr();
		querySpec.appendWhere(sc2,new int[] {});
		QueryResult queryResult = PersistenceHelper.manager.find(querySpec);
        System.out.println("Query is : " + querySpec);
        
        Map<String,String> mapParts=new HashMap<>();//This map will store the Part Numbers
        while (queryResult.hasMoreElements()) {
        	WTPart p = (WTPart) queryResult.nextElement();
        	String partNumber=p.getNumber();
        	String partDisplayType=p.getDisplayType().getLocalizedMessage(null);
        	TypeIdentifier partTypeId = ClientTypedUtility.getTypeIdentifier(p);
        	if(partDisplayType.equals("Part") || partDisplayType.equals("Electrical Part")) {
        		mapParts.put(partNumber, partTypeId.toString());
        	}
        }
        System.out.println("Map output : " + mapParts);
        deleteAllPartsFromMap(mapParts);
        writeOutputPartsGettingDeleted(mapParts);
	}

	private static void deleteAllPartsFromMap(Map<String, String> mapParts) throws WTException, WTPropertyVetoException {
		Set<WTPartMaster> partMasterList=new HashSet<>();
		for (Map.Entry<String,String> entry : mapParts.entrySet()) {
        	QuerySpec query=new QuerySpec(WTPartMaster.class);
        	String partNumberToSearch=entry.getKey();
        	SearchCondition searchCondition = new SearchCondition(WTPartMaster.class, WTPartMaster.NUMBER,
        			SearchCondition.EQUAL, partNumberToSearch);
        	query.appendWhere(searchCondition, new int[] {});
        	QueryResult queryResult=PersistenceHelper.manager.find(query);
        	WTPartMaster pMaster=null;
        	
        	//If master part object is deleted all the other object links are getting deleted
			while(queryResult.hasMoreElements()) {
        		WTPartMaster pm=(WTPartMaster)queryResult.nextElement();
        		WTPart latestPart=(WTPart) wt.vc.VersionControlHelper.service.allVersionsOf(pm).nextElement();
        		Folder checkoutFolder = null;
    			CheckoutLink checkoutLink = null;
    			WTPart target=latestPart;
    			
    			//WTPartUsageLink deletion -- associated with the parts
    			if( !WorkInProgressHelper.isCheckedOut(target) ) {
    				checkoutFolder = WorkInProgressHelper.service.getCheckoutFolder();
    				checkoutLink = WorkInProgressHelper.service.checkout(target, checkoutFolder, "");
    				target = (WTPart) checkoutLink.getWorkingCopy();
    			}
    			WTPartUsageLink partLink = null;
    			QueryResult qr = StructHelper.service.navigateUses(target, false);
    			System.out.println("Number of child : " + qr.size() + " part number : " + target.getNumber());
    			while (qr.hasMoreElements()) {
					partLink = (WTPartUsageLink)qr.nextElement();
					PersistenceHelper.manager.delete(partLink);
					System.out.println("Parent : " + partLink.getUsedBy() + " Child : " + partLink.getUses());
				}
    			WorkInProgressHelper.service.checkin(target,"");
    			pMaster=latestPart.getMaster();
        	}
			partMasterList.add(pMaster);
	    }
		System.out.println(partMasterList);
		deletePartMasterList(partMasterList);
	}
	
	
	private static void deletePartMasterList(Set<WTPartMaster> partMasterList) throws WTException {
		for(WTPartMaster pm : partMasterList) {
			PersistenceHelper.manager.delete(pm);
		}
	}

	private static void writeOutputPartsGettingDeleted(Map<String, String> m1) throws IOException {
		String filePath="/appl/ptc/temp/DeletedPartList.csv";
		File file = new File(filePath);
		FileWriter fileWriter = new FileWriter(file);
        fileWriter.write("PartNumber" + "," + "FinalPartType");//header added
        fileWriter.append("\n");
        for (Map.Entry<String,String> entry : m1.entrySet()) {
        	fileWriter.write(entry.getKey() + "," + entry.getValue());
        	fileWriter.append("\n");
	    }
	    fileWriter.close();
	}
}
