package ext.itc.test;

import java.util.HashMap;
import java.util.Map;

public class DemoTest {
	private static Map<String,String> map1=new HashMap<>();
	public static void main(String[] args) {
		map1.put("Ankit", "1");
		map1.put("Bikram", "2");
		System.out.println("Inside Main map value : "+map1);
		doSomething();
	}
	public static void doSomething() {
		System.out.println("Inside doSomething func Map value is :"+map1);
		doSome2();
	}
	private static void doSome2() {
		// TODO Auto-generated method stub
		System.out.println("Inside doSomething2 func Map value is :"+map1);
	}
}
