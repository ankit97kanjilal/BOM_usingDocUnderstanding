package ext.itc.test;

public class DummyProgram {
	public static void statFunction() {
		System.out.println("Inside function");
	}
	public static void main(String[]args) {
		System.out.println("Inside main method");
		statFunction();
	}
}
