package ext.itc.test;

import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.query.SearchCondition;

public class FindPartFromWC implements RemoteAccess {
	public static void main(String[] args) {
        try {
            //Initialize the Windchill server connection with administrative credentials
            RemoteMethodServer rms = RemoteMethodServer.getDefault();
            rms.setUserName("wcadmin");
            rms.setPassword("wcadmin");
            //Part number to search for
            String partNumberToSearch = "0000000011"; // Replace with the part number you want to search
            //Create a query specification for searching parts
            QuerySpec query=new QuerySpec(WTPartMaster.class);
            QuerySpec query_2=new QuerySpec(WTPart.class);

            //Add a search condition for the part number
            SearchCondition searchCondition = new SearchCondition(WTPartMaster.class,
                    WTPartMaster.NUMBER, SearchCondition.EQUAL, partNumberToSearch);
            SearchCondition searchCondition_2 = new SearchCondition(WTPart.class,
                    WTPart.NUMBER, SearchCondition.EQUAL, partNumberToSearch);
            
            query.appendWhere(searchCondition, new int[] {});
            query_2.appendWhere(searchCondition_2, new int[] {});
            QueryResult queryResult = PersistenceHelper.manager.find(query);
            QueryResult queryResult_2 = PersistenceHelper.manager.find(query_2);
            
            //Process the query results - PartMaster
            System.out.println("Part Master queryspec result");
            while (queryResult.hasMoreElements()) {
            	WTPartMaster pm = (WTPartMaster) queryResult.nextElement();
            	System.out.println("Part Number: " + pm.getNumber());
            	System.out.println("Part GenericType: " + pm.getGenericType());
            	System.out.println("Part Type: " + pm.getType());
            	System.out.println("Part Name: " + pm.getName());
            	System.out.println("Part Container: " + pm.getContainer());
            }
            
            //Part class related query result
            System.out.println("Part queryspec result");
            while (queryResult_2.hasMoreElements()) {
            	WTPart p = (WTPart) queryResult_2.nextElement();
            	System.out.println("Part Number: " + p.getNumber());
            	System.out.println("Part getTypeInfoWTPart: " + p.getTypeInfoWTPart());
            	System.out.println("Part Type: " + p.getType());
            	System.out.println("Part getTypeDefinitionInfo: " + p.getTypeDefinitionInfo());
            	System.out.println("Part getTypeDefinitionReference: " + p.getTypeDefinitionReference());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
