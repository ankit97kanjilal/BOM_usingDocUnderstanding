package ext.itc.test;

//@successful - thread
//@in progress - logger
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;

import wt.facade.ixb.profile.StopWatch;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.service.IBAValueDBService;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.PersistenceException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.units.FloatingPointWithUnits;
import wt.units.Unit;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class IntroducingThreadsFetchWTParts implements RemoteAccess {
	private static final long serialVersionUID = 1L;
	private static final Logger LOGGER = LogManager.getLogger(IntroducingThreadsFetchWTParts.class );
    private static final Logger LOGGER_SUMMARY = LogManager.getLogger("vguardUpdatePIAttributesOnEPAndCP_Summary");
    private static final Logger LOGGER_PRE = LogManager.getLogger("vguardUpdatePIAttributesOnEPAndCP_Pre");
    private static final Logger LOGGER_POST = LogManager.getLogger("vguardUpdatePIAttributesOnEPAndCP_Post");
    private static final Logger LOGGER_ERROR = LogManager.getLogger("vguardUpdatePIAttributesOnEPAndCP_Error");

    private static final String IDA2A2_COLUMN = "thePersistInfo.theObjectIdentifier.id";

    private static final int USERNAME_INDEX = 0;
    private static final int USERNAME_VALUE_INDEX = 1;
    private static final int PASSWORD_VALUE_INDEX = 3;
    private static final int THREADS_INDEX = 4;
    private static final int THREADS_VALUE_INDEX = 5;

    private static final String TRACEABLE_CHECK_IBA_NAMES = "phiMedicalDevice,phiBusinessInterestItem,phiCertifiableItem";
    private static final String PI_CTRL_BY_BUILD_INTERNAL_NAME = "phiControlByDateOfBuild";
    private static final String PI_CTRL_BY_MFG_INTERNAL_NAME = "phiControlByDateOfManufacturing";
    private static final String PI_CTRL_BY_EXP_INTERNAL_NAME = "phiControlByExpDate";
    private static final String PI_CTRL_BY_LOT_INTERNAL_NAME = "phiControlByLot";
    private static final String PI_CTRL_BY_SN_INTERNAL_NAME = "phiControlBySerialNumber";
    private static final String PI_CTRL_BY_SWR_INTERNAL_NAME = "phiControlBySoftRev";
    private static final String PI_CTRL_BY_DN_INTERNAL_NAME = "phiPiControlByDonationNumber";
    private static final String PI_CTRL_BY_PN_INTERNAL_NAME = "phiPIControlByPartNumber";
    private static final String ADD_SN_LBL_INTERNAL_NAME = "phiAdditionalSerialNumber";
    private static final String ADD_DOM_LBL_INTERNAL_NAME = "phiAdditionalDoMonLabel";
    
    private static final String PM_LOGGING_STRING = "partMaster : ";

    private static boolean logHeaderWritten = false;
    
    private static String h1 = "Part Number~Part Name~Default Trace Code~PI Control By Date Of Build~";
    private static String h2 = "PI Control By Date Of Manufacturing~PI Control By Expiration Date~PI Control By Lot~";
    private static String h3 = "PI Control By Serial Number~PI Control By Software Revision~PI Control By Donation Number~";
    private static String h4 = "PI Control By Part Number~Additional Serial Number on Separate Label~Additional DoM on Label";
    
    private static String loggerHeader = h1 + h2 + h3 + h4;

    private static int processedPartMasterCount = 0;
    private static int successfulPartMasterCount = 0;
    private static int failedPartMasterCount = 0;

    private static Integer threads;
    private static RemoteMethodServer rms;
	
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		System.out.println("ENTER : IntroducingThreadsFetchWTParts.class.main(String[])");
        try {
            long startTime = System.currentTimeMillis();
            System.out.println("IntroducingThreadsFetchWTParts.class StartTime : " + startTime);
            rms = getConnection(args);//getting the connection
            if (rms != null) {
            	@SuppressWarnings("unchecked")
				ArrayList<WTPartMaster> partMasterList = (ArrayList<WTPartMaster>) rms.invoke("updateAttributeValueFromExcel",
						IntroducingThreadsFetchWTParts.class.getName(), null, new Class[] {}, new Object[] {});
            	List<Callable<String>> tasksForUpdate = tasksPreparation(partMasterList);
                executeAllTasks(tasksForUpdate);
            	
            	long endTime = System.currentTimeMillis();
                LOGGER.debug("ReadExcelUpdateAttribute.class EndTime : " + endTime);
                long totalTimeTaken = endTime - startTime;
//                rms.invoke("printSummaryLogs", IntroducingThreadsFetchWTParts.class.getName(),
//                		null, new Class[] { Long.class }, new Object[] {totalTimeTaken});
                processedPartMasterCount = 0;
                successfulPartMasterCount = 0;
                failedPartMasterCount = 0;
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing the utility.", e);
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.main(String[])");		
	}
	
	/**
     * This method establishes connection with method server
     * @param args - command line args
     * @return returns - rmi connection
     * @throws WTException - throws WTException
     */
    public static RemoteMethodServer getConnection(String[] args) throws WTException {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.getConnection(String[])");
        String username = null;
        String password = null;
        if ("-u".equals(args[USERNAME_INDEX])) {
            username = args[USERNAME_VALUE_INDEX];
            password = args[PASSWORD_VALUE_INDEX];
        }
        if ("-t".equals(args[THREADS_INDEX])) {
            threads = Integer.valueOf(args[THREADS_VALUE_INDEX]);
        }

        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        if (username != null && !"".equals(username)) {
            remoteMethodServer.setUserName(username);
            if (password != null) {
                remoteMethodServer.setPassword(password);
            }
        }
        LOGGER.debug("EXIT : UpdateExistingPartAttributes.getConnection(String[])");
        return remoteMethodServer;
    }
    
    /**
     * This method prepares independent tasks to be fed to threads
     * @param partMasterList - list of relevant WTPartMaster objects
     * @return returns a list of Callable tasks
     */
    private static List<Callable<String>> tasksPreparation(ArrayList<WTPartMaster> partMasterList) {
        LOGGER.debug("ENTER : UpdatePIAttributesOnEPAndCP.tasksPreparation(ArrayList<WTPartMaster>)");
        final List<Callable<String>> updateTask = new ArrayList<>();
        
        if (partMasterList != null && !partMasterList.isEmpty()) {
            for (final WTPartMaster wtpm : partMasterList) {
                updateTask.add(new Callable<String>() {
                    @Override
                    public String call() {
                        try {
                            rms.invoke("updatePartAttributeValue", IntroducingThreadsFetchWTParts.class.getName(), null, 
                            		new Class[] { WTPartMaster.class }, new Object[] { wtpm });
                        } catch (RemoteException | InvocationTargetException e) {
                            LOGGER.error("Exception occured during task preparation", e);
                            return e.getMessage();
                        }
                        return "Success";
                    }
                });
            }
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.tasksPreparation(ArrayList<WTPartMaster>)");
        return updateTask;
    }
    
    /**
     * This method executes all tasks one by one based on the number of threads
     * @param tasksForUpdate - all tasks
     */
    private static void executeAllTasks(List<Callable<String>> tasksForUpdate) {
        LOGGER.debug("ENTER : UpdatePIAttributesOnEPAndCP.executeAllTasks(List<Callable<String>>)");
        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        try {
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            executor.invokeAll(tasksForUpdate);
            stopWatch.stop();
        } catch (InterruptedException e) {
            LOGGER.error("Exception occured while executing tasks", e);
            return;
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.executeAllTasks(List<Callable<String>>) :: Shutdown");
        executor.shutdown();
    }
    
    /**
     * This method prints the part details of Part master object
     * @param WTPartMaster object
     * @throws WTException 
     * @throws PersistenceException 
     */    
    public static void updatePartAttributeValue(WTPartMaster pm) throws WTException {
    	LOGGER.debug("Enter printPartMasterName function() : ");
    	synchronized(IntroducingThreadsFetchWTParts.class) { processedPartMasterCount++; }
    	System.out.println("Part Number : "+pm.getNumber());
    	System.out.println("Part Name : "+pm.getName());
    	System.out.println("Part Container  for "+pm.getNumber()+" is : "+pm.getContainerName());
    	System.out.println("Part Type for "+pm.getNumber()+" is : "+pm.getType());
    	synchronized(IntroducingThreadsFetchWTParts.class) { successfulPartMasterCount++; }
    }
	
	public static ArrayList<WTPartMaster> updateAttributeValueFromExcel() throws WTException, WTPropertyVetoException {
		QuerySpec query=new QuerySpec(WTPart.class);
		TypeIdentifier typeCheck=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart|com.ptc.ElectricalPart");
		SearchCondition sc=TypedUtility.getSearchCondition(typeCheck, true);
		query.appendWhere(sc,new int [] {});
		System.out.println("Query for searching VGuard Parts : " + query);
        QueryResult queryResult = PersistenceHelper.manager.find(query);
        ArrayList<WTPartMaster> partMasterList=new ArrayList<>();
        
        while (queryResult.hasMoreElements()) {
        	WTPart p = (WTPart) queryResult.nextElement();
        	WTPartMaster partMaster=p.getMaster();
        	if (!partMasterList.contains(partMaster)) {
                partMasterList.add(partMaster);
            }
        }
        return partMasterList;
	}
}
