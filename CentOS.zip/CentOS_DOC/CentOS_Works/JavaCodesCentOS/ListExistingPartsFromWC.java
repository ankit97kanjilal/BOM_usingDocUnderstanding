package ext.itc.test;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;

import wt.facade.classification.ClassificationFacade;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.query.QuerySpec;
import wt.type.ClientTypedUtility;
import wt.util.WTException;

public class ListExistingPartsFromWC implements RemoteAccess {
	
	public static void main(String[] args) {
        try {
            //Initialize the Windchill server connection with administrative credentials
            RemoteMethodServer rms = RemoteMethodServer.getDefault();
            rms.setUserName("wcadmin");
            rms.setPassword("wcadmin");
            QuerySpec query=new QuerySpec(WTPart.class);
            QueryResult queryResult = PersistenceHelper.manager.find(query);
            
            Map<String,String> m1=new HashMap<>();//Map will store part number and part type
            while (queryResult.hasMoreElements()) {
            	WTPart p = (WTPart) queryResult.nextElement();
            	System.out.println("Part Number: " + p.getNumber());
            	System.out.println("Part Name: " + p.getName());
            	System.out.println("Part Type: " + p.getDisplayType().getLocalizedMessage(null));//For the part subtype present
            	
            	String partNumber=p.getNumber();
            	String partType=p.getDisplayType().getLocalizedMessage(null);
            	m1.put(partNumber, partType);
            	
            	TypeIdentifier partTypeId = ClientTypedUtility.getTypeIdentifier(p);
            	ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
            	System.out.println("Part Type (Full): " + partTypeId);
            	
            	/* retrieve the binding attribute(s) from part type */
                String bindAttrName = null;
                Set<AttributeTypeIdentifier> atis = facadeInstance.getClassificationConstraintAttributes(partTypeId);
                for (AttributeTypeIdentifier ati : atis) {
                    bindAttrName = ati.getAttributeName();
                    break;
                }
                
                String bindAttrValue = null;
                if (bindAttrName != null){
                   System.out.println("The classification node iba name is : " + bindAttrName);
                   PersistableAdapter obj = new PersistableAdapter(p, null, Locale.getDefault(),
                		   new DisplayOperationIdentifier());
                   obj.load(bindAttrName);
                   bindAttrValue = (String) obj.get(bindAttrName);
                 }
                System.out.println("The classification node internal name is "+ bindAttrValue);
            }
            System.out.println(m1);
        } catch (WTException e) {
            e.printStackTrace();
        }
    }
}