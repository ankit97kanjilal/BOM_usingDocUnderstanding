package ext.itc.test;

//Using Remote Method Invocation we can put our output in Method Server log
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import com.ptc.core.foundation.type.server.impl.TypeHelper;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.AttributeTypeIdentifier;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.windchill.csm.common.CsmConstants;

import wt.facade.classification.ClassificationFacade;
import wt.fc.Identified;
import wt.fc.IdentityHelper;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMasterIdentity;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class ListExistingPartsUsingRMI205 implements RemoteAccess {
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		System.out.println("Enter: main method");
		Class[] argTypes = {};
		Object[] argObject = {};
		RemoteMethodServer rms = RemoteMethodServer.getDefault();
		rms.setUserName("wcadmin");
		rms.setPassword("wcadmin");
		rms.invoke("listingPartNumbers", "ext.itc.test.ListExistingPartsUsingRMI205", null, argTypes,argObject);
		System.out.println(rms.getUserName());
	}
	
	public static void listingPartNumbers() throws WTException, WTPropertyVetoException, IOException {
		QuerySpec query=new QuerySpec(WTPart.class);
		TypeIdentifier typeCheck=ClientTypedUtility.getTypeIdentifier("wt.part.WTPart|com.plmtestlab.VGuardPart");
		SearchCondition sc=TypedUtility.getSearchCondition(typeCheck, true);
		query.appendWhere(sc,new int [] {});
		System.out.println("Query for searching VGuard Parts : " + query);
        QueryResult queryResult = PersistenceHelper.manager.find(query);
        Map<String,String> m1=new HashMap<>();//Map will store part number and part type
        
        while (queryResult.hasMoreElements()) {
        	WTPart p = (WTPart) queryResult.nextElement();
        	System.out.println("Part Number : " + p.getNumber());
        	System.out.println("Part Name : " + p.getName());
        	System.out.println("Part Type Display-name : " + p.getDisplayType().getLocalizedMessage(null));//For the part subtype present
        	
        	String partNumber=p.getNumber();
        	TypeIdentifier partTypeId = ClientTypedUtility.getTypeIdentifier(p);
        	ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
        	
        	//retrieve the binding attribute(s) from part type
            String bindAttrName = null;
            Set<AttributeTypeIdentifier> atis = facadeInstance.getClassificationConstraintAttributes(partTypeId);
            for (AttributeTypeIdentifier ati : atis) {
                bindAttrName = ati.getAttributeName();
            }
            //retrieve the classification node internal name
            String bindAttrValue = null;
            if (bindAttrName != null){
               PersistableAdapter obj = new PersistableAdapter(p, null, Locale.getDefault(),
            		   new DisplayOperationIdentifier());//business object api
               obj.load(bindAttrName);
               bindAttrValue = (String) obj.get(bindAttrName);
            }
            //retrieve the classification node path details, based on that finalize the part type
            String classifPartType = null;
            if (bindAttrValue != null) {
                String localizedName = facadeInstance.getLocalizedDisplayNameForClassificationNode(
                		bindAttrValue, CsmConstants.NAMESPACE, new Locale("en"));
                System.out.println("The localized name / display name for " + bindAttrValue + " is " + localizedName);
                String localizedHierarchy = facadeInstance.getLocalizedHierarchyForClassificationNode(
                		bindAttrValue, CsmConstants.NAMESPACE, new Locale("en"));
                System.out.println("The classification path for " + bindAttrValue + " is " + localizedHierarchy);
                String [] classifValue = localizedHierarchy.split(">");
                classifPartType = classifValue[2].trim();
            }
            //Finalizing Part Type based on VGuard Classification
            if (bindAttrValue != null) {
            	String newPartType="";
            	switch(classifPartType) {
            	case "Electrical" : 
            		newPartType="in.vguard.electricalParts";
            		break;
            	case "Electronics": 
            		newPartType="in.vguard.electronicsParts";
					break;
            	case "Fasteners": 
            		newPartType="in.vguard.fastenersParts";
					break;
            	case "Mechanical": 
            		newPartType="in.vguard.mechanicalParts";
					break;
            	case "Packing Material":
            		newPartType="in.vguard.packingMaterialParts";
					break;
            	case "Raw Material":
            		newPartType="in.vguard.rawMaterialParts";
					break;
            	default:
            		newPartType="com.plmtestlab.VGuardPart";
            	}
            	m1.put(partNumber, newPartType);
            }
        }
        updatePartTypeAndNumber(m1);
	}
	
	private static void updatePartTypeAndNumber(Map<String, String> m1)
			throws WTException, WTPropertyVetoException, IOException {
		Integer startPartNumberElectrical=100000001;//starting part number for Electrical
		Integer startPartNumberElectronics=200000001;//starting part number for Electronics
		Integer startPartNumberFasteners=300000001;//starting part number for Fasteners
		Integer startPartNumberMechanical=400000001;//starting part number for Mechanical
		Integer startPartNumberPackingMaterial=500000001;//starting part number for Packing Material
		Integer startPartNumberRawMaterial=600000001;//starting part number for Raw Material
		Map<String,String> mapParts=new HashMap<>();
		
		for (Map.Entry<String,String> entry : m1.entrySet()) {
        	System.out.println("PartNumber = " + entry.getKey() + ", NewPartType = " + entry.getValue());
			QuerySpec query=new QuerySpec(WTPart.class);
        	String partNumberToSearch=entry.getKey();
        	SearchCondition searchCondition = new SearchCondition(WTPart.class, WTPart.NUMBER,
        			SearchCondition.EQUAL, partNumberToSearch);
        	query.appendWhere(searchCondition, new int[] {});
        	QueryResult queryResult=PersistenceHelper.manager.find(query);
        	WTPart p=(WTPart) queryResult.nextElement();
        	Integer startPartNumber=0;
        	switch(entry.getValue()) {
        	case "in.vguard.electricalParts" :
        		startPartNumber=startPartNumberElectrical;
	        	startPartNumberElectrical++;
	        	break;
        	case "in.vguard.electronicsParts" :
        		startPartNumber=startPartNumberElectronics;
	        	startPartNumberElectronics++;
	        	break;
        	case "in.vguard.fastenersParts" :
        		startPartNumber=startPartNumberFasteners;
	        	startPartNumberFasteners++;
	        	break;
        	case "in.vguard.mechanicalParts" :
        		startPartNumber=startPartNumberMechanical;
	        	startPartNumberMechanical++;
	        	break;
        	case "in.vguard.rawMaterialParts" :
        		startPartNumber=startPartNumberRawMaterial;
        		startPartNumberRawMaterial++;
	        	break;
        	case "in.vguard.packingMaterialParts" :
        		startPartNumber=startPartNumberPackingMaterial;
	        	startPartNumberPackingMaterial++;
	        	break;
	        default:
        	}        	
        	//changing part number --> for master object any revision and iteration will be fine
        	//as it will lead to same master object, and it will update the part number of same PartMaster
        	String newPartNumber=Integer.toString(startPartNumber);
        	Identified idPart=p.getMaster();
        	WTPartMasterIdentity masterId=(WTPartMasterIdentity)idPart.getIdentificationObject();
        	masterId.setNumber(newPartNumber); //new part number is starting from defined range
        	IdentityHelper.service.changeIdentity(idPart, masterId);
        	
        	//changing part type
        	String newPartType=entry.getValue();
        	TypeIdentifier newPartTypeId = ClientTypedUtility.getTypeIdentifier(newPartType);
    		System.out.println("The new part type id is : " + newPartTypeId);
    		mapParts.put(partNumberToSearch.concat(">>".concat(newPartNumber)),
        			"in.vguard.vguardPart".concat(">>".concat(newPartType)));
        	TypeHelper.setType(p, newPartTypeId);
        	PersistenceServerHelper.update(p);
        	//for all revision and iteration part type should be changed
        	while(queryResult.hasMoreElements()) {
        		WTPart p1=(WTPart) queryResult.nextElement();
        		TypeHelper.setType(p1, newPartTypeId);
            	PersistenceServerHelper.update(p1);
        	}
        }
		System.out.println(mapParts);
		writeOutputPartsType(mapParts);
	}
	
	private static void writeOutputPartsType(Map<String, String> m1) throws IOException {
		String filePath="/appl/ptc/temp/PartList_ChangedPartType.csv";
		File file = new File(filePath);
		FileWriter fileWriter = new FileWriter(file);
        fileWriter.write("OldPartNumber" + "," + "OldPartType" + "," + "NewPartNumber" + "," + "NewPartType");//header added
        fileWriter.append("\n");
        for (Map.Entry<String,String> entry : m1.entrySet()) {
        	System.out.println("Map values are PartNumber : " + entry.getKey() + " PartType : " + entry.getValue());
        	String [] partNumber = entry.getKey().split(">>");
        	String oldPartNumber = partNumber[0].trim();
        	String newPartNumber = partNumber[1].trim();
        	String [] partType = entry.getValue().split(">>");
        	String oldPartType = partType[0].trim();
        	String newPartType = partType[1].trim();
        	fileWriter.write(oldPartNumber + "," + newPartNumber + "," + oldPartType + "," + newPartType);
        	fileWriter.append("\n");
	    }
	    fileWriter.close();
	}
}
