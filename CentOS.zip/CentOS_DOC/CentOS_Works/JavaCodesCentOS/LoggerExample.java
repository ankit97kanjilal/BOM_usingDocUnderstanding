package ext.itc.test;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.util.WTException;

public class LoggerExample implements RemoteAccess {
	private static final Logger LOGGER = LogManager.getLogger(LoggerExample.class);
	private static final Logger LOGGER_PRE = LogR.getLogger("LoggerExample_Pre");
    private static final Logger LOGGER_SUMMARY = LogR.getLogger("LoggerExample_Summary");
    private static final Logger LOGGER_POST = LogR.getLogger("LoggerExample_Post");
    private static final Logger LOGGER_ERROR = LogR.getLogger("LoggerExample_ERROR");
    
    private static final int USERNAME_INDEX = 0;
    private static final int USERNAME_VALUE_INDEX = 1;
    private static final int PASSWORD_VALUE_INDEX = 3;
    
    private static int processedPartMasterCount = 0;
    private static int successfulPartMasterCount = 0;
    private static int failedPartMasterCount = 0;
    private static RemoteMethodServer rms;
	
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		LOGGER.debug("ENTER : LoggerExample.class.main(String[])");
        try {
            long startTime = System.currentTimeMillis();
            LOGGER.debug("LoggerExample.class StartTime : " + startTime);
            rms = getConnection(args);
            if (rms != null) {
            	rms.invoke("doSomething", LoggerExample.class.getName(), null, new Class[] {}, new Object[] {});
                long endTime = System.currentTimeMillis();
                LOGGER.debug("LoggerExample.class EndTime : " + endTime);
                long totalTimeTaken = endTime - startTime;
                rms.invoke("printSummaryLogs", LoggerExample.class.getName(), null, new Class[] { Long.class }, new Object[] {totalTimeTaken});
                processedPartMasterCount = 0;
                successfulPartMasterCount = 0;
                failedPartMasterCount = 0;
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing the utility.", e);
        }
        LOGGER.debug("EXIT : LoggerExample.main(String[])");		
	}
	
    public static RemoteMethodServer getConnection(String[] args) throws WTException {
        LOGGER.debug("ENTER : LoggerExample.getConnection(String[])");
        String username = null;
        String password = null;
        if ("-u".equals(args[USERNAME_INDEX])) {
            username = args[USERNAME_VALUE_INDEX];
            password = args[PASSWORD_VALUE_INDEX];
        }
        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        if (username != null && !"".equals(username)) {
            remoteMethodServer.setUserName(username);
            if (password != null) {
                remoteMethodServer.setPassword(password);
            }
        }
        LOGGER.debug("EXIT : LoggerExample.getConnection(String[])");
        return remoteMethodServer;
    }
    
    public static void doSomething() {
    	LOGGER.debug("Inside doSomething() method...");
    	LOGGER_PRE.debug("Inside doSomething() method...PRE");
    	LOGGER_SUMMARY.debug("Inside doSomething() method...SUMMARY");
    	LOGGER_POST.debug("Inside doSomething() method...POST");
    	LOGGER_ERROR.debug("Inside doSomething() method...ERROR");
    }
    
    /**
     * This method writes the execution summary log.
     * @param totalTimeTaken total time taken to execute the utility
     */
    public static void printSummaryLogs(Long totalTimeTaken) {
        LOGGER_SUMMARY.debug("ENTER : LoggerExample.printSummaryLogs(Long)");
        long totalTimeInMilis = totalTimeTaken.longValue();
        LOGGER_SUMMARY.debug("Total time taken in miliSeconds : " + totalTimeInMilis);

        LOGGER_PRE.debug("Only for Pre log Inside printSummaryLogs() method...");
    	LOGGER_SUMMARY.debug("Inside printSummaryLogs() method...");
    	LOGGER_POST.debug("Inside printSummaryLogs() method...");
    	LOGGER_ERROR.debug("Inside printSummaryLogs() method...");
        
        LOGGER_PRE.info("Logger Example :: Summary");
        LOGGER.info("=======================================");
        LOGGER_SUMMARY.info("Number of traceable Part Master(s) : " + processedPartMasterCount);
        LOGGER_SUMMARY.info("Number of succssfully updated Part Master(s) : " + successfulPartMasterCount);
        LOGGER_SUMMARY.info("Number of Part Master(s) : " + failedPartMasterCount);
        LOGGER_ERROR.debug("EXIT : LoggerExample.printSummaryLogs(Long)");
    }
}
