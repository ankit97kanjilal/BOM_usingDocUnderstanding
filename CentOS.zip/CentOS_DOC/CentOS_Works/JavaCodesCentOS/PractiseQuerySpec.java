package ext.itc.test;

import java.rmi.RemoteException;
import wt.fc.PersistenceHelper;
import wt.fc.QueryResult;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.query.QueryException;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.part.WTPartMaster;
import wt.util.WTException;
import java.lang.reflect.InvocationTargetException;

//implement a query using QuerySpec
public class PractiseQuerySpec implements RemoteAccess {
	
	//searchPartNumber from windchill database
	public static void searchPartNumber() {
		try {
			System.out.println("Searching for the part number TEST_1234 : ");
			QuerySpec query = new QuerySpec(WTPartMaster.class);
			query.appendWhere(new SearchCondition(WTPartMaster.class,
					WTPartMaster.NUMBER, SearchCondition.EQUAL, "TEST_1234"),new int[] {});
			QueryResult result=PersistenceHelper.manager.find(query);
			System.out.println(query.toString());
			System.out.println(result.size());
		} catch (QueryException e) {
			e.printStackTrace();
		} catch (WTException e1) {
			e1.printStackTrace();
		}
	}
	
	//Main method
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		try {
			System.out.println("Enter: main method");
			Class[] argTypes = {};
			Object[] argObject = {};
			RemoteMethodServer rms;
			rms = RemoteMethodServer.getDefault();
			rms.setUserName("wcadmin");
			rms.setPassword("wcadmin");
			rms.invoke("searchPartNumber", "com.test.PractiseQuerySpec", null, argTypes,argObject);
			System.out.println(rms.getUserName());
			System.out.println("Please see 'SetPartMasterAttributes.log' file for detail log. ");
		}
		catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid Syntax\n windchill "
					+ "com.vguard.cost.UpdatePartMasterAttributesScheduler <ADMIN_USER> <ADMIN_PASSWORD>");
		}
	}
}
