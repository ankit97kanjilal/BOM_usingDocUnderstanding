package ext.itc.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelFile {
	public static void main(String[]args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the excel file path : "); //user will provide the excel file path
		String excelFilePath=sc.nextLine();
		
		//Creating FileInputStream to communicate with excel file
		try {
			FileInputStream inputStream=new FileInputStream(excelFilePath); //exception handling required
			XSSFWorkbook workbook=new XSSFWorkbook(inputStream); //exception handling required
			XSSFSheet sheet=workbook.getSheetAt(0);
			
			//iterating over the excel file and get the required values
			Iterator<Row> itrRow=sheet.iterator();
			while(itrRow.hasNext()) {
				Row row=itrRow.next();
				Iterator<Cell> itrCell=row.cellIterator(); //iterate over each cell row wise
				while(itrCell.hasNext()) {
					Cell cell=itrCell.next();
					System.out.print(cell.getStringCellValue() + "\t\t");
					//cell can be of different datatypes
				}
				System.out.println("");
			}
		}
		catch (FileNotFoundException e) {
			e.printStackTrace(); //printStackTrace to print the error
		}
		catch (IOException e1) {
			e1.printStackTrace(); //printStackTrace to print the error
		}
	}
}