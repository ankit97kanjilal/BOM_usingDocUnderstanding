package ext.itc.test;

//@successful
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import wt.fc.collections.WTArrayList;

import com.ptc.core.businessfield.common.BusinessField;
import com.ptc.core.businessfield.common.BusinessFieldIdFactoryHelper;
import com.ptc.core.businessfield.common.BusinessFieldServiceHelper;
import com.ptc.core.businessfield.server.BusinessFieldIdentifier;
import com.ptc.core.businessfield.server.businessObject.BusinessObject;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelper;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelperFactory;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;

import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.service.IBAValueDBService;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.ClientTypedUtility;
import wt.units.FloatingPointWithUnits;
import wt.units.Unit;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class ReadExcelUpdateAttribute014 implements RemoteAccess {
	private static final long serialVersionUID = 1L;
	private final static Logger LOGGER = LogManager.getLogger(UpdateExistingPartAttributes.class );
    private static final Logger LOGGER_SUMMARY = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Summary");
    private static final Logger LOGGER_PRE = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Pre");
    private static final Logger LOGGER_POST = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Post");
    private static final Logger LOGGER_ERROR = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Error");

    private static final String IDA2A2_COLUMN = "thePersistInfo.theObjectIdentifier.id";

    private static final int USERNAME_INDEX = 0;
    private static final int USERNAME_VALUE_INDEX = 1;
    private static final int PASSWORD_VALUE_INDEX = 3;
    private static final int THREADS_INDEX = 4;
    private static final int THREADS_VALUE_INDEX = 5;

    private static final String TRACEABLE_CHECK_IBA_NAMES = "phiMedicalDevice,phiBusinessInterestItem,phiCertifiableItem";

    private static final String PI_CTRL_BY_BUILD_INTERNAL_NAME = "phiControlByDateOfBuild";
    private static final String PI_CTRL_BY_MFG_INTERNAL_NAME = "phiControlByDateOfManufacturing";
    private static final String PI_CTRL_BY_EXP_INTERNAL_NAME = "phiControlByExpDate";
    private static final String PI_CTRL_BY_LOT_INTERNAL_NAME = "phiControlByLot";
    private static final String PI_CTRL_BY_SN_INTERNAL_NAME = "phiControlBySerialNumber";
    private static final String PI_CTRL_BY_SWR_INTERNAL_NAME = "phiControlBySoftRev";
    private static final String PI_CTRL_BY_DN_INTERNAL_NAME = "phiPiControlByDonationNumber";
    private static final String PI_CTRL_BY_PN_INTERNAL_NAME = "phiPIControlByPartNumber";
    private static final String ADD_SN_LBL_INTERNAL_NAME = "phiAdditionalSerialNumber";
    private static final String ADD_DOM_LBL_INTERNAL_NAME = "phiAdditionalDoMonLabel";
    
    private static final String PM_LOGGING_STRING = "partMaster : ";

    private static boolean logHeaderWritten = false;
    
    private static String h1 = "Part Number~Part Name~Default Trace Code~PI Control By Date Of Build~";
    private static String h2 = "PI Control By Date Of Manufacturing~PI Control By Expiration Date~PI Control By Lot~";
    private static String h3 = "PI Control By Serial Number~PI Control By Software Revision~PI Control By Donation Number~";
    private static String h4 = "PI Control By Part Number~Additional Serial Number on Separate Label~Additional DoM on Label";
    
    private static String loggerHeader = h1 + h2 + h3 + h4;

    private static int processedPartMasterCount = 0;
    private static int successfulPartMasterCount = 0;
    private static int failedPartMasterCount = 0;

    private static Integer threads;
    private static RemoteMethodServer rms;
	
	public static void main(String[] args) throws RemoteException, InvocationTargetException {
		LOGGER.debug("ENTER : ReadExcelUpdateAttribute.class.main(String[])");
        try {
            long startTime = System.currentTimeMillis();
            LOGGER.debug("ReadExcelUpdateAttribute.class StartTime : " + startTime);
            rms = getConnection(args);//getting the connection
            if (rms != null) {
            	rms.invoke("updateAttributeValueFromExcel", ReadExcelUpdateAttribute014.class.getName(),
            			null, new Class[] {}, new Object[] {});
                long endTime = System.currentTimeMillis();
                LOGGER.debug("ReadExcelUpdateAttribute.class EndTime : " + endTime);
                long totalTimeTaken = endTime - startTime;
                rms.invoke("printSummaryLogs", ReadExcelUpdateAttribute014.class.getName(),
                		null, new Class[] { Long.class }, new Object[] {totalTimeTaken});
                processedPartMasterCount = 0;
                successfulPartMasterCount = 0;
                failedPartMasterCount = 0;
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing the utility.", e);
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.main(String[])");		
	}
	
	/**
     * This method establishes connection with method server
     * @param args - command line args
     * @return returns - rmi connection
     * @throws WTException - throws WTException
     */
    public static RemoteMethodServer getConnection(String[] args) throws WTException {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.getConnection(String[])");
        String username = null;
        String password = null;
        if ("-u".equals(args[USERNAME_INDEX])) {
            username = args[USERNAME_VALUE_INDEX];
            password = args[PASSWORD_VALUE_INDEX];
        }
        if ("-t".equals(args[THREADS_INDEX])) {
            threads = Integer.valueOf(args[THREADS_VALUE_INDEX]);
        }

        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        if (username != null && !"".equals(username)) {
            remoteMethodServer.setUserName(username);
            if (password != null) {
                remoteMethodServer.setPassword(password);
            }
        }
        LOGGER.debug("EXIT : UpdateExistingPartAttributes.getConnection(String[])");
        return remoteMethodServer;
    }
	
	public static void updateAttributeValueFromExcel() throws WTException, WTPropertyVetoException {
		QuerySpec query=new QuerySpec(WTPartMaster.class);
		String partNumberToSearch="TESTPART5";
        SearchCondition searchCondition = new SearchCondition(WTPartMaster.class,
        		WTPartMaster.NUMBER, SearchCondition.EQUAL, partNumberToSearch);
        query.appendWhere(searchCondition, new int[] {});
        QueryResult queryResult = PersistenceHelper.manager.find(query);
        
        while (queryResult.hasMoreElements()) {
        	WTPartMaster pm=(WTPartMaster)queryResult.nextElement();
    		WTPart target=(WTPart) wt.vc.VersionControlHelper.service.allVersionsOf(pm).nextElement();
        	System.out.println("Part Number : " + target.getNumber());
        	System.out.println("Part Name : " + target.getName());
        	System.out.println("Part Life cycle name : " + target.getLifeCycleName());
        	System.out.println("Part Life cycle state : " + target.getLifeCycleState());
        	
        	PersistableAdapter obj = new PersistableAdapter(target, null, Locale.US, new UpdateOperationIdentifier());
        	obj.load("isPlatformIdentifier","testIBARealNumberUnits","testIBARealNumber");
        	FloatingPoint fpVal = new FloatingPoint(8.291,2);
        	FloatingPointWithUnits fpValUnits = new FloatingPointWithUnits(new Unit(410.291,5,"m"));
        	obj.set("isPlatformIdentifier", Boolean.TRUE);
        	obj.set("testIBARealNumber", fpVal);
        	obj.set("testIBARealNumberUnits", fpValUnits);
        	target = (WTPart)obj.apply();
        	
        	IBAValueDBService ibaserv = new IBAValueDBService();
        	ibaserv.updateAttributeContainer(target, ((DefaultAttributeContainer)target.getAttributeContainer()).getConstraintParameter(),null,null);
        	PersistenceServerHelper.manager.update((Persistable)target);
        }
	}
}
