package ext.itc.test;

import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import wt.method.RemoteMethodServer;

public class RemoteAccessClient {
	public static RemoteMethodServer getMS() {
		return RemoteMethodServer.getDefault();
	}
	public static void main(String []args) {		
		try {
			String user="Stranger";
			if(args.length>0) user=args[0];
			RemoteMethodServer rms=getMS();
			Class[] rmiArgsType=new Class[1];
			rmiArgsType[0] = java.lang.String.class;
			Object[] rmiArgsValue=new Object[1];
			rmiArgsValue[0]=user;
			
			Object result = rms.invoke("sayHelloTo","com.test.RemoteAccessTarget",null,rmiArgsType,rmiArgsValue);
			System.out.println("\nServer responded with the following message:" + result.toString());	
		} catch (RemoteException | InvocationTargetException e) {
			e.printStackTrace();
		}
	}
}
