package ext.itc.test;

import wt.method.RemoteAccess;
import wt.util.WTException;

public class RemoteAccessTarget implements RemoteAccess {	
	//Invoking a Method
	public static String sayHelloTo (String name) throws WTException {
		String message = "Windchill says hello, "+name;
	    System.out.println("AccessWindchillRMI >> "+message);
	    return message;
	}
}