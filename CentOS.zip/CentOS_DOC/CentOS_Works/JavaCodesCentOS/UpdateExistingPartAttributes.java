package ext.itc.test;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.ptc.core.meta.common.TypeIdentifier;

import wt.facade.ixb.profile.StopWatch;
import wt.fc.ObjectIdentifier;
import wt.fc.PersistInfo;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.definition.BooleanDefinition;
import wt.iba.value.BooleanValue;
import wt.iba.value.StringValue;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pds.StatementSpec;
import wt.pom.Transaction;
import wt.query.ArrayExpression;
import wt.query.ClassAttribute;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.type.ClientTypedUtility;
import wt.type.TypedUtility;
import wt.type.TypedUtilityServiceHelper;
import wt.util.WTAttributeNameIfc;
import wt.util.WTException;
import wt.util.WTPropertyVetoException;

public class UpdateExistingPartAttributes implements RemoteAccess, Serializable{
	private static final long serialVersionUID = 1L;
	private final static Logger LOGGER = LogManager.getLogger(UpdateExistingPartAttributes.class );
    private static final Logger LOGGER_SUMMARY = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Summary");
    private static final Logger LOGGER_PRE = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Pre");
    private static final Logger LOGGER_POST = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Post");
    private static final Logger LOGGER_ERROR = LogManager.getLogger("philipsUpdatePIAttributesOnEPAndCP_Error");

    private static final String IDA2A2_COLUMN = "thePersistInfo.theObjectIdentifier.id";

    private static final int USERNAME_INDEX = 0;
    private static final int USERNAME_VALUE_INDEX = 1;
    private static final int PASSWORD_VALUE_INDEX = 3;
    private static final int THREADS_INDEX = 4;
    private static final int THREADS_VALUE_INDEX = 5;

    private static final String TRACEABLE_CHECK_IBA_NAMES = "phiMedicalDevice,phiBusinessInterestItem,phiCertifiableItem";

    private static final String PI_CTRL_BY_BUILD_INTERNAL_NAME = "phiControlByDateOfBuild";
    private static final String PI_CTRL_BY_MFG_INTERNAL_NAME = "phiControlByDateOfManufacturing";
    private static final String PI_CTRL_BY_EXP_INTERNAL_NAME = "phiControlByExpDate";
    private static final String PI_CTRL_BY_LOT_INTERNAL_NAME = "phiControlByLot";
    private static final String PI_CTRL_BY_SN_INTERNAL_NAME = "phiControlBySerialNumber";
    private static final String PI_CTRL_BY_SWR_INTERNAL_NAME = "phiControlBySoftRev";
    private static final String PI_CTRL_BY_DN_INTERNAL_NAME = "phiPiControlByDonationNumber";
    private static final String PI_CTRL_BY_PN_INTERNAL_NAME = "phiPIControlByPartNumber";
    private static final String ADD_SN_LBL_INTERNAL_NAME = "phiAdditionalSerialNumber";
    private static final String ADD_DOM_LBL_INTERNAL_NAME = "phiAdditionalDoMonLabel";
    
    private static final String PM_LOGGING_STRING = "partMaster : ";

    private static boolean logHeaderWritten = false;
    
    private static String h1 = "Part Number~Part Name~Default Trace Code~PI Control By Date Of Build~";
    private static String h2 = "PI Control By Date Of Manufacturing~PI Control By Expiration Date~PI Control By Lot~";
    private static String h3 = "PI Control By Serial Number~PI Control By Software Revision~PI Control By Donation Number~";
    private static String h4 = "PI Control By Part Number~Additional Serial Number on Separate Label~Additional DoM on Label";
    
    private static String loggerHeader = h1 + h2 + h3 + h4;

    private static int processedPartMasterCount = 0;
    private static int successfulPartMasterCount = 0;
    private static int failedPartMasterCount = 0;

    private static Integer threads;
    private static RemoteMethodServer rms;

    /**
     * main() method from where the utility execution starts
     * @param args - arguments passed through command line
     */
    public static void main(String[] args) {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.main(String[])");
        try {
            long startTime = System.currentTimeMillis();
            LOGGER.debug("UpdateExistingPartAttributes StartTime : " + startTime);
            rms = getConnection(args);//getting the connection
            if (rms != null) {
                @SuppressWarnings("unchecked")
				ArrayList<WTPartMaster> partMasterList = (ArrayList<WTPartMaster>) rms.invoke("fetchPartMastersForEPAndCP",
                		UpdateExistingPartAttributes.class.getName(), null, new Class[] {}, new Object[] {});
                //List<Callable<String>> tasksForUpdate = tasksPreparation(partMasterList);
                //executeAllTasks(tasksForUpdate);

                long endTime = System.currentTimeMillis();
                LOGGER.debug("UpdateExistingPartAttributes EndTime : " + endTime);
                long totalTimeTaken = endTime - startTime;
                rms.invoke("printSummaryLogs", UpdateExistingPartAttributes.class.getName(),
                		null, new Class[] { Long.class }, new Object[] {totalTimeTaken});
                processedPartMasterCount = 0;
                successfulPartMasterCount = 0;
                failedPartMasterCount = 0;
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing the utility.", e);
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.main(String[])");
    }

    /**
     * This method establishes connection with method server
     * @param args - command line args
     * @return returns - rmi connection
     * @throws WTException - throws WTException
     */
    public static RemoteMethodServer getConnection(String[] args) throws WTException {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.getConnection(String[])");
        String username = null;
        String password = null;
        if ("-u".equals(args[USERNAME_INDEX])) {
            username = args[USERNAME_VALUE_INDEX];
            password = args[PASSWORD_VALUE_INDEX];
        }
        if ("-t".equals(args[THREADS_INDEX])) {
            threads = Integer.valueOf(args[THREADS_VALUE_INDEX]);
        }

        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        if (username != null && !"".equals(username)) {
            remoteMethodServer.setUserName(username);
            if (password != null) {
                remoteMethodServer.setPassword(password);
            }
        }
        LOGGER.debug("EXIT : UpdateExistingPartAttributes.getConnection(String[])");
        return remoteMethodServer;
    }

    /**
     * This method prepares independent tasks to be fed to threads
     * @param partMasterList - list of relevant WTPartMaster objects
     * @return returns a list of callable tasks
     */
//    private static List<Callable<String>> tasksPreparation(ArrayList<WTPartMaster> partMasterList) {
//        LOGGER.debug("ENTER : UpdateExistingPartAttributes.tasksPreparation(ArrayList<WTPartMaster>)");
//        final List<Callable<String>> updateTask = new ArrayList<>();
//        
//        if (partMasterList != null && !partMasterList.isEmpty()) {
//            for (final WTPartMaster wtpm : partMasterList) {
//                updateTask.add(new Callable<String>() {
//                    @Override
//                    public String call() throws Exception {
//                        try {
//                            rms.invoke("updatePartMaster", UpdateExistingPartAttributes.class.getName(), null, new Class[] { WTPartMaster.class },
//                                    new Object[] { wtpm });
//
//                        } catch (RemoteException | InvocationTargetException e) {
//                            LOGGER.error("Exception occured during task preparation.", e);
//                            return e.getMessage();
//                        }
//                        return "Success";
//                    }
//                });
//            }
//        }
//        LOGGER.debug("EXIT : UpdateExistingPartAttributes.tasksPreparation(ArrayList<WTPartMaster>)");
//        return updateTask;
//    }
//
//    /**
//     * This method executes all tasks one by one based on the number of threads
//     * @param tasksForUpdate - all tasks
//     */
//    private static void executeAllTasks(List<Callable<String>> tasksForUpdate) {
//        LOGGER.debug("ENTER : UpdateExistingPartAttributes.executeAllTasks(List<Callable<String>>)");
//        final ExecutorService executor = Executors.newFixedThreadPool(threads);
//        try {
//            StopWatch stopWatch = new StopWatch();
//            stopWatch.start();
//            executor.invokeAll(tasksForUpdate);
//            stopWatch.stop();
//        } catch (InterruptedException e) {
//            LOGGER.error("Exception occurred while executing tasks", e);
//            return;
//        }
//        LOGGER.debug("EXIT : UpdateExistingPartAttributes.executeAllTasks(List<Callable<String>>) :: Shutdown");
//        executor.shutdown();
//    }

    /**
     * This method writes the execution summary log.
     * @param totalTimeTaken - total time taken to execute the utility
     */
    public static void printSummaryLogs(Long totalTimeTaken) {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.printSummaryLogs(Long)");
        long totalTimeInMilis = totalTimeTaken.longValue();
        LOGGER.debug("Total time taken in miliSeconds : " + totalTimeInMilis);
        LOGGER_SUMMARY.info("Update PI Related attributes :: Summary");
        LOGGER_SUMMARY.info("=======================================");
        LOGGER_SUMMARY.info("Number of traceable Part Master(s) of type Engineered and Configurable Part : " + processedPartMasterCount);
        LOGGER_SUMMARY.info("Number of succssfully updated Part Master(s) of type Engineered and Configurable Part : " + successfulPartMasterCount);
        LOGGER_SUMMARY.info("Number of Part Master(s) of type Engineered and Configurable Part failed to update : " + failedPartMasterCount);
        LOGGER.debug("EXIT : UpdateExistingPartAttributes.printSummaryLogs(Long)");
    }
    
    /**
     * This method finds the WTPartMaster objects for all the Existing Parts
     * @return list of WTPartMaster objects
     * @throws WTPropertyVetoException - the WTPropertyVetoException
     */
    public static List<WTPartMaster> fetchPartMastersForEPAndCP() throws WTPropertyVetoException {
        LOGGER.debug("ENTER : UpdateExistingPartAttributes.fetchPartMastersForEPAndCP()");
        ArrayList<WTPartMaster> partMasterList = new ArrayList<WTPartMaster>();
        try {
        	QuerySpec query=new QuerySpec(WTPartMaster.class);
//    		SearchCondition sc=TypedUtility.getSearchCondition(typeCheck, true);
//    		query.appendWhere(sc,new int [] {});
    		LOGGER.debug("Query : " + query);
            QueryResult pmQueryResult = PersistenceHelper.manager.find(query);
            LOGGER.debug("QueryResult size : " + pmQueryResult.size());

            while (pmQueryResult.hasMoreElements()) {
                WTPartMaster partMaster = (WTPartMaster) pmQueryResult.nextElement();
                LOGGER.debug(PM_LOGGING_STRING + partMaster.getDisplayIdentifier());
                if (!partMasterList.contains(partMaster)) {
                    partMasterList.add(partMaster);
                }
            }
        } catch (WTException e) {
            LOGGER.error("Exception occured while fetching part master objects", e);
        }
        LOGGER.debug("EXIT : UpdateExistingPartAttributes.fetchPartMastersForEPAndCP() :: " + partMasterList.size());
        return partMasterList;
    }

    /**
     * This method updates the PI related attributes on basis of trace code value of the input part master.
     * And writes the pre and post update logs.
     * @param partMaster - the input WTPartMaster object
     */
//    public static void updatePartMaster(WTPartMaster partMaster) {
//        LOGGER.debug("ENTER : UpdatePIAttributesOnEPAndCP.updatePartMaster(WTPartMaster)");
//
//        if (null != partMaster) {
//            synchronized (UpdatePIAttributesOnEPAndCP.class) {
//                if (!logHeaderWritten) {
//                    LOGGER_PRE.info(loggerHeader);
//                    LOGGER_POST.info(loggerHeader);
//                    logHeaderWritten = true;
//                }
//                processedPartMasterCount++;
//            }
//
//            populateLogInfo(partMaster, LOGGER_PRE);
//
//            partMaster = calculateAndPopulatePIAttributes(partMaster);
//
//            populateLogInfo(partMaster, LOGGER_POST);
//        }
//
//        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.updatePartMaster(WTPartMaster)");
//    }
//
//    /**
//     * This method writes the trace code and other PI related attribute values of the input part master to the input logger file.
//     * 
//     * @param partMaster
//     *            the input part master object
//     * @param logger
//     *            the input logger object
//     */
//    private static void populateLogInfo(WTPartMaster partMaster, Logger logger) {
//        LOGGER.debug("ENTER : UpdatePIAttributesOnEPAndCP.populateLogInfo(WTPartMaster, Logger)");
//
//        LOGGER.debug("Log name : " + logger.getName());
//
//        String partNumber = partMaster.getNumber();
//        String partName = partMaster.getName();
//        String dtc = partMaster.getDefaultTraceCode().getDisplay();
//
//        // Get values of all IBAs available on WTPartMaster
//        Map<String, String> partMasterIBAMap = CPLMIBAUtility.getAllIBAValues(partMaster);
//
//        String ctrlByDOB = partMasterIBAMap.get(PI_CTRL_BY_BUILD_INTERNAL_NAME);
//        String ctrlByDOM = partMasterIBAMap.get(PI_CTRL_BY_MFG_INTERNAL_NAME);
//        String ctrlByED = partMasterIBAMap.get(PI_CTRL_BY_EXP_INTERNAL_NAME);
//        String ctrlByLot = partMasterIBAMap.get(PI_CTRL_BY_LOT_INTERNAL_NAME);
//        String ctrlBySN = partMasterIBAMap.get(PI_CTRL_BY_SN_INTERNAL_NAME);
//        String ctrlBySWR = partMasterIBAMap.get(PI_CTRL_BY_SWR_INTERNAL_NAME);
//        String ctrlByDN = partMasterIBAMap.get(PI_CTRL_BY_DN_INTERNAL_NAME);
//        String ctrlByPN = partMasterIBAMap.get(PI_CTRL_BY_PN_INTERNAL_NAME);
//        String addSNLbl = partMasterIBAMap.get(ADD_SN_LBL_INTERNAL_NAME);
//        String addDoMLbl = partMasterIBAMap.get(ADD_DOM_LBL_INTERNAL_NAME);
//
//        logger.info(partNumber + "~" + partName + "~" + dtc + "~" + ctrlByDOB + "~" + ctrlByDOM + "~" + ctrlByED + "~" + ctrlByLot + "~" + ctrlBySN + "~"
//                + ctrlBySWR + "~" + ctrlByDN + "~" + ctrlByPN + "~" + addSNLbl + "~" + addDoMLbl);
//
//        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.populateLogInfo(WTPartMaster, Logger)");
//    }
}
