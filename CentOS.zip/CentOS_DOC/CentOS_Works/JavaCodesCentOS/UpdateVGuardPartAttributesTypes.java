package ext.itc.test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.Logger;

import com.ptc.core.businessfield.common.BusinessField;
import com.ptc.core.businessfield.common.BusinessFieldIdFactoryHelper;
import com.ptc.core.businessfield.common.BusinessFieldServiceHelper;
import com.ptc.core.businessfield.server.BusinessFieldIdentifier;
import com.ptc.core.businessfield.server.businessObject.BusinessObject;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelper;
import com.ptc.core.businessfield.server.businessObject.BusinessObjectHelperFactory;
import com.ptc.core.lwc.server.PersistableAdapter;
import com.ptc.core.meta.common.DisplayOperationIdentifier;
import com.ptc.core.meta.common.FloatingPoint;
import com.ptc.core.meta.common.TypeIdentifier;
import com.ptc.core.meta.common.UpdateOperationIdentifier;
import com.ptc.windchill.csm.common.CsmConstants;

import wt.facade.classification.ClassificationFacade;
import wt.facade.ixb.profile.StopWatch;
import wt.fc.Persistable;
import wt.fc.PersistenceHelper;
import wt.fc.PersistenceServerHelper;
import wt.fc.QueryResult;
import wt.iba.value.DefaultAttributeContainer;
import wt.iba.value.service.IBAValueDBService;
import wt.log4j.LogR;
import wt.method.RemoteAccess;
import wt.method.RemoteMethodServer;
import wt.part.WTPart;
import wt.part.WTPartMaster;
import wt.pom.Transaction;
import wt.query.QuerySpec;
import wt.query.SearchCondition;
import wt.session.SessionHelper;
import wt.type.ClientTypedUtility;
import wt.units.FloatingPointWithUnits;
import wt.units.Unit;
import wt.util.WTException;

public class UpdateVGuardPartAttributesTypes implements RemoteAccess {
	private static final String CSV_FILE_PATH="/appl/ptc/temp/PartAttributeChange.csv";
	private static final Logger LOGGER = LogR.getLogger("UpdateVGuardPartAttributesTypes_Overview");
    private static final Logger LOGGER_SUMMARY = LogR.getLogger("vguardUpdateVGuardPartAttributesTypes_Summary");
    private static final Logger LOGGER_PRE = LogR.getLogger("vguardUpdateVGuardPartAttributesTypes_Pre");
    private static final Logger LOGGER_POST = LogR.getLogger("vguardUpdateVGuardPartAttributesTypes_Post");
    private static final Logger LOGGER_ERROR = LogR.getLogger("vguardUpdateVGuardPartAttributesTypes_Error");    
    
    private static final int USERNAME_INDEX = 0;
    private static final int USERNAME_VALUE_INDEX = 1;
    private static final int PASSWORD_VALUE_INDEX = 3;
    private static final int THREADS_INDEX = 4;
    private static final int THREADS_VALUE_INDEX = 5;
    
    private static boolean logHeaderWritten = false;
    private static String loggerHeader="Part Number~Part Name~Default Trace Code~PI Control By Date Of Build~";

    private static int processedPartMasterCount = 0;
    private static int successfulPartMasterCount = 0;
    private static int failedPartMasterCount = 0;
    private static Integer threads;
    private static RemoteMethodServer rms;
    	
	public static void main(String[] args) throws RemoteException {
		LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.class.main(String[])");
        try {
            long startTime=System.currentTimeMillis();
            LOGGER.debug("UpdateAttributeValuesFromExcel.class StartTime : " + startTime);
            rms = getConnection(args);
            if (rms != null) {
            	@SuppressWarnings("unchecked")
				Map<String,String> partListAll=(Map<String, String>) rms.invoke("readAttributeValuesFromExcel",
            			UpdateVGuardPartAttributesTypes.class.getName(), null, new Class[] {}, new Object[] {});
            	List<WTPart> partObjList=preparePartObjectList(partListAll);
				List<Callable<String>>tasksForUpdate=tasksPreparation(partObjList);
				executeAllTasks(tasksForUpdate);
				
            	long endTime=System.currentTimeMillis();
                processedPartMasterCount=0;
                successfulPartMasterCount=0;
                failedPartMasterCount=0;
                LOGGER.debug("Time taken total for execution : "+endTime);
                LOGGER_SUMMARY.debug("Time taken total for execution : "+endTime);
            }
        } catch (Exception e) {
            LOGGER.error("Exception occured while executing the utility.", e);
        }
        LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.main(String[])");		
	}
	
	/**
     * This method establishes connection with method server
     * @param args - command line args
     * @return returns - rmi connection
     * @throws WTException - throws WTException
     */
    public static RemoteMethodServer getConnection(String[] args) throws WTException {
        LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.getConnection(String[])");
        String username = null;
        String password = null;
        if ("-u".equals(args[USERNAME_INDEX])) {
            username = args[USERNAME_VALUE_INDEX];
            password = args[PASSWORD_VALUE_INDEX];
        }
        if ("-t".equals(args[THREADS_INDEX])) {
            threads = Integer.valueOf(args[THREADS_VALUE_INDEX]);
        }
        RemoteMethodServer remoteMethodServer = RemoteMethodServer.getDefault();
        if (username != null && !"".equals(username)) {
            remoteMethodServer.setUserName(username);
            if (password != null) {
                remoteMethodServer.setPassword(password);
            }
        }
        LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.getConnection(String[])");
        return remoteMethodServer;
    }
    
    /**
     * This method fetch the attribute values to update for a part
     * @return map variable - Part Number, Part attributes to update
     * @throws IOException
     */
    public static Map<String,String> readAttributeValuesFromExcel() throws IOException {
    	LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.readAttributeValuesFromExcel()");
    	Map<String,String> partListAll=new HashMap<>();
    	String line="";
    	String splitBy=",";
    	BufferedReader br = null;
    	try {
    		FileReader fr=new FileReader(CSV_FILE_PATH);
    		br=new BufferedReader(fr);
    		while ((line=br.readLine())!=null) {
    			String[] partDetails=line.split(splitBy);
    			if(partDetails[0].equals("PartNumber")) { //skip header
    				continue;
    			}
    			String partNumber=partDetails[0];
    			String partAttrValue="";
    			for (int i=1;i<partDetails.length;i++) {
    				if(i==partDetails.length-1) {partAttrValue=partAttrValue+partDetails[i];}
    				else {partAttrValue=partAttrValue+partDetails[i]+"~";}
    			}
    			partListAll.put(partNumber, partAttrValue);
    		}
    	}catch (IOException e) {
    		e.printStackTrace();
    		LOGGER_ERROR.error("Exception occured during readAttributeValuesFromExcel(): ",e);
    	}finally {
    		br.close();
    	}
    	LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.readAttributeValuesFromExcel()");
		return partListAll;
    }
    
    public static List<WTPart> preparePartObjectList(Map<String,String> partListAll) {
    	LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.preparePartObjectList()");
    	List<WTPart> partObjList=new ArrayList<>();
    	try {
    		for(Map.Entry<String, String> entry:partListAll.entrySet()) {
    			String partNumber=entry.getKey();
        		WTPart target=null;
        		QuerySpec query=new QuerySpec(WTPartMaster.class);
                SearchCondition searchCondition = new SearchCondition(WTPartMaster.class,
                		WTPartMaster.NUMBER, SearchCondition.EQUAL, partNumber);
                query.appendWhere(searchCondition, new int[] {});
                QueryResult queryResult = PersistenceHelper.manager.find(query);
                while (queryResult.hasMoreElements()) {
                	WTPartMaster pm=(WTPartMaster)queryResult.nextElement();
            		target=(WTPart) wt.vc.VersionControlHelper.service.allVersionsOf(pm).nextElement();
                }
                partObjList.add(target);
        	}
    	}catch (WTException e) {
			e.printStackTrace();
			LOGGER_ERROR.error("Error in executing preparePartObjectList() : ",e);
		}
    	LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.preparePartObjectList()");
    	return partObjList;
    }
    
    /**
     * This method prepares independent tasks to be fed to threads
     * @param partMasterList - list of relevant WTPartMaster objects
     * @return returns a list of Callable tasks
     */
    private static List<Callable<String>> tasksPreparation(List<WTPart> partObjList) {
    	LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.tasksPreparation(List<String>)");
    	final List<Callable<String>> updateTask = new ArrayList<>();
    	if (partObjList != null && !partObjList.isEmpty()) {
    		for (final WTPart wtpart : partObjList) {
    			updateTask.add(new Callable<String>() {
    				@Override
    				public String call() {
    					try {
    						rms.invoke("updateParts", UpdateVGuardPartAttributesTypes.class.getName(), null, 
    								new Class[] { WTPart.class }, new Object[] { wtpart });
    					} catch (RemoteException | InvocationTargetException e) {
    						LOGGER.error("Exception occured during task preparation", e);
    						return e.getMessage();
    					}
    					return "Success";
    				}
    			});
    		}
    	}
    	LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.tasksPreparation(List<WTPart>)");
    	return updateTask;
    }
    
    /**
     * This method prints the part details of Part master object
     * @param WTPartMaster object
     * @throws IOException 
     */    
    public static void updateParts(WTPart partObj) throws IOException {
        LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.updateParts(WTPart)");
        if (null != partObj) {
            synchronized (UpdateVGuardPartAttributesTypes.class) {
                if (!logHeaderWritten) {
                    LOGGER_PRE.info(loggerHeader);
                    LOGGER_POST.info(loggerHeader);
                    logHeaderWritten = true;
                }
                processedPartMasterCount++;
            }
            populateLogInfo(partObj, LOGGER_PRE);
            //partObj=updateAttributeValues(partObj);
            populateLogInfo(partObj, LOGGER_POST);
            updateTypeLCStateValues(partObj);
        }
        LOGGER.debug("EXIT : UpdateAttributeValuesFromExcel.updatePartMaster(WTPartMaster)");
    }

	private static void populateLogInfo(WTPart partObj, Logger logger) {
		LOGGER.debug("ENTER : UpdateAttributeValuesFromExcel.populateLogInfo(WTPart, Logger)");
		logger.info("The part number is : "+partObj.getName());
	}

	private static WTPart updateAttributeValues(WTPart partObj) throws IOException {
		//Attribute value PartNumber - will be updated with new SAP Number
		//Attribute value LegacyPartNumber - will be updated with old PartNumber
		Map<String,String> partListAll=readAttributeValuesFromExcel();
		String partNumber=partObj.getNumber();
		System.out.println("Part number from partObj.getNumber: "+partNumber);
		String partAttributes="";
		for(Map.Entry<String, String> entry:partListAll.entrySet()) {
			System.out.println("Part number from Map : "+entry.getKey());
			if(partNumber.equals(entry.getKey())) {
				System.out.println("matched with Part Number...");
				partAttributes=entry.getValue();
			}
		}
		System.out.println("Part number: "+partNumber+" Part attributes: "+partAttributes);
		String [] attributes = partAttributes.split("~");
		String isPlatformIdentifier=attributes[0];
		String testIBARealNumber=attributes[1];
		String testIBARealNumberUnits=attributes[2];
		
		System.out.println("isPlatformIdentifier : "+isPlatformIdentifier);
		System.out.println("testIBARealNumber : "+testIBARealNumber);
		System.out.println("testIBARealNumberUnits : "+testIBARealNumberUnits);
		
		Transaction transaction = null;
        try {
            transaction = new Transaction();
            transaction.start();
            FloatingPoint fpVal = new FloatingPoint(Float.parseFloat(testIBARealNumber),4);
    		FloatingPointWithUnits fpValUnits = new FloatingPointWithUnits(new Unit(Float.parseFloat(testIBARealNumberUnits),5,"m"));
    		Boolean boolVal=Boolean.parseBoolean(isPlatformIdentifier);
    		
            System.out.println("Inside updateAttributeValues(WTPart) function, Inside Transaction...");
            PersistableAdapter obj = new PersistableAdapter(partObj, null, Locale.US, new UpdateOperationIdentifier());
        	obj.load("isPlatformIdentifier","testIBARealNumberUnits","testIBARealNumber");
        	
        	obj.set("isPlatformIdentifier", boolVal);
        	obj.set("testIBARealNumber", fpVal);
        	obj.set("testIBARealNumberUnits", fpValUnits);
        	partObj = (WTPart)obj.apply();
        	System.out.println("Inside updateAttributeValues(WTPart) function, attribute values updated...");
        	IBAValueDBService ibaserv = new IBAValueDBService();
        	ibaserv.updateAttributeContainer(partObj, ((DefaultAttributeContainer)partObj.getAttributeContainer()).getConstraintParameter(),null,null);
        	PersistenceServerHelper.manager.update(partObj);
            
            transaction.commit();
            transaction = null;
            synchronized (UpdateVGuardPartAttributesTypes.class) {
                successfulPartMasterCount++;
            }
        } catch (WTException e) {
            synchronized (UpdateVGuardPartAttributesTypes.class) {
                failedPartMasterCount++;
            }
            LOGGER_ERROR.error("Attribute update failed for the part : " + partObj.getName());
            LOGGER.error("Exception occured while updating WTPartmaster IBAs", e);
        } finally {
            if (null != transaction) {
                LOGGER.error("Transaction has failed");
                transaction.rollback();
            }
        }
		return partObj;
	}

	private static void updateTypeLCStateValues(WTPart partObj) {
    	ClassificationFacade facadeInstance = ClassificationFacade.getInstance();
    	String classifAttrName="vgpClassification";
        String partSubType="PartType";
        try {
        	PersistableAdapter obj = new PersistableAdapter(partObj, null, Locale.US, new UpdateOperationIdentifier());
        	obj.load(classifAttrName,partSubType);
        	String classifAttrValue=(String) obj.get(classifAttrName);
        	String partSubTypeValue=obj.getAttributeDescriptor(partSubType).getLabel();//(String) obj.get(partSubType);
        	
            String classifPartType = null;
            
            if (classifAttrValue != null) {
                String localizedHierarchy=
                		facadeInstance.getLocalizedHierarchyForClassificationNode(classifAttrValue, CsmConstants.NAMESPACE, new Locale("en"));
                System.out.println("The classification path for " + classifAttrValue + " is " + localizedHierarchy);
                String [] classifValue = localizedHierarchy.split(">");
                classifPartType = classifValue[2].trim();
            }
            System.out.println("Part number : "+partObj.getNumber()+" Part Type should be : "+classifPartType+" Part sub type : "+partSubTypeValue);
            String newPartType=null;
            String newLCState=null;
//            if (partSubTypeValue.equals("))
            
        }catch (WTException e) {
			e.printStackTrace();
		}
	}
	
    /**
     * This method executes all tasks one by one based on the number of threads
     * @param tasksForUpdate - all tasks
     */
    private static void executeAllTasks(List<Callable<String>> tasksForUpdate) {
        LOGGER.debug("ENTER : UpdatePIAttributesOnEPAndCP.executeAllTasks(List<Callable<String>>)");
        final ExecutorService executor = Executors.newFixedThreadPool(threads);
        try {
            StopWatch stopWatch = new StopWatch();
            stopWatch.start();
            executor.invokeAll(tasksForUpdate);
            stopWatch.stop();
        } catch (InterruptedException e) {
            LOGGER.error("Exception occured while executing tasks", e);
            return;
        }
        LOGGER.debug("EXIT : UpdatePIAttributesOnEPAndCP.executeAllTasks(List<Callable<String>>) :: Shutdown");
        executor.shutdown();
    }
}
