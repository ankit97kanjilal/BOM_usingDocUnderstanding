--Deleting all the Electrical & WTPart objects
--Deletion order of related objects
select * from wtpartalternatelink;--done
select * from wtpartdescribelink;--done
select * from wtpartreferencelink;--done
select * from wtpartsubstitutelink;--
select * from wtpartusagelink;--done
select * from epmbuildrule;--done

select * from stringvalue;--done
select * from integervalue;--done
select * from floatvalue;--done
select * from unitvalue;--done
select * from booleanvalue;--done
select * from timestampvalue;--done

select * from wtpart;--done
select * from wtpartmasterkey;--done
select * from wtpartmaster;--done

--Create back up tables of all the tables
---------------------------------------------
create table wtpartalternatelink_BKP as select * from wtpartalternatelink;
create table wtpartdescribelink_BKP as select * from wtpartdescribelink;
create table wtpartreferencelink_BKP as select * from wtpartreferencelink;
create table wtpartsubstitutelink_BKP as select * from wtpartsubstitutelink;
create table wtpartusagelink_BKP as select * from wtpartusagelink;
create table epmbuildrule_BKP as select * from epmbuildrule;

create table stringvalue_BKP as select * from stringvalue;
create table integervalue_BKP as select * from integervalue;
create table floatvalue_BKP as select * from floatvalue;
create table unitvalue_BKP as select * from unitvalue;
create table booleanvalue_BKP as select * from booleanvalue;
create table timestampvalue_BKP as select * from timestampvalue;

create table wtpart_BKP as select * from wtpart;
create table wtpartmasterkey_BKP as select * from wtpartmasterkey;
create table wtpartmaster_BKP as select * from wtpartmaster;

--Identify the WTPartNumber for electrical & wtpart
-----------------------------------------------------
create table temp as
select distinct pm.wtpartnumber,pm.name,t.name PARTTYPE from wtpartmaster pm,wtpart p,wttypedefinition t
where pm.ida2a2=p.ida3masterreference and p.ida2typedefinitionreference=t.ida2a2 and t.name in (
'com.ptc.ElectricalPart','wt.part.WTPart');

--Identify the links related to the parts
--------------------------------------------------
--UsageLink where Parent need to be deleted
select * from wtpartusagelink;

select pm1.wtpartnumber PARENT_ITEM,pm2.wtpartnumber CHILD_ITEM,ul.ida2a2 USAGELINK_ID from
wtpartusagelink ul,wtpartmaster pm1,wtpartmaster pm2,wtpart p where pm1.ida2a2=p.ida3masterreference
and pm2.ida2a2=ul.IDA3B5 and p.ida2a2=ul.ida3a5 and (pm1.wtpartnumber in (select wtpartnumber from temp)
or pm2.wtpartnumber in (select wtpartnumber from temp));

--DescribeLink where Parent need to be deleted
select * from wtpartdescribelink;

select pm.wtpartnumber PARENT_PART,dm.wtdocumentnumber CHILD_DOC,dl.ida2a2 DESCRIBELINK_ID from
wtpartdescribelink dl,wtpartmaster pm,wtpart p,wtdocumentmaster dm,wtdocument d where pm.ida2a2=p.ida3masterreference
and p.ida2a2=dl.ida3a5 and dm.ida2a2=d.ida3masterreference and d.ida2a2=dl.ida3b5
and pm.wtpartnumber in (select wtpartnumber from temp);

--ReferenceLink where Parent need to be deleted
select * from wtpartreferencelink;

select pm.wtpartnumber PARENT_PART,dm.wtdocumentnumber REFERENCE_DOC,rl.ida2a2 DESCRIBELINK_ID from
wtpartreferencelink rl,wtpartmaster pm,wtpart p,wtdocumentmaster dm where pm.ida2a2=p.ida3masterreference
and p.ida2a2=rl.ida3a5 and dm.ida2a2=rl.ida3b5 and pm.wtpartnumber in (select wtpartnumber from temp);

--AlternateLink where Parent need to be deleted
select * from wtpartalternatelink;

select pm1.wtpartnumber PARENT_PART,pm2.wtpartnumber ALTERNATE_PART,al.ida2a2 DESCRIBELINK_ID from
wtpartalternatelink al,wtpartmaster pm1,wtpartmaster pm2 where pm1.ida2a2=al.ida3a5 and pm2.ida2a2=al.ida3b5
and pm1.wtpartnumber in (select wtpartnumber from temp);

--EPMBuildRule where Parent need to be deleted
select * from epmbuildrule;
select * from epmdocumentmaster where documentnumber like 'TEST%';
select * from epmdocument where ida3masterreference=391243;--found branchiditerationinfo will be matched

select em.documentnumber CAD_ITEM,pm.wtpartnumber PART_ITEM,p.versionida2versioninfo,p.iterationida2iterationinfo,
br.ida2a2 BUILDRULE_ID from epmbuildrule br,wtpartmaster pm,wtpart p,epmdocumentmaster em,epmdocument e where
p.ida3masterreference=pm.ida2a2 and e.ida3masterreference=em.ida2a2 and e.branchiditerationinfo=br.BRANCHIDA3A5
and p.branchiditerationinfo=br.BRANCHIDA3B5 and pm.wtpartnumber in (select wtpartnumber from temp);

--Identify the attributes related to the parts
--------------------------------------------------
select * from stringvalue;
select * from stringdefinition where ida2a2=374988;--PartType

--stringvalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,sv.value,sv.value2,sv.ida2a2
from wtpartmaster pm,wtpart p,stringvalue sv where pm.ida2a2=p.ida3masterreference
and sv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--intergervalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,iv.value,iv.ida2a2
from wtpartmaster pm,wtpart p,integervalue iv where pm.ida2a2=p.ida3masterreference
and iv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--floatvalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,fv.value,fv.ida2a2
from wtpartmaster pm,wtpart p,floatvalue fv where pm.ida2a2=p.ida3masterreference
and fv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--unitvalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,uv.value,uv.ida2a2
from wtpartmaster pm,wtpart p,unitvalue uv where pm.ida2a2=p.ida3masterreference
and uv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--booleanvalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,bv.value,bv.ida2a2
from wtpartmaster pm,wtpart p,booleanvalue bv where pm.ida2a2=p.ida3masterreference
and bv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--timestampvalue
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,tv.value,tv.ida2a2
from wtpartmaster pm,wtpart p,timestampvalue tv where pm.ida2a2=p.ida3masterreference
and tv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp);

--Entry of WTPart
select pm.wtpartnumber,p.versionida2versioninfo,p.iterationida2iterationinfo,p.ida2a2 from wtpartmaster pm,
wtpart p where p.ida3masterreference=pm.ida2a2 and pm.wtpartnumber in(select wtpartnumber from temp);

--Entry of WTPartMasterKey
select * from wtpartmasterkey where wtkey in (select wtpartnumber from temp);

--Entry of WTPartMaster
select * from wtpartmaster where wtpartnumber in (select wtpartnumber from temp);

--Deletion based on select queries (deletion of all the links)
--deletion of UsageLink
delete from WTPartUsageLink where ida2a2 in (select distinct ul.ida2a2 USAGELINK_ID from
wtpartusagelink ul,wtpartmaster pm1,wtpartmaster pm2,wtpart p where pm1.ida2a2=p.ida3masterreference
and pm2.ida2a2=ul.IDA3B5 and p.ida2a2=ul.ida3a5 and (pm1.wtpartnumber in (select wtpartnumber from temp)
or pm2.wtpartnumber in (select wtpartnumber from temp)));

--deletion of ReferenceLink
delete from wtpartreferencelink where ida2a2 in (select distinct rl.ida2a2 DESCRIBELINK_ID from
wtpartreferencelink rl,wtpartmaster pm,wtpart p,wtdocumentmaster dm where pm.ida2a2=p.ida3masterreference
and p.ida2a2=rl.ida3a5 and dm.ida2a2=rl.ida3b5 and pm.wtpartnumber in (select wtpartnumber from temp));

--deletion of AlternateLink
delete from wtpartalternatelink where ida2a2 in (select distinct al.ida2a2 DESCRIBELINK_ID from
wtpartalternatelink al,wtpartmaster pm1,wtpartmaster pm2 where pm1.ida2a2=al.ida3a5 and pm2.ida2a2=al.ida3b5
and pm1.wtpartnumber in (select wtpartnumber from temp));

--EPMBuildRule where Parent need to be deleted
delete from epmbuildrule where ida2a2 in (select distinct br.ida2a2 BUILDRULE_ID from epmbuildrule br,
wtpartmaster pm,wtpart p,epmdocumentmaster em,epmdocument e where p.ida3masterreference=pm.ida2a2 and
e.ida3masterreference=em.ida2a2 and e.branchiditerationinfo=br.BRANCHIDA3A5 and
p.branchiditerationinfo=br.BRANCHIDA3B5 and pm.wtpartnumber in (select wtpartnumber from temp));

--All the attributes deleteion from the parts
--stringvalue
delete from stringvalue where ida2a2 in (select distinct sv.ida2a2
from wtpartmaster pm,wtpart p,stringvalue sv where pm.ida2a2=p.ida3masterreference
and sv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--intergervalue
delete from integervalue where ida2a2 in (select distinct iv.ida2a2
from wtpartmaster pm,wtpart p,integervalue iv where pm.ida2a2=p.ida3masterreference
and iv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--floatvalue
delete from floatvalue where ida2a2 in (select distinct fv.ida2a2
from wtpartmaster pm,wtpart p,floatvalue fv where pm.ida2a2=p.ida3masterreference
and fv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--unitvalue
delete from unitvalue where ida2a2 in (select distinct uv.ida2a2
from wtpartmaster pm,wtpart p,unitvalue uv where pm.ida2a2=p.ida3masterreference
and uv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--booleanvalue
delete from booleanvalue where ida2a2 in (select distinct bv.ida2a2
from wtpartmaster pm,wtpart p,booleanvalue bv where pm.ida2a2=p.ida3masterreference
and bv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--timestampvalue
delete from timestampvalue where ida2a2 in (select distinct tv.ida2a2
from wtpartmaster pm,wtpart p,timestampvalue tv where pm.ida2a2=p.ida3masterreference
and tv.ida3a4=p.ida2a2 and pm.wtpartnumber in (select wtpartnumber from temp));

--delete from part table
delete from wtpart where ida2a2 in (select distinct p.ida2a2 from wtpartmaster pm,
wtpart p where p.ida3masterreference=pm.ida2a2 and pm.wtpartnumber in(select wtpartnumber from temp));

--Entry of WTPartMasterKey
delete from wtpartmasterkey where wtkey in (select wtpartnumber from temp);

--Entry of WTPartMaster
delete from wtpartmaster where wtpartnumber in (select wtpartnumber from temp);
