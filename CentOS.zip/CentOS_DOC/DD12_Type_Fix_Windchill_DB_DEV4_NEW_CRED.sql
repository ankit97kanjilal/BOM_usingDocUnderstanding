select * from tab where tname like '%TYPE%';
select * from WTTYPEDEFINITIONMASTER where DISPLAYNAMEKEY like '%com.ptcmscloud.General%';
/*
DISPLAYNAMEKEY  IDA2A2
wt.doc.WTDocument|com.ptcmscloud.IrrigationDocuments|com.ptcmscloud.GeneralDocuments|com.ptcmscloud.GeneralDocument - 466258
*/
select m.DISPLAYNAMEKEY,m.INTHID,m.IDA2A2 MASTERID,t.IDA2A2 TYPEID from WTTYPEDEFINITIONMASTER m,WTTYPEDEFINITION t
where m.IDA2A2=t.IDA3MASTERREFERENCE and m.DISPLAYNAMEKEY like '%com.ptcmscloud.General%' and m.INTHID=
'wt.doc.WTDocument|com.ptcmscloud.IrrigationDocuments|com.ptcmscloud.GeneralDocuments|com.ptcmscloud.GeneralDocument';
--466258 will be BRANCHIDA2TYPEDEFINITIONREFE, 466263 OR 466260 will be TYPEID

select distinct WBMSOURCEDESCRIPTION from aud_wtdocumentmaster where MIGRATIONSITE='ePDM';
--RH3_ePDM_WTDocumentMaster_FR
--WTDocumentMaster_DD12 (we need to change type for these two)
select * from aud_wtdocumentmaster where MIGRATIONSITE='ePDM' and WBMSOURCEDESCRIPTION='RH3_ePDM_WTDocumentMaster_FR';--171353  Rows

--Testing type change for one document --wbmsourceidentifier='451478'
--Targetobjectid='654449251'
select BRANCHIDA2TYPEDEFINITIONREFE,IDA2TYPEDEFINITIONREFERENCE,IDA2A2 from wtdocument where ida2a2 in(
select p.ida2a2 from wtdocumentmaster m,wtdocument p where m.IDA2A2=p.IDA3MASTERREFERENCE and m.ida2a2 in
(select Targetobjectid from aud_wtdocumentmaster where MIGRATIONSITE='ePDM' and 
WBMSOURCEDESCRIPTION in ('RH3_ePDM_WTDocumentMaster_FR','WTDocumentMaster_DD12'))
);
--BACKUP OF WTDOCUMENT TABLE
create table WTDOCUMENT_BACKUP_10_MARCH as select * from WTDOCUMENT;

--provided BRANCHIDA2TYPEDEFINITIONREFE increased by 1
--previously BRANCHIDA2TYPEDEFINITIONREFE=79334,IDA2TYPEDEFINITIONREFERENCE=466149
update WTDOCUMENT set BRANCHIDA2TYPEDEFINITIONREFE=466259,IDA2TYPEDEFINITIONREFERENCE=466260 where ida2a2 in(
select p.ida2a2 from wtdocumentmaster m,wtdocument p where m.IDA2A2=p.IDA3MASTERREFERENCE and m.ida2a2 in
(select Targetobjectid from aud_wtdocumentmaster where MIGRATIONSITE='ePDM' and 
WBMSOURCEDESCRIPTION in ('RH3_ePDM_WTDocumentMaster_FR','WTDocumentMaster_DD12'))
);
--206,137 rows updated.
commit;