--MEMBERLINK,REFERENCELINK,BUILDRULE,WTPARTREFERENCELINK
----------------------------------------------------------
--EPMMEMBERLINK (ePDM)
select * from int_epmmemberlink where WBMSOURCEDESCRIPTION is not null and migrated=5;

select em.container,em.OBJECTNUMBER PARENT,v.revision,e.iteration,em2.OBJECTNUMBER CHILD
from int_epmmemberlink a, int_epmdocumentmaster em,int_epmdocumentversion v,int_epmdocument e,int_epmdocumentmaster em2
where em.sequencenumber=v.masterreference and v.sequencenumber=e.versionreference
and a.USESREFERENCE=em2.sequencenumber and a.usedbyreference = e.sequencenumber
and a.migrated=5 and a.WBMSOURCEDESCRIPTION is not null;--470069  Rows

--EPMREFERENCELINK (ePDM)
select * from int_epmreferencelink where WBMSOURCEDESCRIPTION is not null and migrated=5;

select em.container,em.OBJECTNUMBER PARENT,v.revision,e.iteration,em2.OBJECTNUMBER CHILD
from int_epmreferencelink a, int_epmdocumentmaster em,int_epmdocumentversion v,int_epmdocument e,int_epmdocumentmaster em2
where em.sequencenumber=v.masterreference and v.sequencenumber=e.versionreference
and a.REFERENCESREFERENCE=em2.sequencenumber and a.REFERENCEDBYREFERENCE = e.sequencenumber
and a.migrated=5 and a.WBMSOURCEDESCRIPTION is not null;--309095  Rows

--EPMBUILDRULE (Network Drive & ePDM)
select * from int_epmbuildrule where migrated=5;--32039  Rows

select em.container,em.OBJECTNUMBER EPMDOCUMENT_OBJECTNUMBER,v.revision,e.iteration,pm.OBJECTNUMBER WTPART_OBJECTNUMBER
from int_epmbuildrule a, int_epmdocumentmaster em,int_epmdocumentversion v,int_epmdocument e,int_wtpartmaster pm
where em.sequencenumber=v.masterreference and v.sequencenumber=e.versionreference
and a.BUILDSOURCEREFERENCE = em.sequencenumber and a.BUILDTARGETREFERENCE=pm.sequencenumber 
and a.migrated=5 and a.WBMSOURCEDESCRIPTION is not null;--309095  Rows

--EPMDescribelink(Network Drive & ePDM)
select * from int_epmdescribelink where migrated=5;--27902  Rows

select em.container,em.OBJECTNUMBER EPMDOCUMENT_OBJECTNUMBER,v.revision,e.iteration,pm.OBJECTNUMBER WTPART_OBJECTNUMBER
from int_epmdescribelink a, int_epmdocumentmaster em,int_epmdocumentversion v,int_epmdocument e,int_wtpartmaster pm
where em.sequencenumber=v.masterreference and v.sequencenumber=e.versionreference
and a.DESCRIBESREFERENCE = pm.sequencenumber and a.DESCRIBEDBYREFERENCE=e.sequencenumber 
and a.migrated=5 and a.WBMSOURCEDESCRIPTION is not null;--27902  Rows

--WTPartReferenceLink
select * from int_wtpartreferencelink where migrated=5;--5868  Rows

select dm.container,dm.OBJECTNUMBER WTDOCUMENT_OBJECTNUMBER,v.revision,d.iteration,pm.OBJECTNUMBER WTPART_OBJECTNUMBER
from int_wtpartreferencelink a, int_wtdocumentmaster dm,int_wtdocumentversion v,int_wtdocument d,
int_wtpartmaster pm,int_wtpartversion pv,int_wtpart p
where dm.sequencenumber=v.masterreference and v.sequencenumber=d.versionreference
and pm.sequencenumber=pv.masterreference and pv.sequencenumber=p.versionreference
and a.REFERENCESREFERENCE=dm.sequencenumber and a.REFERENCEDBYREFERENCE=p.sequencenumber
and a.migrated=5;--5868  Rows

--Loaded ePDM - Objects with Legacy Path
select distinct WBMSOURCEDESCRIPTION from int_epmdocument;
select * from int_epmdocument where migrated=9;--595161  Rows

create table RH3_LOADED_EPMDOC_WITH_LEGACY_PATH as
select em.OBJECTNUMBER,v.revision,e.iteration,e.wbmsourcedescription,a.ibaname,a.stringvalue LEGACY_PATH
from int_epmdocumentmaster em,int_epmdocumentversion v,int_epmdocument e,iat_epmdocument a
where em.sequencenumber=v.masterreference and v.sequencenumber=e.versionreference and
e.sequencenumber=a.ibaholderreference and a.ibaname='Legacy_Path' and em.migrated=5;--595167  Rows

Alter table RH3_LOADED_EPMDOC_WITH_LEGACY_PATH add(Data_Source varchar2(20));
update RH3_LOADED_EPMDOC_WITH_LEGACY_PATH set Data_Source='ePDM'
where WBMSOURCEDESCRIPTION in('RH3_wt.epm.EPMDocument_FR','RH3_wt.epm.EPMDocument_PL');--561,267 rows updated.
update RH3_LOADED_EPMDOC_WITH_LEGACY_PATH set Data_Source='Network Drive' where data_source is null;--33,900 rows updated.
commit;
alter table RH3_LOADED_EPMDOC_WITH_LEGACY_PATH drop column WBMSOURCEDESCRIPTION;
select * from RH3_LOADED_EPMDOC_WITH_LEGACY_PATH;