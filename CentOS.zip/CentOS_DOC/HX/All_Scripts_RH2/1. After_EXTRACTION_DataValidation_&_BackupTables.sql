--After Extraction, data validation and 
--BACKUP of tables before transformation
--Product
select * from pdmlinkproduct;--86 rows
create table pdmlinkproduct_extract as select * from pdmlinkproduct;

--Library
select * from librarycontainer;--2 rows
create table librarycontainer_extract as select * from librarycontainer;

--Folder
select * from folder;--914  Rows
create table folder_extract as select * from folder;

--WTPart
select * from WTPartMaster;--32  Rows
select * from WTPart;--33  Rows
select * from ATT_WTPart;--87  Rows
create table WTPartMaster_extract as select * from WTPartMaster;
create table WTPart_extract as select * from WTPart;
create table ATT_WTPart_extract as select * from ATT_WTPart;

--EPMDocument
select * from EPMDocumentMaster;--765  Rows
select * from EPMDocument;--1275  Rows
select * from ATT_EPMDocument;--47  Rows
select * from epmparammapfordoc;--344 Rows/6 filtered
select * from epmmemberlink;--2001  Rows
select * from epmreferencelink;--678  Rows
select * from epmasstored;--4063  Rows
select * from epmbuildrule;--1 row
create table EPMDocumentMaster_extract as select * from EPMDocumentMaster;
create table EPMDocument_extract as select * from EPMDocument;
create table ATT_EPMDocument_extract as select * from ATT_EPMDocument;
create table epmparammapfordoc_extract as select * from epmparammapfordoc;
create table epmmemberlink_extract as select * from epmmemberlink;
create table epmreferencelink_extract as select * from epmreferencelink;
create table epmasstored_extract as select * from epmasstored;
create table epmbuildrule_extract as select * from epmbuildrule;

--WTDocument
select * from WTDocumentMaster;--2207  Rows
select * from WTDocument;--2209  Rows/2 rows filtered
select * from ATT_WTDocument;--0 rows
create table WTDocumentMaster_extract as select * from WTDocumentMaster;
create table WTDocument_extract as select * from WTDocument;
create table ATT_WTDocument_extract as select * from ATT_WTDocument;

--Lifecyclehistory
select * from lifecyclehistory;--12069  Rows
create table lifecyclehistory_extract as select * from lifecyclehistory;

--OBJECTHISTORY
--1st need to find which object history tables have data
--select * from objecthistory;
select tab.owner as schema_name, tab.table_name from sys.all_tables tab
where num_rows<>0 and tab.owner='reh1_staging' and tab.table_name like 'OBJECT%';
/*
OBJECTHISTORY_1742630401
OBJECTHISTORY_688167553
OBJECTHISTORY__860951556
*/
select * from OBJECTHISTORY_1742630401;--8612  Rows/8672  Rows
select * from OBJECTHISTORY_688167553;--32  Rows
select * from OBJECTHISTORY__860951556;--2898  Rows/2898  Rows
create table OBJECTHISTORY_1742630401_BKP as select * from OBJECTHISTORY_1742630401;
create table OBJECTHISTORY_688167553_BKP as select * from OBJECTHISTORY_688167553;
create table OBJECTHISTORY__860951556_BKP as select * from OBJECTHISTORY__860951556;

--DerivedImages
select * from derivedimage;--848  Rows
create table derivedimage_extract as select * from derivedimage;

--contentmetadata
select * from contentmetadata;--6015  Rows
create table contentmetadata_extract as select * from contentmetadata;

--Extract tables back up are done