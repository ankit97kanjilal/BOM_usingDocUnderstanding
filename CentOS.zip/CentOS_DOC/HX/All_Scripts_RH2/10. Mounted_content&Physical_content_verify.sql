--physical content validation on
--source and mounted data ITG4
select * from Mounted_data;
drop table Mounted_data;

select * from Mounted_data_PRO;--25832  Rows
create table Mounted_data as select * from Mounted_data_pro;

select * from source_data;
alter table source_data add (Filename varchar2(50));
alter table Mounted_data add (Filename varchar2(50));

select max(length(substr(data,instr(data,'\',-1)+1))) from source_data;
update source_data set filename=trim(substr(data,instr(data,'\',-1)+1));
commit;

select substr(data,instr(data,' ',-1)+1) from Mounted_data;
update Mounted_data set filename=trim(substr(data,instr(data,' ',-1)+1));
commit;

select * from mounted_data;
--select * from source_data;
select distinct filename from mounted_data;--25832  Rows
--select * from source_data where filename not in (select filename from mounted_data);
select * from contentmetadata;--6050  Rows
select * from contentmetadata where SRCFILENAME not in (select filename from mounted_data);
