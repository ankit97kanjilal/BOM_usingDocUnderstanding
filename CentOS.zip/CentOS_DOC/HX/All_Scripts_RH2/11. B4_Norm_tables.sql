--Before normalization take tables BACKUP
create table B4_Norm_pdmlinkproduct as select * from pdmlinkproduct;
create table B4_Norm_librarycontainer as select * from librarycontainer;
create table B4_Norm_Folder as select * from Folder;

create table B4_Norm_wtpart as select * from wtpart;
create table B4_Norm_wtpartmaster as select * from wtpartmaster;
create table B4_Norm_att_wtpart as select * from att_wtpart;

create table B4_Norm_wtdocument as select * from wtdocument;
create table B4_Norm_wtdocumentmaster as select * from wtdocumentmaster;
create table B4_Norm_att_wtdocument as select * from att_wtdocument;

create table B4_Norm_epmdocument as select * from epmdocument;
create table B4_Norm_epmdocumentmaster as select * from epmdocumentmaster;
create table B4_Norm_att_epmdocument as select * from att_epmdocument;
create table B4_Norm_epmasstored as select * from epmasstored;
create table B4_Norm_epmmemberlink as select * from epmmemberlink;
create table B4_Norm_epmreferencelink as select * from epmreferencelink;
--create table B4_Norm_epmparammapfordoc as select * from epmparammapfordoc;
--create table B4_Norm_epmbuildrule as select * from epmbuildrule;

create table B4_Norm_OBJHISTORY_1742630401 as select * from OBJECTHISTORY_1742630401;
create table B4_Norm_OBJHISTORY_688167553 as select * from OBJECTHISTORY_688167553;
create table B4_Norm_OBJHISTORY__860951556 as select * from OBJECTHISTORY__860951556;

drop table B4_Norm_contentmetadata;
create table B4_Norm_lifecyclehistory as select * from lifecyclehistory;

create table B4_Norm_derivedimage as select * from derivedimage;
create table B4_Norm_contentmetadata as select * from contentmetadata;

select * from tab where tname like 'B4_NORM%';--23  Rows

--count
select count(*) from B4_NORM_ATT_EPMDOCUMENT;--42
select count(*) from B4_NORM_ATT_WTDOCUMENT;--0
select count(*) from B4_NORM_ATT_WTPART;--120
select count(*) from B4_NORM_CONTENTMETADATA;--5171
select count(*) from B4_NORM_DERIVEDIMAGE;--678
select count(*) from B4_NORM_EPMASSTORED;--3795
select count(*) from B4_NORM_EPMDOCUMENT;--1021
select count(*) from B4_NORM_EPMDOCUMENTMASTER;--601
select count(*) from B4_NORM_EPMMEMBERLINK;--1479
select count(*) from B4_NORM_EPMREFERENCELINK;--664
select count(*) from B4_NORM_FOLDER;--310
select count(*) from B4_NORM_LIBRARYCONTAINER;--1
select count(*) from B4_NORM_LIFECYCLEHISTORY;--12116
select count(*) from B4_NORM_OBJHISTORY_1742630401;--8707
select count(*) from B4_NORM_OBJHISTORY_688167553;--32
select count(*) from B4_NORM_OBJHISTORY__860951556;--2453
select count(*) from B4_NORM_PDMLINKPRODUCT;--84
select count(*) from B4_NORM_WTDOCUMENT;--2227
select count(*) from B4_NORM_WTDOCUMENTMASTER;--2223
select count(*) from B4_NORM_WTPART;--33
select count(*) from B4_NORM_WTPARTMASTER;--32
