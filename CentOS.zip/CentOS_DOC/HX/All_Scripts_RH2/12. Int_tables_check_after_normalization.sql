select * from int_wtpartmaster;--32  Rows
select * from int_wtpart;--33  Rows
select * from iat_wtpart;--120  Rows

select * from int_epmdocumentmaster;--601  Rows
select * from int_epmdocument;--1021  Rows
select * from iat_epmdocument;--42  Rows
select * from int_epmmemberlink;--1479  Rows
select * from int_epmreferencelink;--664  Rows
select * from i_epmasstoredconfig;--116  Rows
select * from i_epmasstoredmember;--3795  Rows

select * from int_wtdocumentmaster;--2223  Rows
select * from int_wtdocument;--2227  Rows
select * from iat_wtdocument;--0  Rows

select * from int_lifecyclehistory;--12116  Rows

select * from int_OBJECTHISTORY_1742630401;--8706  Rows
select * from int_OBJECTHISTORY_688167553;--32  Rows
select * from int_OBJECTHISTORY__860951556;--2453  Rows
