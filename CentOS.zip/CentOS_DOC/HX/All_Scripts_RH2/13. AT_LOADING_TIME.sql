select * from int_epmdocumentmaster;
--1904006-id.asm will be for testing load
--wbmsourceid=77562, sequencenumber=10
select * from int_epmdocumentversion;
--match with seqnumber of master -> masterreference of version
select em.objectnumber, ev.revision,e.iteration,ea.ibaname,ea.STRINGVALUE,
ea.INTEGERVALUE, ea.FLOATVALUE, ea.FLOATVALUEWITHUNITS from 
int_epmdocumentmaster em,int_epmdocumentversion ev,
int_epmdocument e,iat_epmdocument ea where 
em.sequencenumber=ev.masterreference and 
ev.sequencenumber=e.versionreference
and e.sequencenumber=ea.ibaholderreference;

select * from int_epmdocument;
select * from iat_epmdocument;

select * from int_epmmemberlink;
select * from int_epmreferencelink;
select * from int_wtdocumentmaster;


select count(*),migrated from contentmetadata group by migrated;


select * from contentmap;
select distinct SRCFILEPATH from contentmap;
--srcfilepath=/mnt/vault01/Folder104/vaults/defaultsystemrootfolder/defaultsystemrootfolder_Folder_1
update contentmap set srcfilepath='/mnt/vault01/Folder104/vaults/defaultsystemrootfolder/defaultsystemrootfolder_Folder_1';
commit;

select 'cp '||SRCFILEPATH||'/'||SRCFILENAME||' '||TARGETFILEPATH||'/'||TARGETFILENAME from contentmap;
select 'ls -la '||TARGETFILEPATH||'/'||TARGETFILENAME||' >> FileExist.txt ' from contentmap;

select * from derivedimage;
--/opt/webhost/pdmlink/tmp/ankit/derivedimage/Viewables/77767

select cm.OBJECTNUMBER,cm.HOLDERREVISION,cm.HOLDERITERATION,cm.FILENAME,
cmp.srcfilepath,cmp.srcfilename,cmp.targetfilepath,cmp.targetfilename,cm.srcfilesize
from contentmetadata cm, contentmap cmp where cm.srcfilename=cmp.srcfilename;--5171  Rows

select migrated,count(*) from int_lifecyclehistory group by migrated;

select m.containertype,m.container, m.objectnumber,v.viewname, v.revision, p.iteration, 
p.type,p.folderpath,p.lifecycle,p.lifecyclestate,a.ibaname,a.stringvalue,a.boolvalue,a.floatvalue,a.timevalue
from int_wtpartmaster m,int_wtpartversion v,int_wtpart p,iat_wtpart a
where  m.objectnumber in ('0533-0000300','0513-0000C00','0523-0000000','0513-0000N00','06B6-0000200')
and  m.sequencenumber=v.masterreference and v.sequencenumber=p.versionreference and p.sequencenumber=a.ibaholderreference;

select m.containertype,m.container, m.objectnumber, v.revision, p.iteration, 
p.type,p.folderpath,p.lifecycle,p.lifecyclestate,a.ibaname,a.stringvalue,a.boolvalue,a.floatvalue,a.timevalue
from int_epmdocumentmaster m,int_epmdocumentversion v,int_epmdocument p,iat_epmdocument a where m.sequencenumber=v.masterreference 
and v.sequencenumber=p.versionreference and p.sequencenumber=a.ibaholderreference;

select m.containertype,m.container, m.objectnumber, v.revision, p.iteration, 
p.type,p.folderpath,p.lifecycle,p.lifecyclestate
from int_wtdocumentmaster m,int_wtdocumentversion v,int_wtdocument p
where  m.objectnumber in ('CAD0000002167','CAD0000002169','CAD0000002175','CAD0000002178','CAD0000002181') and  
m.sequencenumber=v.masterreference and v.sequencenumber=p.versionreference;

select  m.objectnumber, v.revision, d.iteration,c.role,c.filename,c.srcfilesize
from int_epmdocumentmaster m,int_epmdocumentversion v,int_epmdocument d,contentmetadata c
where m.objectnumber in ('SWITCH-MS-07S00-G2-1.PRT','1808003-CTR-TOP.PRT','1808003-EARPAD.PRT',
'1808003-BUTTON-MUTE.PRT','1808003-SLIDER-OUTER.PRT','1808003-HBPAD-SIDE.PRT','1808003-02-CABLE-INLINE-EAR.ASM') 
and m.sequencenumber=v.masterreference and v.sequencenumber=d.versionreference and c.objectnumber=m.objectnumber 
and c.holderrevision=v.revision and c.holderiteration=d.iteration and c.migrated=1;

select  m.objectnumber, v.revision, d.iteration,c.role,c.filename,c.srcfilesize
from int_wtdocumentmaster m,int_wtdocumentversion v,int_wtdocument d,contentmetadata c
where m.objectnumber in ('CAD0000000018','CAD0000000020','CAD0000000021','CAD0000000022',
'CAD0000000023','CAD0000000024','PJD0000000025','CAD0000000026') and m.sequencenumber=v.masterreference 
and v.sequencenumber=d.versionreference and c.objectnumber=m.objectnumber and c.holderrevision=v.revision 
and c.holderiteration=d.iteration and c.migrated=1;

select * from epmbom;
