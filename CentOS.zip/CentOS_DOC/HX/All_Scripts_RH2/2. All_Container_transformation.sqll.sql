--Library
select * from librarycontainer_extract;--backup done
select * from librarycontainer;
update librarycontainer set name='HX ME Common Parts',CONTAINERTEMPLATE='HyperX ME Common Parts Library',
ORGANIZATION='Hewlett-Packard' where name='ME Common Parts Library';
delete from librarycontainer where name='Part Information Library';--1
commit;

--Product
--PDMLINKPRODUCT update
select * from pdmlinkproduct_extract;--backup done
select * from pdmlinkproduct;
update pdmlinkproduct set name='HX '||name;
update pdmlinkproduct set ORGANIZATION='Hewlett-Packard';
update pdmlinkproduct set CONTAINERTEMPLATE='HyperX Product Template';
delete from pdmlinkproduct where name in ('HX KB0001_test','HX Aaron_Test');
commit;

--Folder
select * from folder_extract;--backup done
select * from folder;
--deleting as these folders will come from template
delete from folder where folderpath in('/Default/00-Promotion Requests','/Default/01-Baseline',
'/Default/Documents','/Default/CAD','/Default/CAD/MDE','/Default/CAD/Envision','/Default/Collaboration')
and containertype='PRODUCT';--602 rows deleted
delete from folder where folderpath in('/Default/00-Promotion Requests',
'/Default/Audio','/Default/2D_Format','/Default/Non-Audio','/Default/ME Standard Parts')
and containertype='LIBRARY';--5 rows deleted
commit;

update folder set container='HX ME Common Parts',ORGANIZATION='Hewlett-Packard' where containertype='LIBRARY';
update folder set container='HX '||container,ORGANIZATION='Hewlett-Packard' where containertype='PRODUCT';
commit;

--actual loss--Need to delete Organization containertype
delete from folder where CONTAINERTYPE='ORGANIZATION';
delete from folder where CONTAINER='HX KB0001_test';
commit;

--verify
select * from pdmlinkproduct;
select * from librarycontainer;
select * from folder;
