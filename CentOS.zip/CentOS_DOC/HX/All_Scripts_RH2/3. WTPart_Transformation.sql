--WTPart Transformation
select * from wtpartmaster;
--update wtpartmaster
update wtpartmaster set CONTAINER_ORGANIZATION_NAME='Hewlett-Packard',
ORGANIZATION_NAME='Hewlett-Packard';
commit;
update wtpartmaster set container='HX ME Common Parts'; 
commit;
select distinct containertype from wtpartmaster;--should be LIBRARY only

--For transferring IBANAME 'Description' to NAME
create table temp1  as
select m.name,a.stringvalue from wtpartmaster m, wtpart p, att_wtpart a
where m.wbmsourceidentifier=p.masterwbmsourceidentifier and 
p.wbmsourceidentifier=a.ibaholderwbmsourceidentifier
and a.ibaname='Description';

--Description comes into Name of WTPartMaster
select * from wtpartmaster;
merge into wtpartmaster a using 
(select distinct name,stringvalue from temp1) b
on (a.objectnumber=b.name)when matched then 
update set a.name=b.stringvalue;
commit;

--update wtpart
select * from wtpart;
select distinct type from wtpart;--wt.part.WTPart|corp.kingston.tw.KingstonPart
update wtpart set type='wt.part.WTPart|com.hp.HPPart';
commit;

select distinct lifecycle from wtpart;--Kingston_Part_LC
select distinct LIFECYCLESTATE from wtpart;--INWORK
update wtpart set lifecycle='Basic Part';
update wtpart set folderpath='/Default/Part Information';
commit;

--WTPART user update
--need to change createdby and modifiedby
alter table wtpart add (newcreatedby varchar2(50), newmodifiedby varchar2(50));

merge into wtpart a
using (select * from user_load)b
on (a.CREATEDBY=b.sourceusername)
when matched then update
set a.NEWCREATEDBY=b.targetusername;
commit;

merge into wtpart a
using (select * from user_load)b
on (a.modifiedby=b.sourceusername)
when matched then update
set a.newmodifiedby=b.targetusername;
commit;
select distinct createdby,newcreatedby,modifiedby,newmodifiedby from WTPart;

--transfer values and drop column
update WTPart set createdby=newcreatedby;
update WTPart set modifiedby=newmodifiedby;
commit;
select distinct createdby,newcreatedby,modifiedby,newmodifiedby from WTPart;

alter table WTPart drop (newcreatedby,newmodifiedby);
select distinct createdby,modifiedby from WTPart;

--Att transformation
select * from att_wtpart;
select ibaname,count(*) from att_wtpart group by ibaname;
insert into att_wtpart (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select  WBMSOURCEIDENTIFIER, 'ERSite', 'A67 (HyperX)' from wtpart ;--33
insert into att_wtpart (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select  WBMSOURCEIDENTIFIER, 'PartComments', '' from wtpart ;--33
commit;

select * from att_wtpart where stringvalue = '????(?TPU?)+?????+??TPU+Y3030?';
update att_wtpart set stringvalue = 'Healthy mesh (including TPU film) + black good performance cloth + blue TPU + Y3030 cotton'
where stringvalue = '????(?TPU?)+?????+??TPU+Y3030?';

update att_wtpart set ibaname='com.hp.BCNSUBCOMMODITY' where ibaname='RawMaterialSpec';
update att_wtpart set ibaname='com.hp.BCNCOMMODITY' where ibaname='Type';

delete from att_wtpart where ibaname='Description';
commit;

--verify all WTPartMaster, WTPart & ATT_WTPart is updated
select * from wtpartmaster;
select * from wtpart;
select * from att_wtpart;
