--Transformation for EPMDocument
select * from EPMDocumentmaster;--763  Rows
select * from EPMDocument;--1273  Rows
select * from att_epmdocument;--42  Rows
select IBANAME,count(*) from att_epmdocument group by IBANAME;
/*
RawMaterialSpec	1
PART_NO	43
Type	1
Remark	1
Part_Spec	1
*/
--Rules for EPMDocument : "Migrate all the EPMDocument with structure into Target Windchill Server"
--CAD Document will be mapped to CAD Document in target
--The lifecycle mapping for CAD Documents will be new LC �HyperX_EPMDoc_LC�.
--EPMMemberLink	"Migrate all the links available in the source."
--The engineering BOM  structure and all Assembly structure needs to be migrated into Windchill Server.
--EPMReferenceLink	"Migrate all the links available in the source."
--The relationship between Model and drawing files infomation needs to be migrate into Windchill server.
--epmasStored - Migrate all the links available in the source.
--EPMParameterMap - EPMParameterMap will be migrated as extracted.

--epmdocumentmaster
select * from epmdocumentmaster;
select distinct containertype from epmdocumentmaster;
select container, containertype,count(*) from epmdocumentmaster group by container, containertype;
select * from epmdocumentmaster where container='ME Common Parts Library';

--need to ignore
select * from epmdocumentmaster where container='KB0001_test';

--updating
update epmdocumentmaster set container='HX '||container where container not in ('KB0001_test','Site');--601 rows updated
update epmdocumentmaster set container='HX ME Common Parts' where container='HX ME Common Parts Library';--6 rows
commit;
update epmdocumentmaster set CONTAINER_ORGANIZATION_NAME='Hewlett-Packard',
ORGANIZATION_NAME='Hewlett-Packard';--763
commit;

--type (site, KB* not )
select * from epmdocumentmaster;
select distinct type from epmdocument;

--type of epmdocumentmaster update
--wt.epm.EPMDocumentMaster|com.hp.DefaultEPMDocumentMaster
select distinct type from epmdocumentmaster where container not in ('Site','KB0001_test');
update epmdocumentmaster set TYPE='wt.epm.EPMDocumentMaster|com.hp.DefaultEPMDocumentMaster'
where container not in ('Site','KB0001_test');--601 rows
commit;

--epmdocument
select * from epmdocument;
select lifecycle, count(*) from epmdocument group by lifecycle;

--Basic/Default lifecycle belong to which container -- Site
select distinct container from epmdocumentmaster where wbmsourceidentifier in (select MASTERWBMSOURCEIDENTIFIER 
from epmdocument where LIFECYCLE in ('Basic','Default'));--78  Rows

update epmdocument set lifecycle='HyperX_LC' where lifecycle='Kingston_EPMDoc_LC';--1195
commit;
select distinct lifecyclestate from epmdocument;
/*INWORK
RELEASED
DESIGN*/
update epmdocument set lifecyclestate='INWORK' where lifecyclestate='DESIGN';
commit;

select type, count(*) from epmdocument group by type;

--wt.epm.EPMDocument|com.hp.DefaultEPMDocument
update epmdocument set type='wt.epm.EPMDocument|com.hp.DefaultEPMDocument' where 
type='wt.epm.EPMDocument|corp.kingston.tw.DefaultEPMDocument';--1238
commit;

--EPMDocument user update
--need to change createdby and modifiedby
alter table epmdocument add (newcreatedby varchar2(50), newmodifiedby varchar2(50));

merge into epmdocument a
using (select * from user_load)b
on (a.CREATEDBY=b.sourceusername)
when matched then update
set a.NEWCREATEDBY=b.targetusername;
commit;

merge into epmdocument a
using (select * from user_load)b
on (a.modifiedby=b.sourceusername)
when matched then update
set a.newmodifiedby=b.targetusername;
commit;

select distinct createdby,newcreatedby,modifiedby,newmodifiedby from epmdocument;
--transfer values and drop column
update epmdocument set createdby=newcreatedby;
update epmdocument set modifiedby=newmodifiedby;
commit;
select distinct createdby,newcreatedby,modifiedby,newmodifiedby from epmdocument;

alter table epmdocument drop (newcreatedby,newmodifiedby);
select distinct createdby, modifiedby from epmdocument;

--att_epmdocument update
/*
insert into att_epmdocument (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select WBMSOURCEIDENTIFIER, 'PART_NUMBER', '' from epmdocument;
insert into att_epmdocument (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select WBMSOURCEIDENTIFIER, 'NC_NUMBER', '' from epmdocument;
insert into att_epmdocument (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select WBMSOURCEIDENTIFIER, 'PART_ILNK_RL', '' from epmdocument;
insert into att_epmdocument (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select WBMSOURCEIDENTIFIER, 'INITIATOR', '' from epmdocument;
insert into att_epmdocument (IBAHOLDERWBMSOURCEIDENTIFIER, IBANAME, STRINGVALUE)
select WBMSOURCEIDENTIFIER, 'MC_TYPE', '' from epmdocument;
commit;
*/
--att_epmdocument
select * from att_epmdocument;
select distinct IBAname from att_epmdocument;
select ibaname, count(*) from att_epmdocument group by ibaname;
select * from att_epmdocument where ibaname='RawMaterialSpec';
/*
RawMaterialSpec -> PART_ILNK_RL
PART_NO -> PART_NUMBER
Type -> MC_TYPE
Remark -> INITIATOR
Part_Spec -> NC_NUMBER
*/
--rename IBANAME
update att_epmdocument set IBANAME='PART_NUMBER' where IBANAME='PART_NO';
/*
update att_epmdocument set IBANAME='NC_NUMBER' where IBANAME='Part_Spec';
update att_epmdocument set IBANAME='PART_ILNK_RL' where IBANAME='RawMaterialSpec';
update att_epmdocument set IBANAME='INITIATOR' where IBANAME='Remark';
update att_epmdocument set IBANAME='MC_TYPE' where IBANAME='Type';
*/
--select * from epmdocument where wbmsourceidentifier='109330';--deleted
select * from att_epmdocument where IBAHOLDERWBMSOURCEIDENTIFIER not in (select wbmsourceidentifier from epmdocument);
delete from att_epmdocument where IBAHOLDERWBMSOURCEIDENTIFIER not in (select wbmsourceidentifier from epmdocument);
commit;

--EPMMemberLink
select * from epmmemberlink;
--update type
--wt.epm.structure.EPMMemberLink|com.hp.DefaultEPMMemberLink
select distinct type from epmmemberlink;
update epmmemberlink set type = 'wt.epm.structure.EPMMemberLink|com.hp.DefaultEPMMemberLink';--2001
commit;

--EPMReferenceLink
select * from epmreferencelink;
select distinct TYPE from epmreferencelink;
--update type
--wt.epm.structure.EPMReferenceLink|com.hp.DefaultEPMReferenceLink
update epmreferencelink set type = 'wt.epm.structure.EPMReferenceLink|com.hp.DefaultEPMReferenceLink';--678
commit;

--EPMParameterMap --not reqd
/*
select * from epmparammapfordoc;
select * from epmparammapfordoc where docobjectnumber not in (select OBJECTNUMBER from epmdocumentmaster);

--DOCORGANIZATION_NAME, DOCCONTAINERTYPE, DOCCONTAINER, DOCCONTAINER_ORGANIZATION_NAME
merge into epmparammapfordoc a
using (select * from epmdocumentmaster)b
on (a.DOCOBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.DOCORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.DOCCONTAINERTYPE=b.CONTAINERTYPE,
a.DOCCONTAINER=b.CONTAINER,
a.DOCCONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME;
commit;
*/
--EPMBuildRule--not reqd
/*
select * from epmbuildrule;
--checking duplicates
select BUILDSOURCEWBMSOURCEIDENTIFIER, BUILDTARGETWBMSOURCEIDENTIFIER, count(*) from epmbuildrule_new
group by BUILDSOURCEWBMSOURCEIDENTIFIER, BUILDTARGETWBMSOURCEIDENTIFIER having count(*) > 1;
--WBMSOURCEIDENTIFIER update with squence
create sequence WBM_SEQ start with 10000 increment by 1 nocache nocycle;
update epmbuildrule_new set WBMSOURCEIDENTIFIER = WBM_SEQ.nextval;
commit;
--UNIQUEID update with sequence
create sequence UNIQUE_SEQ start with 90000 increment by 1 nocache nocycle;
update epmbuildrule_new set UNIQUEID = UNIQUE_SEQ.nextval;
commit;
select * from epmbuildrule_new;
*/

--EPMasStored
select * from epmasstored;
select * from epmasstored where MEMOBJECTNUMBER not in (select objectnumber from epmdocumentmaster);--no rows
merge into epmasstored a
using (select * from epmdocumentmaster)b
on (a.MEMOBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.MEMORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.MEMCONTAINERTYPE=b.CONTAINERTYPE,
a.MEMCONTAINER=b.CONTAINER,
a.MEMCONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME;--4063 merged
commit;

--After transformation updates
--nned to delete->Data not reqd
--EPMDOC-HyperX_LC
select distinct LIFECYCLE from epmdocument;
update epmdocument set LIFECYCLE='HyperX_LC'
where lifecycle='HyperX_EPMDoc_LC';--1195
commit;
select * from epmdocumentmaster where wbmsourceidentifier in (select masterwbmsourceidentifier from 
epmdocument where lifecycle in ('Basic','Default'));--78  Rows

--Epmdocument
select * from epmdocumentmaster;

/*
--create table all_epmdocument as
select a.* from epmdocumentmaster a, epmdocument b, epmmemberlink c
where a.WBMSOURCEIDENTIFIER=b.MASTERWBMSOURCEIDENTIFIER and a.wbmsourceidentifier=c.useswbmsourceidentifier
and b.wbmsourceidentifier=c.USEDBYWBMSOURCEIDENTIFIER100;

select * from epmmemberlink;
--USEDBYWBMSOURCEIDENTIFIER100
select * from epmdocumentmaster where wbmsourceidentifier in 
(select useswbmsourceidentifier from epmmemberlink) and container='Site';

create table all_epm_doc1 as
select a.*, b.revision, b.iteration, b.lifecycle,b.lifecyclestate,b.wbmsourceidentifier 
as wbmsourceidentifier_1 from epmdocumentmaster a, epmdocument b 
where a.wbmsourceidentifier=b.masterwbmsourceidentifier;

select * from all_epm_doc1;
select p.objectnumber as parent, c.objectnumber child , a.* from epmmemberlink a, 
all_epm_doc1 p, all_epm_doc1 c where a.USEDBYWBMSOURCEIDENTIFIER100=p.wbmsourceidentifier_1
and a.useswbmsourceidentifier=c.wbmsourceidentifier and p.containertype='SITE';
*/

select * from att_epmdocument where IBAHOLDERWBMSOURCEIDENTIFIER in (select 
WBMSOURCEIDENTIFIER from epmdocument where masterWBMSOURCEIDENTIFIER in (select WBMSOURCEIDENTIFIER
from epmdocumentmaster where container in ('Site','KB0001_test')));--no data

select distinct CONTAINER from epmdocumentmaster;
select * from epmdocument where masterWBMSOURCEIDENTIFIER in (select WBMSOURCEIDENTIFIER
from epmdocumentmaster where container in ('Site','KB0001_test'));--252  Rows

--need to delete these rows
select em.objectnumber,em.name,em.container,em.containertype, em.ORGANIZATION_NAME,
e.LIFECYCLE,e.LIFECYCLESTATE,e.TYPE,e.revision,e.iteration from epmdocumentmaster em, epmdocument e
where em.WBMSOURCEIDENTIFIER=e.masterWBMSOURCEIDENTIFIER and em.container in ('Site','KB0001_test');--252  Rows

delete from epmdocument where masterWBMSOURCEIDENTIFIER in (select WBMSOURCEIDENTIFIER
from epmdocumentmaster where container in ('Site','KB0001_test'));--252  Rows
commit;

select container, count(*) from epmdocumentmaster where container in ('Site','KB0001_test') group by container;--162  Rows
delete from epmdocumentmaster where container in ('Site','KB0001_test');--162 rows deleted
commit;

--checking epmmemberlink
select * from epmmemberlink where USEDBYWBMSOURCEIDENTIFIER100 not in (select wbmsourceidentifier
from epmdocument);--522  Rows
select * from epmmemberlink where useswbmsourceidentifier not in (select wbmsourceidentifier
from epmdocumentmaster);--522  Rows
--need to delete 522 Rows
delete from epmmemberlink where useswbmsourceidentifier not in (select wbmsourceidentifier
from epmdocumentmaster);
commit;

--select em.*,mem.ASSTOREDCHILDNAME,mem.useswbmsourceidentifier from epmdocumentmaster_extract em,
--epmmemberlink_extract mem where em.wbmsourceidentifier=mem.useswbmsourceidentifier
--and em.wbmsourceidentifier in (select useswbmsourceidentifier from epmmemberlink where 
--useswbmsourceidentifier not in (select wbmsourceidentifier
--from epmdocumentmaster));--522  Rows

--epmasstored
select * from epmasstored;
select memobjectnumber from epmasstored where MEMOBJECTNUMBER not in 
(select objectnumber from epmdocumentmaster);--268  Rows/distinct 84
select * from epmasstored where MEMOBJECTNUMBER not in (select objectnumber from epmdocumentmaster_extract);--no data

select * from epmdocumentmaster_extract where objectnumber in
(select distinct memobjectnumber from epmasstored where MEMOBJECTNUMBER not in 
(select objectnumber from epmdocumentmaster));--84  Rows
select * from epmasstored;

select a.objectnumber||b.revision||b.iteration from epmdocumentmaster_extract a,
epmdocument_extract b where a.wbmsourceidentifier=b.masterwbmsourceidentifier
and container in ('Site','KB0001_test');

select distinct memobjectnumber||memrevision||memiteration from epmasstored
where memobjectnumber||memrevision||memiteration not in (select a.objectnumber||b.revision||b.iteration from 
epmdocumentmaster a,epmdocument b where a.wbmsourceidentifier=b.masterwbmsourceidentifier);--174 rows/wo distinct-268

select * from epmdocumentmaster_extract where objectnumber='00_FORGE_KEYCAP_ASM_3.ASM';
select * from epmdocumentmaster where objectnumber='00_FORGE_KEYCAP_ASM_3.ASM';

--============EPMAsstored 268 rows delete
select * from epmasstored where memobjectnumber not in (select objectnumber from epmdocumentmaster);--268 rows
delete from epmasstored where memobjectnumber not in (select objectnumber from epmdocumentmaster);--268 deleted
commit;

--Epmreferencelink
select * from epmreferencelink where REFDBYWBMSOURCEIDENTIFIER100 not in
(select wbmsourceidentifier from epmdocument);--14

select * from epmreferencelink where REFERENCESWBMSOURCEIDENTIFIER not in
(select wbmsourceidentifier from epmdocumentmaster);--14

delete from epmreferencelink where REFERENCESWBMSOURCEIDENTIFIER not in
(select wbmsourceidentifier from epmdocumentmaster);--14
commit;

--Epmparammap
select distinct STGIBANAME from epmparammapfordoc;--not migrating any
--not required
/*
select * from epmparammapfordoc;
select * from epmparammapfordoc where DOCOBJECTNUMBER||DOCREVISION||DOCITERATION
not in (select a.objectnumber||b.revision||b.iteration from 
epmdocumentmaster a,epmdocument b where 
a.wbmsourceidentifier=b.masterwbmsourceidentifier);

delete from epmparammapfordoc where DOCOBJECTNUMBER||DOCREVISION||DOCITERATION
not in (select a.objectnumber||b.revision||b.iteration from 
epmdocumentmaster a,epmdocument b where 
a.wbmsourceidentifier=b.masterwbmsourceidentifier);
commit;
*/

--need to delete
--Not present in production
/*
select * from epmdocumentmaster where objectnumber='CAD0000000052.ASM';
select * from epmdocument where masterwbmsourceidentifier='108858';

select * from epmmemberlink where useswbmsourceidentifier in (select
wbmsourceidentifier from epmdocumentmaster where objectnumber='CAD0000000052.ASM');--no data
select * from epmreferencelink where REFERENCESWBMSOURCEIDENTIFIER in
(select wbmsourceidentifier from epmdocumentmaster where objectnumber='CAD0000000052.ASM');--no data

delete from epmdocumentmaster where objectnumber='CAD0000000052.ASM';
delete from epmdocument where masterwbmsourceidentifier in(
select wbmsourceidentifier from epmdocumentmaster where objectnumber='CAD0000000052.ASM');
commit;
*/