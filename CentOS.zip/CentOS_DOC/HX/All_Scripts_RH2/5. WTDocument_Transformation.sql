--WTDocument Transformation

--wtdocumentmaster
select * from WTDocumentmaster;
select distinct containertype from wtdocumentmaster;
select *  from wtdocumentmaster where container='KB0001_test';--0
select *  from wtdocumentmaster where container='Aaron_Test';--0

update wtdocumentmaster set container='HX '||container;
update wtdocumentmaster set CONTAINER_ORGANIZATION_NAME='Hewlett-Packard';
update wtdocumentmaster set ORGANIZATION_NAME='Hewlett-Packard';
commit;

--wtdocument
select * from wtdocument;
--CADdata for promotion mapped to hp document
select distinct type from wtdocument;
update wtdocument set type='wt.doc.WTDocument|com.hp.CADData' 
where type='wt.doc.WTDocument|corp.kingston.tw.RDDocument|corp.kingston.tw.CADData';--1631
commit;

--ReferenceDocument to  HyperX Reference Document 
update wtdocument set type='wt.doc.WTDocument|com.ptc.ReferenceDocument|com.hp.HyperXReferenceDocument' 
where type='wt.doc.WTDocument|com.ptc.ReferenceDocument';--33
commit;

--ProjectDocument to  HyperX Reference Document 
update wtdocument set type='wt.doc.WTDocument|com.ptc.ReferenceDocument|com.hp.HyperXReferenceDocument' 
where type='wt.doc.WTDocument|corp.kingston.tw.RDDocument|corp.kingston.tw.ProjectDocument';--
commit;

--WTDocument to  HyperX Reference Document 
update wtdocument set type='wt.doc.WTDocument|com.ptc.ReferenceDocument|com.hp.HyperXReferenceDocument' 
where type='wt.doc.WTDocument';--
commit;

select distinct lifecycle from wtdocument;
update wtdocument set LIFECYCLE='HyperX_LC';
commit;
select distinct lifecyclestate from wtdocument;

--WTDocument user update
--need to change createdby and modifiedby
alter table wtdocument add (newcreatedby varchar2(50), newmodifiedby varchar2(50));

merge into wtdocument a
using (select * from user_load)b
on (a.CREATEDBY=b.sourceusername)
when matched then update
set a.NEWCREATEDBY=b.targetusername;
commit;

merge into wtdocument a
using (select * from user_load)b
on (a.modifiedby=b.sourceusername)
when matched then update
set a.newmodifiedby=b.targetusername;
commit;

select distinct createdby,newcreatedby,modifiedby,newmodifiedby from WTDocument;
--transfer values and drop column
update WTDocument set createdby=newcreatedby;
update WTDocument set modifiedby=newmodifiedby;
commit;
select distinct createdby,newcreatedby,modifiedby,newmodifiedby from WTDocument;

alter table WTDocument drop (newcreatedby,newmodifiedby);
select distinct createdby,modifiedby from WTDocument;

--verify
select * from wtdocumentmaster;
select * from wtdocument;
select * from att_wtdocument; -- empty

--deleting data not reqd
delete from wtdocument where masterWBMSOURCEIDENTIFIER in
(select WBMSOURCEIDENTIFIER from wtdocumentmaster where containertype='ORGANIZATION');
delete from wtdocumentmaster where containertype='ORGANIZATION';
commit;

select * from wtdocumentmaster_extract where containertype='ORGANIZATION';
