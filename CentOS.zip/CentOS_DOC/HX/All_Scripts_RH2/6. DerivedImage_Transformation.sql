--DerivedImage Transformation
select * from derivedimage;
select distinct CONTAINERTYPE from derivedimage;
select * from derivedimage where CONTAINERTYPE='ORGANIZATION';
delete from derivedimage where CONTAINERTYPE='ORGANIZATION';--1 row
commit;

update derivedimage set container='HX ME Common Parts' where containertype='LIBRARY';
update derivedimage set container='HX '||container where containertype='PRODUCT';
update derivedimage set ORGANIZATION_NAME='Hewlett-Packard',CONTAINER_ORGANIZATION_NAME='Hewlett-Packard';
update derivedimage set srcfilepath=replace(srcfilepath,'D:ptcderivedimage\Viewables\','/tmp/ankit/derivedimage/Viewables/');
commit;

select * from derivedimage where objectnumber in (select objectnumber from epmdocumentmaster_extract);--804  Rows before delete
select * from derivedimage where objectnumber in (select objectnumber from epmdocumentmaster);--after delete 630  Rows
select * from derivedimage where objectnumber in (select objectnumber from wtdocumentmaster);--48  Rows
/*
merge into derivedimage a
using (select * from epmdocumentmaster)b
on (a.OBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.ORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.CONTAINERTYPE=b.CONTAINERTYPE,
a.CONTAINER=b.CONTAINER,
a.CONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME;
commit;

merge into derivedimage a
using (select * from wtdocumentmaster)b
on (a.OBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.ORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.CONTAINERTYPE=b.CONTAINERTYPE,
a.CONTAINER=b.CONTAINER,
a.CONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME;
commit;
*/
select * from derivedimage where OBJECTNUMBER||REVISION||ITERATION
not in (select a.objectnumber||b.revision||b.iteration from 
epmdocumentmaster a,epmdocument b where 
a.wbmsourceidentifier=b.masterwbmsourceidentifier) and CLASSNAME='wt.epm.EPMDocument';--174  Rows

delete from derivedimage where OBJECTNUMBER||REVISION||ITERATION
not in (select a.objectnumber||b.revision||b.iteration from 
epmdocumentmaster a,epmdocument b where a.wbmsourceidentifier=b.masterwbmsourceidentifier) 
and CLASSNAME='wt.epm.EPMDocument';--174 Rows
commit;

--this data is not present in production
select * from derivedimage_extract where OBJECTNUMBER='CAD0000000052.ASM';--deleted already

--path we need to update
--/opt/webhost/pdmlink/tmp/ankit/derivedimage/Viewables/
select * from derivedimage;
update derivedimage set srcfilepath=replace(srcfilepath,'/tmp/ankit/derivedimage/Viewables/',
'/opt/webhost/pdmlink/tmp/ankit/derivedimage/Viewables/');--678 rows updated.
commit;