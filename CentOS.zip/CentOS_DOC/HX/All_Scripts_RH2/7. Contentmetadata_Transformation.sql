--Contentmetadata transformation
select * from contentmetadata;
select distinct holderclassname from contentmetadata;
select * from contentmetadata where OBJECTNUMBER in (select OBJECTNUMBER from epmdocumentmaster);--2802  Rows after delete
select * from contentmetadata where OBJECTNUMBER in (select OBJECTNUMBER from wtdocumentmaster);--2332  Rows
/*
wt.doc.WTDocument
wt.epm.EPMDocument
*/
--merge from epmdocumentmaster
merge into contentmetadata a
using (select * from epmdocumentmaster)b
on (a.OBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.ORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.CONTAINER_TYPE=b.CONTAINERTYPE,
a.CONTAINER_NAME=b.CONTAINER,
a.CONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME
where a.holderclassname='wt.epm.EPMDocument';
commit;

--merge from wtdocumentmaster
merge into contentmetadata a
using (select * from wtdocumentmaster)b
on (a.OBJECTNUMBER=b.OBJECTNUMBER)
when matched then update
set a.ORGANIZATION_NAME=b.ORGANIZATION_NAME,
a.CONTAINER_TYPE=b.CONTAINERTYPE,
a.CONTAINER_NAME=b.CONTAINER,
a.CONTAINER_ORGANIZATION_NAME=b.CONTAINER_ORGANIZATION_NAME
where a.holderclassname='wt.doc.WTDocument';
commit;

--need to update CREATEDBY, MODIFIEDBY
alter table contentmetadata add (newcreatedby varchar2(40),newmodifiedby varchar2(40));

merge into contentmetadata a
using (select * from user_load)b
on (a.createdby=b.sourceusername)
when matched then update
set a.newcreatedby=b.targetusername;
commit;

merge into contentmetadata a
using (select * from user_load)b
on (a.modifiedby=b.sourceusername)
when matched then update
set a.newmodifiedby=b.targetusername;
commit;

select distinct createdby, newcreatedby from contentmetadata;
select distinct modifiedby, newmodifiedby from contentmetadata;

--Transfer the value and drop column newcreatedby, newmodifiedby
update contentmetadata set createdby = newcreatedby,
modifiedby = newmodifiedby;
select distinct createdby, modifiedby from contentmetadata;
alter table contentmetadata drop (newcreatedby, newmodifiedby);
commit;

update contentmetadata set createdby='Administrator' where createdby='wcadmin';
update contentmetadata set MODIFIEDBY='Administrator' where MODIFIEDBY='wcadmin';
commit;
update contentmetadata set TARGETSITEURL='https://pdmlink-hpi-itg.ext.hp.com/Windchill/servlet/WindchillGW';
update contentmetadata set TARGETVAULTNAME='defaultsystemvault';
commit;

--need to delete
select * from contentmetadata where CONTAINER_ORGANIZATION_NAME='Kingston';--881  Rows
delete from contentmetadata where CONTAINER_ORGANIZATION_NAME='Kingston';
commit;

select count(*),holderclassname from contentmetadata group by holderclassname;
/*2332	wt.doc.WTDocument
2802	wt.epm.EPMDocument*/
