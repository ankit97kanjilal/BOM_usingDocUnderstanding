select distinct lifecyclename from lifecyclehistory;
/*
Basic 1
Basic Part
Kingston_EPMDoc_LC 1
Kingston_EPMDoc_LC 2
Kingston_EPMDoc_LC 3
Kingston_EPMDoc_LC 4
Kingston_Part_LC 1
Kingston_RDDoc_LC 1
Kingston_RDDoc_LC 2
Kingston_RDDoc_LC 3
Kingston_RDDoc_LC 4
Promotion Request 1
*/

--updating
select * from lifecyclehistory;
select distinct ACTORNAME,ACTORREFERENCE from lifecyclehistory;
update lifecyclehistory set ACTORNAME='Alex.Gu1@hp.com' where ACTORNAME='alex_gu';
update lifecyclehistory set ACTORREFERENCE='Alex.Gu1@hp.com' where ACTORREFERENCE='alex_gu';

update lifecyclehistory set ACTORNAME='Bruce.Ho@hp.com' where ACTORNAME='bruce_ho';
update lifecyclehistory set ACTORREFERENCE='Bruce.Ho@hp.com' where ACTORREFERENCE='bruce_ho';

update lifecyclehistory set ACTORNAME='Carter.Lai@hp.com' where ACTORNAME='carter_lai';
update lifecyclehistory set ACTORREFERENCE='Carter.Lai@hp.com' where ACTORREFERENCE='carter_lai';

update lifecyclehistory set ACTORNAME='Charlson.Chang@hp.com' where ACTORNAME='charlson_chang';
update lifecyclehistory set ACTORREFERENCE='Charlson.Chang@hp.com' where ACTORREFERENCE='charlson_chang';

update lifecyclehistory set ACTORNAME='Ethan.Chen@hp.com' where ACTORNAME='ethan_chen';
update lifecyclehistory set ACTORREFERENCE='Ethan.Chen@hp.com' where ACTORREFERENCE='ethan_chen';

update lifecyclehistory set ACTORNAME='Glason.Chou@hp.com' where ACTORNAME='glason_chou';
update lifecyclehistory set ACTORREFERENCE='Glason.Chou@hp.com' where ACTORREFERENCE='glason_chou';

update lifecyclehistory set ACTORNAME='Jeff.Wang@hp.com' where ACTORNAME='jeff_wang';
update lifecyclehistory set ACTORREFERENCE='Jeff.Wang@hp.com' where ACTORREFERENCE='jeff_wang';

update lifecyclehistory set ACTORNAME='Kyle.Yu@hp.com' where ACTORNAME='kyle_yu';
update lifecyclehistory set ACTORREFERENCE='Kyle.Yu@hp.com' where ACTORREFERENCE='kyle_yu';

update lifecyclehistory set ACTORNAME='Linus.Chien@hp.com' where ACTORNAME='linus_chien';
update lifecyclehistory set ACTORREFERENCE='Linus.Chien@hp.com' where ACTORREFERENCE='linus_chien';

update lifecyclehistory set ACTORNAME='Wells.Wang@hp.com' where ACTORNAME='wells_wang';
update lifecyclehistory set ACTORREFERENCE='Wells.Wang@hp.com' where ACTORREFERENCE='wells_wang';

update lifecyclehistory set ACTORNAME='Administrator' where ACTORNAME='rdadmin';
update lifecyclehistory set ACTORREFERENCE='Administrator' where ACTORREFERENCE='rdadmin';
commit;

select * from lifecyclehistory;