select * from pdmlinkproduct;
update pdmlinkproduct set BATCH_ID=1;
commit;

select * from pdmlinkproduct;
create table pdmlinkproduct_test as select * from pdmlinkproduct where NAME='HX 1808003-Cloud-Chat';
update pdmlinkproduct_test set name='Test_'||name, BATCH_ID=1, DESCRIPTION='test',
SEQUENCENUMBER=90,SOURCEID=100000;
commit;
insert into pdmlinkproduct select * from pdmlinkproduct_test;
commit;

delete from pdmlinkproduct where name='Test_HX 1808003-Cloud-Chat';
commit;

select * from librarycontainer;

select * from int_wtpart;
select distinct LIFECYCLESTATE,type,count(*) from int_wtdocument group by lifecyclestate , type;

select distinct LIFECYCLESTATE,type,count(*) from  int_epmdocument group by lifecyclestate , type;
update int_epmdocument set LIFECYCLESTATE='INWORK' where LIFECYCLESTATE='DESIGN';
commit;
select count(*),migrated from int_epmdocument group by migrated;

select count(*),MIGRATED from contentmetadata where holderclassname='wt.epm.EPMDocument' group by migrated;
select count(*),MIGRATED from contentmetadata where holderclassname='wt.doc.WTDocument' group by migrated;

select * from derivedimage;

select * from contentmetadata;
update contentmetadata set srcfilepath='/mnt/CADPLM/Folder01/hyperx2/vaults/defaultsystemrootfolder/defaultsystemrootfolder_Folder_1';
rollback;

select count(*) from contentmap;

update contentmap set SRCFILEPATH='/mnt/CADPLM/Folder01/hyperx2/vaults/defaultsystemrootfolder/defaultsystemrootfolder_Folder_1';
commit;

select distinct targetfilepath from contentmap;
select 'cp '||SRCFILEPATH||'/'||SRCFILENAME||' '||TARGETFILEPATH||'/'||TARGETFILENAME from contentmap;

select * from derivedimage;

select * from contentmap;
select 'ls -la '||TARGETFILEPATH||'/'||TARGETFILENAME from contentmap;