select * from wtdocumentmaster;
select * from WTDocumentmaster where OBJECTNUMBER in (select WTDOCUMENTNUMBER from wtdocumentmaster@olditg1);

select m.objectnumber, d.type, d.lifecycle, d.lifecyclestate from wtdocumentmaster m, wtdocument d
where m.wbmsourceidentifier=d.masterwbmsourceidentifier and m.objectnumber like 'HX%';-- ('0000000005','0000000006');

select * from epmdocumentmaster where OBJECTNUMBER in (select WTPARTNUMBER from wtpartmaster@olditg1);
--no duplicate object number in epmdocument & wtdocument