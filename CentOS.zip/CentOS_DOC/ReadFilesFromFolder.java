import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ReadFilesFromFolder
{
  public static String parentFolderName;
  public static File folder;
  
  public static void main(String[] args)
    throws Exception
  {
    System.out.println("Enter your folder path to read files: ");
    Scanner scanner1 = new Scanner(System.in);
    String folderPath1 = scanner1.nextLine();
    folder = new File(folderPath1);
    
    System.out.println("Using read path: " + folderPath1);
    
    parentFolderName = new File(folderPath1).getName();
    
    System.out.println("Enter your folder path to write: ");
    Scanner scanner = new Scanner(System.in);
    String folderPath = scanner.nextLine();
    
    System.out.println("Using write path: " + folderPath);
    
    File file = new File(folderPath);
    FileOutputStream fos = new FileOutputStream(file);
    PrintStream ps = new PrintStream(fos);
    System.setOut(ps);
    
    System.out.println("OBJECTNUMBER,NAME,CONTAINER,FOLDERPATH,CREATED,UPDATED,Absolute Path,FileSize,FileExt");
    
    listFilesForFolder(folder);
  }
  
  public static void listFilesForFolder(File folder)
    throws Exception
  {
    File[] arrayOfFile;
    int j = (arrayOfFile = folder.listFiles()).length;
    for (int i = 0; i < j; i++)
    {
      File fileEntry = arrayOfFile[i];
      if (fileEntry.isDirectory())
      {
        listFilesForFolder(fileEntry);
      }
      else
      {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        String fileName = fileEntry.getName();
        
		fileName = new String(fileName.getBytes(), "UTF-8");
		//System.out.println("Filename: "+fileName);
		
		
        String fileExt = new String();
        try
        {
          String tempFileName = fileName;
          int index = tempFileName.lastIndexOf(".");
          fileExt = tempFileName.substring(index, tempFileName.length());
        }
        catch (Exception e)
        {
          fileExt = "not_found";
        }
        String[] data = fileName.split("\\.(?=[^\\.]+$)");
        
        String absolutePath = fileEntry.getParent();
        String[] data1 = absolutePath.split(parentFolderName);
        
        String path = " ";
        if (data1.length > 1) {
          path = path + data1[1];
        }
        path = path.replace("\\", "/");
        try
        {
          Path path1 = Paths.get(fileEntry.getAbsolutePath(), new String[0]);
          
          BasicFileAttributes attr = Files.readAttributes(path1, BasicFileAttributes.class, new LinkOption[0]);
          SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
          SimpleDateFormat output = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
          Date d = sdf1.parse(attr.creationTime().toString());
          String createdDate = output.format(d);
          
          String pathNoFileName = fileEntry.getAbsolutePath();
          
          int i2 = pathNoFileName.lastIndexOf("\\");
          String finalPath = pathNoFileName.substring(0, i2);
		  finalPath = new String(finalPath.getBytes(), "UTF-8");
		//System.out.println("finalPath: "+finalPath);
          
          System.out.println("\""+data[0] + "\",\"" + fileName + "\",\"" + parentFolderName + "\",\"" + path + "\",\"" + 
            createdDate + "\",\"" + sdf.format(Long.valueOf(fileEntry.lastModified())) + "\",\"" + 
            finalPath + "\",\"" + fileEntry.length() + "\",\"" + fileExt+"\"");
        }
        catch (IOException e)
        {
          System.out.println("oops error! " + e.getMessage());
        }
      }
    }
  }
}