--UAT 2 FIXES
--Need to delete these 1362 attributes
--PODKLADKA all will be migrated as Hardware
select * from rh3_qad_item_extract_classif_attributes_all_5_sites_final_23_jan where item_number in(
select item_number from rh3_qad_item_extract_all_5_sites where upper(DESC1) like 'PODKLADKA%' 
and part_type='com.ptcmscloud.StructuralPart');--1362  Rows
select * from rh3_qad_item_extract_classif_attributes_all_5_sites_final_23_jan where item_number in(
select item_number from rh3_qad_item_extract_all_5_sites where upper(DESC1) like '%SRUBA%' 
and part_type='com.ptcmscloud.StructuralPart');--No attributes
select * from rh3_qad_item_extract_classif_attributes_all_5_sites_final_23_jan where item_number in(
select item_number from rh3_qad_item_extract_all_5_sites where upper(DESC1) like '%ARKUSZ%' 
and part_type='com.ptcmscloud.StructuralPart');--No attributes

--COMPARISON WITH VERSION 6 EXCEL
create table Classif_attr_details_migrated_03_MAR_2023 as
select distinct classif_level_1,classif_level_2,classif_level_3,classification_node,attr_name,attr_internal_name
from rh3_qad_item_extract_classif_attributes_all_5_sites_final_23_jan;

alter table Classif_attr_details_migrated_03_MAR_2023 add(DATATYPE varchar2(100),LOV_STATUS varchar2(100),
LOV_VALUES varchar(1000));

--STRUCTURAL PART ATTR MERGED
merge into Classif_attr_details_migrated_03_MAR_2023 a
using(select * from CLASSIFICATION_STRUCTURAL_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS)b
on(upper(trim(a.CLASSIFICATION_NODE)||trim(a.ATTR_NAME))=
upper(trim(b.L3_INTERNAL_NAME)||trim(b.ATTRIBUTE_DISPLAY_NAME)))when matched then update set
a.DATATYPE=b.DATATYPE,a.LOV_STATUS=b.LOV_STATUS,a.LOV_VALUES=b.LOV_VALUES;--416 rows merged.
commit;

--RAW MATERIAL & HARDWARE PART ATTR MERGED
merge into Classif_attr_details_migrated_03_MAR_2023 a
using(select * from CLASSIFICATION_RAW_HARDWARE_PART_L1_L2_L3_ATTRIBUTES_WITH_UNITS)b
on(upper(trim(a.CLASSIFICATION_NODE)||trim(a.ATTR_NAME))=
upper(trim(b.L2_INTERNAL_NAME)||trim(b.ATTRIBUTE_DISPLAY_NAME)))when matched then update set
a.DATATYPE=b.DATATYPE,a.LOV_STATUS=b.LOV_STATUS,a.LOV_VALUES=b.LOV_VALUES;--65 rows merged.
commit;

select * from Classif_attr_details_migrated_03_MAR_2023;--465  Rows
alter table Classif_attr_details_migrated_03_MAR_2023 add(DATA_TYPE varchar2(100));
update Classif_attr_details_migrated_03_MAR_2023 set DATA_TYPE='STRINGVALUE' where LOV_STATUS='No' and DATATYPE='java.lang.String';
update Classif_attr_details_migrated_03_MAR_2023 set DATA_TYPE='ENUMERATION' where LOV_STATUS='Yes' and DATATYPE='java.lang.String';
update Classif_attr_details_migrated_03_MAR_2023 set DATA_TYPE='INTEGERVALUE' where DATATYPE='java.lang.Long';
update Classif_attr_details_migrated_03_MAR_2023 set DATA_TYPE='FLOATVALUE' where DATATYPE='com.ptc.core.meta.common.FloatingPoint';
update Classif_attr_details_migrated_03_MAR_2023 set DATA_TYPE='FLOATVALUEWITHUNITS' where DATATYPE='wt.units.FloatingPointWithUnits';
commit;

alter table Classif_attr_details_migrated_03_MAR_2023 add Matched_datatype varchar2(20);
update Classif_attr_details_migrated_03_MAR_2023 set Matched_datatype='Yes' where 
upper(CLASSIF_LEVEL_1||CLASSIF_LEVEL_2||CLASSIF_LEVEL_3||ATTR_NAME||data_type) in(
select upper(CLASSIF_LEVEL_1||CLASSIF_LEVEL_2||CLASSIF_LEVEL_3||ATTR_NAME||data_type)
from classif_summary_v6_03_mar_2023);--393  Rows
commit;

select * from Classif_attr_details_migrated_03_MAR_2023;