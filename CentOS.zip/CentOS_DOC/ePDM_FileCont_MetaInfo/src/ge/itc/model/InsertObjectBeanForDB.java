package ge.itc.model;

import java.util.ArrayList;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * 
 * @author Anurag Kumar
 * @version 1.2
 * @category ePDM Java Migration Utility
 * @Description Bean class to store the value
 * 
 *  */

public class InsertObjectBeanForDB {
	
	private String versionId;
	
	private String fileName;
	
	private Map<String, String> version_No_Ref;
	
	private String versionNo;
	
	private String versionNoRev;
	
	private String versionDate;
	
	private String realFileName;
	
	private ArrayList<String> filePath;
	
	private String createdFilePath;
	
	final static Logger log = Logger.getLogger(InsertObjectBeanForDB.class);

	public String getVersionId() {
		
		return versionId;
		
	}

	public void setVersionId(String versionId) {
		
		this.versionId = versionId;
		
	}

	public String getFileName() {
		
		return fileName;
	}

	public void setFileName(String fileName) {
		
		this.fileName = fileName;
		
	}

	public Map<String, String> getVersion_No_Ref() {
		
		return version_No_Ref;
	}
	

	public void setVersion_No_Ref(Map<String, String> version_No_Ref) {
		
		this.version_No_Ref = version_No_Ref;
		
	}

	public String getVersionNo() {
		
		return versionNo;
		
	}

	public void setVersionNo(String versionNo) {
		
		this.versionNo = versionNo;
		
	}

	public String getVersionNoRev() {
		
		return versionNoRev;
		
	}

	public void setVersionNoRev(String versionNoRev) {
		
		this.versionNoRev = versionNoRev;
		
	}

	public String getVersionDate() {
		
		return versionDate;
		
	}

	public void setVersionDate(String versionDate) {
		
		this.versionDate = versionDate;
	}

	public String getRealFileName() {
		
		return realFileName;
		
	}

	public void setRealFileName(String realFileName) {
		
		this.realFileName = realFileName;
		
	}

	public ArrayList<String> getFilePath() {
		
		return filePath;
		
	}

	public void setFilePath(ArrayList<String> filePath) {
		
		this.filePath = filePath;
		
	}

	public String getCreatedFilePath() {
		
		return createdFilePath;
		
	}

	public void setCreatedFilePath(String createdFilePath) {
		
		this.createdFilePath = createdFilePath;
		
	}
}
