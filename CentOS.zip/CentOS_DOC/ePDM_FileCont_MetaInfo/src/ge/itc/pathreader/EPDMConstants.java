package ge.itc.pathreader;

public final class  EPDMConstants{
	
	public static final String SOURCE_FOLDER_PATH = "Y:\\ITC_WORK\\Rehearsal\\RH3\\Extraction\\ePDM_06_02_2023\\PL\\vault_indexes";
	public static final String SQL_SCRIPT_FILE_PATH = "Y:\\ITC_WORK\\Rehearsal\\RH3\\Extraction\\ePDM_06_02_2023\\Utility_Output_CSV\\EPDMPHYSICALFILEINFO_Feb06_2023.csv";
}
