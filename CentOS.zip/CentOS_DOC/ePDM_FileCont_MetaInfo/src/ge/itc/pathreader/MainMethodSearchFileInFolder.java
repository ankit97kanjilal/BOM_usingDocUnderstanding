package ge.itc.pathreader;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.RollingFileAppender;

import ge.itc.xmlparser.ReadXMLFile;

/**
 * 
 * @author Anurag Kumar
 * @version 1.2
 * @category Java Mig Utility
 * 
 *           Main Class
 * 
 */
public class MainMethodSearchFileInFolder {

	final static Logger log = Logger.getLogger(MainMethodSearchFileInFolder.class);

	public static void main(String[] args) throws IOException {

		PropertyConfigurator.configure("log4j.properties");

		RollingFileAppender rollingFileAppender = (RollingFileAppender) Logger.getRootLogger().getAppender("file");

		System.out.println("\n" + "ePDM Physical file Meta Information Start ..." + "\n");
		System.out.println("\n" + "Source Folder of index.xml ==>" +EPDMConstants.SOURCE_FOLDER_PATH+ "\n");
		System.out.println("\n" + "SQL Script File Location is ==>" +EPDMConstants.SQL_SCRIPT_FILE_PATH+ "\n");
		System.out.println("The Log File Path is ::  " + rollingFileAppender.getFile()+ "\n");
		System.out.println("\n" + "Wait..");

		log.info("Application Starts");

		File folder = new File(EPDMConstants.SOURCE_FOLDER_PATH);

		if (folder.isDirectory()) {

			File[] listOfFiles = folder.listFiles();
			showFiles(listOfFiles);

		}

		else
			log.info("There is no Folder @ given path :" + folder.getName());
			log.info("Application Ends");
		System.out.println("\n" + "ePDM Physical file Meta Information Sussefully Completed ...!!!" + "\n");
	}

	public static String[] getDirectoryName(File folder) {
		String[] directories = folder.list(new FilenameFilter() {
			@Override
			public boolean accept(File current, String name) {
				return new File(current, name).isDirectory();
			}
		});

		return directories;
	}

	public static void showFiles(File[] files) {

		for (File file : files) {
			if (file.isDirectory()) {

				showFiles(file.listFiles()); // Calls same method again.

			} else {

				if (file.getName().endsWith("img")) {

				} else {
					if (file.getName().equalsIgnoreCase("index.xml")) {

						String filename = ReadXMLFile.xmlParser(file.getAbsolutePath());
						log.info(filename);

					} else {

						log.info("File Name: " + file.getName());

					}
				}

			}
		}

	}
}