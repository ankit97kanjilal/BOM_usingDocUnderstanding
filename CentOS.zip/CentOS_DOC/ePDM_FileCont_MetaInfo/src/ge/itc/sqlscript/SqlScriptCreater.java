package ge.itc.sqlscript;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.apache.log4j.Logger;
import ge.itc.model.InsertObjectBeanForDB;
import ge.itc.pathreader.EPDMConstants;

/**
 * @previous version - output as sql insert query
 * @author Anurag Kumar
 * @version 1.2
 * @category Java Mig Utility
 * 
 * @current version 1.3
 * @author : Ankit Kumar Kanjilal & Irfan Asef Shah => Output we as csv
 * 
 */
public class SqlScriptCreater {

	final static Logger log = Logger.getLogger(SqlScriptCreater.class);

	// private static final String FILENAME =
	// "D:/PSID_18891/ITC_GE_Restricted/Surface/ePDM_Test/EPDMPHYSICALFILEINFO_sqlscript.sql";

	public static String writingSqlCommands(InsertObjectBeanForDB dbobj) {

		BufferedWriter bw = null;
		FileWriter fw = null;

		try {

//			String insertQuery = "INSERT INTO EPDMPHYSICALFILEINFO "
//					+ "(VERSION_ID, VERSION_NUMBER, VERSION_NUMBER_REF, FILENAME, VERSION_DATE, FILE_PATH) " + "VALUES "
//					+ "('" + dbobj.getVersionId() + "','" + dbobj.getVersionNo() + "','" + dbobj.getVersionNoRev()
//					+ "','" + dbobj.getFileName() + "','" + dbobj.getVersionDate() + "','" + dbobj.getCreatedFilePath()
//					+ "');\n";
			
			String header = (char)34 + "VERSION_ID" + (char)34 + "," +
							(char)34 + "VERSION_NUMBER" + (char)34 + "," +
							(char)34 + "VERSION_NUMBER_REF" + (char)34 + "," +
							(char)34 + "FILENAME" + (char)34 + "," +
							(char)34 + "VERSION_DATE" + (char)34 + "," +
							(char)34 + "FILE_PATH" + (char)34 + "\n";
			
			String insertQuery = 
					(char)34 + dbobj.getVersionId() + (char)34 + "," +
					(char)34 + dbobj.getVersionNo() + (char)34 + "," +
					(char)34 + dbobj.getVersionNoRev() + (char)34 + "," +
					(char)34 + dbobj.getFileName() + (char)34 + "," +
					(char)34 + dbobj.getVersionDate() + (char)34 + "," +
					(char)34 + dbobj.getCreatedFilePath() + (char)34 + "\n";

			File file = new File(EPDMConstants.SQL_SCRIPT_FILE_PATH);

			if (!file.exists()) {
				file.createNewFile();
			}

			fw = new FileWriter(file.getAbsoluteFile(), true);
			bw = new BufferedWriter(fw);
			
			if(file.length() == 0)
				bw.write(header);
			bw.write(insertQuery);

			log.info("Insert Statement is ::" + insertQuery);

		} catch (IOException e) {

			e.printStackTrace();

		} finally {

			try {

				if (bw != null)
					bw.close();

				if (fw != null)
					fw.close();

			} catch (IOException ex) {

				ex.printStackTrace();

			}
		}
		return null;
	}

}