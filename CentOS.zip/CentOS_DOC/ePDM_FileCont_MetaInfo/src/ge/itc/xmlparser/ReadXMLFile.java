package ge.itc.xmlparser;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import ge.itc.model.InsertObjectBeanForDB;
import ge.itc.sqlscript.SqlScriptCreater;

/**
 * 
 * @author Anurag Kumar
 * @version 1.2
 * @category Java Mig Utility
 */
public class ReadXMLFile {
	final static Logger log = Logger.getLogger(ReadXMLFile.class);

	public static String xmlParser(String path) {
		Map<String, String> version_No_Ref = new LinkedHashMap<String, String>();
		InsertObjectBeanForDB dbobj = new InsertObjectBeanForDB();
		String filename = null;
		try {

			File fXmlFile = new File(path);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);

			doc.getDocumentElement().normalize();

			NodeList nList = doc.getElementsByTagName("index");

			for (int temp = 0; temp < nList.getLength(); temp++) {

				Node nNode = nList.item(temp);

				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;

					dbobj.setFileName(eElement.getElementsByTagName("filename").item(0).getTextContent());
					filename = dbobj.getFileName();

					NodeList versionNodes = eElement.getElementsByTagName("version");
					for (int i = 0; i < versionNodes.getLength(); i++) {
						Node vNode = versionNodes.item(i);
						Element vElement = (Element) vNode;

						dbobj.setVersionId(vElement.getAttribute("uid").toString());

						dbobj.setVersionDate(vElement.getAttribute("date"));

						dbobj.setVersionNo(vElement.getAttribute("id"));

						dbobj.setVersionNoRev(vElement.getAttribute("ref"));
						version_No_Ref.put(vElement.getAttribute("id"), vElement.getAttribute("ref"));
						dbobj.setCreatedFilePath(ReadXMLFile.getFilePath(path, dbobj));

						log.info(dbobj.getVersionId() + "\t\t" + dbobj.getVersionNo() + "\t\t" + dbobj.getVersionNoRev()
								+ "\t\t" + dbobj.getFileName() + "\t\t" + dbobj.getVersionDate() + "\t\t"
								+ dbobj.getCreatedFilePath() + "\n\n");
						SqlScriptCreater.writingSqlCommands(dbobj);

					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return filename;
	}

	public static String getFilePath(String path, InsertObjectBeanForDB dbobj) {

		String renewed = null;

		if (dbobj.getVersionNoRev().equals("")) {
			String filename = ReadXMLFile.filenameCreater(dbobj.getVersionNo()) + "." + ReadXMLFile.getExtension(dbobj);
			renewed = path.replace("index.xml", filename);

		} else {
			String filename = ReadXMLFile.filenameCreater(dbobj.getVersionNoRev()) + "."
					+ ReadXMLFile.getExtension(dbobj);
			renewed = path.replace("index.xml", filename);

		}
		return renewed;
	}

	public static String decimal2hex(int n) {
		String val = Integer.toHexString(n);
		return val;
	}

	public static String filenameCreater(String s) {
		int no = Integer.parseInt(s);
		String hexno = null;
		if (no > 15 && no < 255) {
			hexno = "000000" + ReadXMLFile.decimal2hex(no);
		}
		if (no > 255) {
			hexno = "00000" + ReadXMLFile.decimal2hex(no);
		}
		if (no <= 15) {
			hexno = "0000000" + ReadXMLFile.decimal2hex(no);
		}
		return hexno;
	}

	public static String getExtension(InsertObjectBeanForDB dbobj) {
		String[] fileExtension = dbobj.getFileName().split("\\.");
		String s = fileExtension[1];
		return s;
	}
}
